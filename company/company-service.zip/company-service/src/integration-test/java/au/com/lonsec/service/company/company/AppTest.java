package au.com.lonsec.service.company.company;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

// insert by Max Cheung <max.cheung@lonsec.com.au> [30Aug.,2017, 3:42:19 pm]
// Review slow unit testing in spring-boot application

@Ignore
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("it")
public class AppTest {

    @Test
    public void contextLoads() {
    }

}
