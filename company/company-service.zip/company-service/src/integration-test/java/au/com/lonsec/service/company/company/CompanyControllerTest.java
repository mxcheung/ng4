package au.com.lonsec.service.company.company;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.lonsec.service.company.company.client.model.CompanyGetByIdsRequest;
import au.com.lonsec.service.company.company.model.Company;
import au.com.lonsec.service.company.company.server.CompanyController;
import au.com.lonsec.service.company.company.server.CompanyURI;

@RunWith(SpringRunner.class)
@WebMvcTest(value = CompanyController.class, secure = false)
public class CompanyControllerTest extends CompanyTst {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CompanyService companyService;

    private Company company;

    @Before
    public void setup() {
        companyAddRequest = getCompanyAddRequest();
        companyUpdateRequest = getCompanyUpdateRequest();
        companiesGetResponse = getCompaniesGetResponse();
        companyGetByIdsRequest = getCompanyGetByIdsRequest();
        companyEntity = getCompanyEntity();
        company = getCompany();
        companyMap = getCompanyMap();
    }

    @Test
    public void shouldCreateProduct() throws Exception {
        MockHttpServletResponse response = checkEndpoint(CompanyURI.POST_COMPANIES_MAPPING);
        assertEquals(HttpStatus.CREATED.value(), response.getStatus());
    }

    @Test
    public void shouldUpdateProduct() throws Exception {
        companyUpdateRequest.setId(ID);
        MockHttpServletResponse response = checkputEndpoint(CompanyURI.PUT_COMPANIES_MAPPING, COMPANY_ABN);
        assertEquals(HttpStatus.ACCEPTED.value(), response.getStatus());
    }

    @Test
    public void shouldRejectInvalidURL() throws Exception {
        MockHttpServletResponse response = checkEndpoint("/doesNotExist");
        assertEquals(HttpStatus.NOT_FOUND.value(), response.getStatus());
    }

    @Test
    public void shouldFindCompany() throws Exception {
        when(companyService.findCompany(COMPANY_ABN)).thenReturn(company);
        MockHttpServletResponse response = getEndpoint("abn");
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void shouldFindCompanyByABNs() throws Exception {
        assertEquals(1, companiesGetResponse.getCompanies().size());
        when(companyService.fetchByABNs(companyGetByIdsRequest)).thenReturn(companyMap);
        MockHttpServletResponse response = fetchByABNsGEndpoint(companyGetByIdsRequest);
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void shouldHandleCompanyNotFoundException() throws Exception {
        String abn = "dummy";
        when(companyService.findCompany(abn)).thenThrow(new CompanyNotFoundException("dummy"));
        MockHttpServletResponse response = getEndpoint(abn);
        assertEquals(HttpStatus.NOT_FOUND.value(), response.getStatus());
    }

    @Test
    public void shouldHandleCompanyMissingMandatoryFields() throws Exception {
        companyAddRequest.setAbn(null);
        MockHttpServletResponse response = checkEndpoint(CompanyURI.POST_COMPANIES_MAPPING);
        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getStatus());
    }

    @Test
    public void shouldHandleRunTimeException() throws Exception {
        doThrow(new RuntimeException()).when(companyService).createCompany(any());
        MockHttpServletResponse response = checkEndpoint(CompanyURI.POST_COMPANIES_MAPPING);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getStatus());
    }

    private MockHttpServletResponse fetchByABNsGEndpoint(CompanyGetByIdsRequest companyGetByIdsRequest) throws JsonProcessingException, Exception {
        ObjectMapper mapper = new ObjectMapper();
        String plainTextJson = mapper.writeValueAsString(companyGetByIdsRequest);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.post(CompanyURI.COMPANY_BASE_CONTEXT + CompanyURI.COMPANY_ABNS_MAPPING)
                .accept(MediaType.APPLICATION_JSON).content(plainTextJson).contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        return result.getResponse();
    }

    private MockHttpServletResponse getEndpoint(String abn) throws JsonProcessingException, Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(CompanyURI.COMPANY_BASE_CONTEXT + CompanyURI.GET_COMPANY_MAPPING, abn)
                .header("segmentCd", SEGMENT_CD).accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        return result.getResponse();
    }

    private MockHttpServletResponse checkEndpoint(String endpoint) throws JsonProcessingException, Exception {
        ObjectMapper mapper = new ObjectMapper();
        String plainTextJson = mapper.writeValueAsString(companyAddRequest);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.post(CompanyURI.COMPANY_BASE_CONTEXT + endpoint).accept(MediaType.APPLICATION_JSON)
                .content(plainTextJson).contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        return result.getResponse();
    }

    private MockHttpServletResponse checkputEndpoint(String endpoint, String abn) throws JsonProcessingException, Exception {
        ObjectMapper mapper = new ObjectMapper();
        String plainTextJson = mapper.writeValueAsString(companyUpdateRequest);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.put(CompanyURI.COMPANY_BASE_CONTEXT + endpoint, abn).accept(MediaType.APPLICATION_JSON)
                .content(plainTextJson).contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        return result.getResponse();
    }

}
