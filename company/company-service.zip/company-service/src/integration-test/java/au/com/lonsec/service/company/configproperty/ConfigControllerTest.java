package au.com.lonsec.service.company.configproperty;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
@WebMvcTest(value = ConfigController.class, secure = false)
public class ConfigControllerTest {

    private static final String ENTITY_ID = "entityId";

    private static final String SEGMENT_CD = "segmentCd";

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ConfigPropertyService configPropertyService;

    private ConfigDTO configDTO;

    static final String CONFIG_BASE_CONTEXT = "/config";
    static final String CONFIG_SAVE_MAPPING = "/save";
    static final String CONFIG_GET_MAPPING = "/get/{entityId}";

    @Before
    public void setup() {

        configDTO = new ConfigDTO();
        List<ConfigProperty> propertyList = new ArrayList<ConfigProperty>();
        ConfigProperty configProperty = new ConfigProperty();
        configProperty.setKey("key1");
        configProperty.setValue("value1");
        configProperty.setType(ConfigPropertyType.COMPANY);
        propertyList.add(configProperty);
        configDTO.setType(ConfigPropertyType.COMPANY.name());
        configDTO.setPropertyList(propertyList);
        configDTO.setEntityId(ENTITY_ID);
    }

    @Test
    public void shouldSaveConfig() throws Exception {
        MockHttpServletResponse response = checkEndpoint(CONFIG_SAVE_MAPPING);
        assertEquals(HttpStatus.CREATED.value(), response.getStatus());
    }

    @Test
    public void shouldRejectInvalidURL() throws Exception {
        MockHttpServletResponse response = checkEndpoint("/doesNotExist");
        assertEquals(HttpStatus.NOT_FOUND.value(), response.getStatus());
    }

    @Test
    public void shouldHandleConfigPropertyEntityNotFoundException() throws Exception {
        when(configPropertyService.getEntityProperties(ENTITY_ID, ConfigPropertyType.COMPANY))
                .thenThrow(new ConfigPropertyEntityNotFoundException("dummy"));
        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(CONFIG_BASE_CONTEXT + CONFIG_GET_MAPPING, ENTITY_ID).header(SEGMENT_CD, SEGMENT_CD)
                .param("type", "COMPANY").accept(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.NOT_FOUND.value(), response.getStatus());
    }

    @Test
    public void shouldReturnConfigPropertyEntity() throws Exception {
        List<ConfigProperty> propertyList = new ArrayList<ConfigProperty>();
        when(configPropertyService.getEntityProperties(ENTITY_ID, ConfigPropertyType.COMPANY)).thenReturn(propertyList);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(CONFIG_BASE_CONTEXT + CONFIG_GET_MAPPING, ENTITY_ID).header(SEGMENT_CD, SEGMENT_CD)
                .param("type", "COMPANY").accept(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    private MockHttpServletResponse checkEndpoint(String endpoint) throws JsonProcessingException, Exception {
        ObjectMapper mapper = new ObjectMapper();
        String plainTextJson = mapper.writeValueAsString(configDTO);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.post(CONFIG_BASE_CONTEXT + endpoint).accept(MediaType.APPLICATION_JSON)
                .content(plainTextJson).contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        return result.getResponse();
    }

}
