package au.com.lonsec.service.company.product;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.lonsec.service.company.product.client.model.ProductRequest;
import au.com.lonsec.service.company.product.client.model.ProductUpdateRequest;
import au.com.lonsec.service.company.web.DpProfile;

@RunWith(SpringRunner.class)
@WebMvcTest(value = ProductController.class, secure = false)
public class ProductControllerTest extends ProductTst {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ProductService productService;

    private ProductRequest productAddDTO;

    private ProductUpdateRequest productUpdateRequest;
    
    private static final String PROFILE_TOKEN = "eyJpZCI6ICJmZjFjNjFiYS1iYWQzLTExZTctYWJjNC1jZWMyNzhiNmI1MGEiLCJ1c2VybmFtZSI6ICJEUF9TUl9FTVBfQURNSU4iLCJzZWdtZW50IjoiU1IiLCJleHRJZCI6IjAwMCIsInJvbGUiOiAiNDgifQ==";
    
    public static final String ACCESS_TOKEN_EMP_ADMIN = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX25hbWUiOiJEUF9MUl9FT"
            + "VBfQURNSU4iLCJzdXJuYW1lIjoiRW1wQWRtaW4iLCJzY29wZSI6WyJyZWFkIiwid3JpdGUiXSwiYXR0cmlidXRlcyI6eyJURUwxIjoiOTk5OT"
            + "k5OTkifSwiZXhwIjoxNTA5OTUzODc0LCJmaXJzdF9uYW1lIjoiTFIiLCJhdXRob3JpdGllcyI6WyJEUF9JTlRFUk5BTCJdLCJqdGkiOiIyMjR"
            + "jZTAzMS0zNjcyLTQ3ZTItOThhZC1mZTk1MGM0NDA1MjAiLCJlbWFpbCI6ImRwbHJlbXBhZG1pbi4yMC5pdGRldmxvbnNlY0BzcGFtZ291cm1l"
            + "dC5jb20iLCJjbGllbnRfaWQiOiJsb25zZWNBcHAifQ.oJar4XQQxnHv12rSQ7JRBRTtNCvOsNTLCMcYtoYUAnw-rX1ocYoR1PoZblIrr5vcPK"
            + "_ZRg1tyDUtG76hSzCVbf3ssKjoQO5roaTbZlYe-SowMA9eZhFcXIkA1n5M0cijbYdzt9ZoDsKahz3gF-U1Rkj-WzsjPPI90U4vnsryCnMqCtj"
            + "Mvd5PiQIYSd4wnmxFLOY4A3yGUE7aSnXxMfzripQJhgW_n_1YWOM90t_v5fnIC7ZPEIXlh5IWwzdBv_oOuFpthwMMUSXlw8AlDvLvQlXtHQfT"
            + "EfmTA8jfJzfveiKnN5_nj5cyTu0oAd8IwCa2ip73Hzb-opRomCKXjSSeuQ";

    @Before
    public void setup() {
        product = getProduct();
        productAddRequest = getProductAddRequest();
        productGetRequest = getProductGetRequest();
        productUpdateRequest = getProductUpdateRequest();
        productsGetResponse = getProductsGetResponse();
        productGetResponse = getProductGetResponse();
    }

    @Test
    public void shouldCreateProduct() throws Exception {
        MockHttpServletResponse response = checkEndpoint(ProductURI.POST_PRODUCTS_MAPPING);
        assertEquals(HttpStatus.CREATED.value(), response.getStatus());
    }

    @Test
    public void shouldUpdateProduct() throws Exception {
        MockHttpServletResponse response = checkputEndpoint(ProductURI.PUT_PRODUCTS_MAPPING);
        assertEquals(HttpStatus.ACCEPTED.value(), response.getStatus());
    }

    @Test
    public void shouldUpdateProductClassification() throws Exception {
        MockHttpServletResponse response = checkputEndpoint(ProductURI.PUT_PRODUCT_CLASSIFICATION_MAPPING);
        assertEquals(HttpStatus.ACCEPTED.value(), response.getStatus());
    }
    
    @Test
    public void shouldFindProduct() throws Exception {
        when(productService.findProduct(SEGMENT_UUID, PRODUCT_ID)).thenReturn(product);
        ObjectMapper mapper = new ObjectMapper();
        String plainTextJson = mapper.writeValueAsString(productAddDTO);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(ProductURI.PRODUCT_BASE_CONTEXT + ProductURI.GET_PRODUCT_MAPPING, PRODUCT_ID)
                .header("segmentCd", SEGMENT_CD).param("segmentId", SEGMENT_UUID).accept(MediaType.APPLICATION_JSON).content(plainTextJson)
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void shouldFindProductsBySegment() throws Exception {
        DpProfile profileToken = DpProfile.fromToken(PROFILE_TOKEN, "test");
        when(productService.findProducts(SEGMENT_CD, profileToken)).thenReturn(products);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(ProductURI.PRODUCT_BASE_CONTEXT + ProductURI.GET_PRODUCTS_MAPPING)
                .header("segmentCd", SEGMENT_CD).header("profileToken", PROFILE_TOKEN).header("Authorization", "Bearer " + ACCESS_TOKEN_EMP_ADMIN).accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void shouldFindProductsByExtUniqueKey() throws Exception {
        when(productService.findBySegmentCdAndExtUniqueKey(SEGMENT_CD, EXT_UNIQUE_KEY)).thenReturn(products);
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get(ProductURI.PRODUCT_BASE_CONTEXT + ProductURI.GET_PRODUCTS_SEGMENT_MAPPING, EXT_UNIQUE_KEY).header("segmentCd", SEGMENT_CD)
                .param("segmentId", SEGMENT_UUID).accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void shouldHandleProductNotFoundException() throws Exception {
        when(productService.findProduct(SEGMENT_CD, PRODUCT_ID)).thenThrow(new ProductNotFoundException("dummy"));
        ObjectMapper mapper = new ObjectMapper();
        String plainTextJson = mapper.writeValueAsString(productAddDTO);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(ProductURI.PRODUCT_BASE_CONTEXT + ProductURI.GET_PRODUCT_MAPPING, PRODUCT_ID)
                .header("segmentCd", SEGMENT_CD).accept(MediaType.APPLICATION_JSON).content(plainTextJson).contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.NOT_FOUND.value(), response.getStatus());
    }

    @Test
    public void shouldRejectInvalidURL() throws Exception {
        MockHttpServletResponse response = checkEndpoint("/doesNotExist");
        assertEquals(HttpStatus.NOT_FOUND.value(), response.getStatus());
    }

    private MockHttpServletResponse checkEndpoint(String endpoint) throws JsonProcessingException, Exception {
        ObjectMapper mapper = new ObjectMapper();
        String plainTextJson = mapper.writeValueAsString(productAddRequest);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.post(ProductURI.PRODUCT_BASE_CONTEXT + endpoint).header("segmentCd", SEGMENT_CD)
                .accept(MediaType.APPLICATION_JSON).content(plainTextJson).contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        return result.getResponse();
    }

    private MockHttpServletResponse checkputEndpoint(String endpoint) throws JsonProcessingException, Exception {
        ObjectMapper mapper = new ObjectMapper();
        String plainTextJson = mapper.writeValueAsString(productUpdateRequest);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.put(ProductURI.PRODUCT_BASE_CONTEXT + endpoint, PRODUCT_ID)
                .header("segmentCd", SEGMENT_CD).accept(MediaType.APPLICATION_JSON).content(plainTextJson).contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        return result.getResponse();
    }

}
