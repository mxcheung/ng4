package au.com.lonsec.service.company.lookup;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.lonsec.service.company.lookup.model.LookupValue;

@RunWith(SpringRunner.class)
@WebMvcTest(value = LookupController.class, secure = false)
public class LookupControllerTest extends LookupTst {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private LookupService lookupService;

    static final String LOOKUP_BASE_CONTEXT = "/lookup";
    private static final String LOOKUP_FETCH_MAPPING = "/lookupFetch";
    private static final String LOOKUP_REFRESH = "/lookupLoadALL";

    @Before
    public void setup() {
        lookupGetRequest = getLookupGetRequest();
        lookupLoadRequest = getLookupLoadRequest();
        lookupCompanyResponse = getLookupCompanyResponse();
    }

    @Test
    public void shouldRejectInvalidURL() throws Exception {
        MockHttpServletResponse response = checkEndpoint("/doesNotExist");
        assertEquals(HttpStatus.NOT_FOUND.value(), response.getStatus());
    }

    @Test
    public void shouldFetchLookup() throws Exception {
        Map<String, List<LookupValue>> lookups = new HashMap<String, List<LookupValue>>();
        when(lookupService.fetchLookupByType(lookupGetRequest)).thenReturn(lookups);
        MockHttpServletResponse response = checkEndpoint(LOOKUP_FETCH_MAPPING);
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void shouldFetchCompanyLookup() throws Exception {
        Map<String, List<LookupValue>> lookups = new HashMap<String, List<LookupValue>>();
        when(lookupService.fetchLookupByType(any(LookupGetRequest.class))).thenReturn(lookups);
        MockHttpServletResponse response = checkGetEndpoint(LookupURI.COMPANY_LOOKUP);
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void shouldFetchProductLookup() throws Exception {
        Map<String, List<LookupValue>> lookups = new HashMap<String, List<LookupValue>>();
        when(lookupService.fetchLookupByType(any(LookupGetRequest.class))).thenReturn(lookups);
        MockHttpServletResponse response = checkGetEndpoint(LookupURI.PRODUCT_LOOKUP);
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void shouldFetchContactLookup() throws Exception {
        Map<String, List<LookupValue>> lookups = new HashMap<String, List<LookupValue>>();
        when(lookupService.fetchLookupByType(any(LookupGetRequest.class))).thenReturn(lookups);
        MockHttpServletResponse response = checkGetEndpoint(LookupURI.CONTACT_LOOKUP);
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void shouldRefreshLookup() throws Exception {
        List<LookupEntity> lookups = new ArrayList<LookupEntity>();
        when(lookupService.lookupLoad(lookupLoadRequest)).thenReturn(lookups);
        MockHttpServletResponse response = checkEndpoint(LOOKUP_REFRESH);
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    private MockHttpServletResponse checkEndpoint(String endpoint) throws JsonProcessingException, Exception {
        ObjectMapper mapper = new ObjectMapper();
        String plainTextJson = mapper.writeValueAsString(lookupGetRequest);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.post(LOOKUP_BASE_CONTEXT + endpoint).accept(MediaType.APPLICATION_JSON)
                .content(plainTextJson).contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        return result.getResponse();
    }

    private MockHttpServletResponse checkGetEndpoint(String endpoint) throws JsonProcessingException, Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(LOOKUP_BASE_CONTEXT + endpoint).accept(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        return result.getResponse();
    }

}
