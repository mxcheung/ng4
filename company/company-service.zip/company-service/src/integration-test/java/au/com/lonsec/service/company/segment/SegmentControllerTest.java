package au.com.lonsec.service.company.segment;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.lonsec.service.company.segment.client.model.SegmentRequest;
import au.com.lonsec.service.company.segment.model.Segment;

@RunWith(SpringRunner.class)
@WebMvcTest(value = SegmentController.class, secure = false)
public class SegmentControllerTest extends SegmentTst {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private SegmentService segmentService;

    private SegmentRequest segmentAddDTO;

    private SegmentEntity segmentEntity;

    private Segment segment;

    @Before
    public void setup() {

        segmentAddDTO = new SegmentRequest();
        segmentAddDTO.setSegmentCd(SEGMENT_CD);
        segmentAddDTO.setExtUniqueKey(EXT_UNIQUE_KEY);
        segmentAddDTO.setAnalyst(ANALYST);
        segmentAddDTO.setCompanyId(COMPANY_ID);

        segment = getSegment();

        segmentEntity = new SegmentEntity();
        segmentEntity.setExtUniqueKey(EXT_UNIQUE_KEY);

        segmentAddRequest = getSegmentAddRequest();
        segmentUpdateRequest = getSegmentUpdateRequest();
        segmentsGetResponse = getSegmentsGetResponse();
        segments = getSegments();

    }

    @Test
    public void shouldCreateProduct() throws Exception {
        MockHttpServletResponse response = checkEndpoint(SegmentURI.POST_SEGMENTS_MAPPING);
        assertEquals(HttpStatus.CREATED.value(), response.getStatus());
    }

    @Test
    public void shouldUpdateProduct() throws Exception {
        MockHttpServletResponse response = checkputEndpoint(SegmentURI.PUT_SEGMENTS_MAPPING, EXT_UNIQUE_KEY);
        assertEquals(HttpStatus.ACCEPTED.value(), response.getStatus());
    }

    @Test
    public void shouldRejectInvalidURL() throws Exception {
        MockHttpServletResponse response = checkEndpoint("/doesNotExist");
        assertEquals(HttpStatus.NOT_FOUND.value(), response.getStatus());
    }

    @Test
    public void shouldFindSegment() throws Exception {
        when(segmentService.findSegment(SEGMENT_CD, EXT_UNIQUE_KEY)).thenReturn(segment);
        MockHttpServletResponse response = getEndpoint(EXT_UNIQUE_KEY);
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void shouldFindSegmentsBySegmentCd() throws Exception {
        when(segmentService.findSegment(SEGMENT_CD)).thenReturn(segments);
        MockHttpServletResponse response = getfindBySegmentCdEndpoint();
        verify(segmentService, times(1)).findSegment(SEGMENT_CD);
        verifyNoMoreInteractions(segmentService);
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void shouldFindSegmentsByCompanyName() throws Exception {
        when(segmentService.findByCompanyNameContaining(SEGMENT_CD, "companyName")).thenReturn(segments);
        MockHttpServletResponse response = getfindByCompanyNameContainingEndpoint("companyName");
        verify(segmentService, times(1)).findByCompanyNameContaining(SEGMENT_CD, "companyName");
        verifyNoMoreInteractions(segmentService);
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void shouldHandleCompanyNotFoundException() throws Exception {
        String extUniqueKey = "dummy";
        when(segmentService.findSegment(SEGMENT_CD, extUniqueKey)).thenThrow(new SegmentNotFoundException("dummy"));
        MockHttpServletResponse response = getEndpoint(extUniqueKey);
        assertEquals(HttpStatus.NOT_FOUND.value(), response.getStatus());
    }

    @Test
    public void shouldHandleSegmentMissingMandatoryFields() throws Exception {
        segmentAddDTO.setExtUniqueKey(null);
        MockHttpServletResponse response = checkEndpoint(SegmentURI.POST_SEGMENTS_MAPPING);
        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getStatus());
    }

    @Test
    public void shouldHandleRunTimeException() throws Exception {
        doThrow(new RuntimeException()).when(segmentService).createSegment(any());
        MockHttpServletResponse response = checkEndpoint(SegmentURI.POST_SEGMENTS_MAPPING);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getStatus());
    }

    private MockHttpServletResponse getEndpoint(String extUniqueKey) throws JsonProcessingException, Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(SegmentURI.SEGMENT_BASE_CONTEXT + SegmentURI.GET_SEGMENT_MAPPING, extUniqueKey)
                .header("segmentCd", SEGMENT_CD).accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        return result.getResponse();
    }

    private MockHttpServletResponse getfindBySegmentCdEndpoint() throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(SegmentURI.SEGMENT_BASE_CONTEXT + SegmentURI.GET_SEGMENTS_MAPPING)
                .header("segmentCd", SEGMENT_CD).accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        return result.getResponse();
    }

    private MockHttpServletResponse getfindByCompanyNameContainingEndpoint(String companyName) throws JsonProcessingException, Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(SegmentURI.SEGMENT_BASE_CONTEXT + SegmentURI.GET_SEGMENTS_BY_COMPANYNAME_MAPPING)
                .header("segmentCd", SEGMENT_CD).accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON)
                .param("companyName", companyName);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        return result.getResponse();
    }

    private MockHttpServletResponse checkEndpoint(String endpoint) throws JsonProcessingException, Exception {
        ObjectMapper mapper = new ObjectMapper();
        String plainTextJson = mapper.writeValueAsString(segmentAddDTO);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.post(SegmentURI.SEGMENT_BASE_CONTEXT + endpoint).header("segmentCd", SEGMENT_CD)
                .accept(MediaType.APPLICATION_JSON).content(plainTextJson).contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        return result.getResponse();
    }

    private MockHttpServletResponse checkputEndpoint(String endpoint, String extUniqueKey) throws JsonProcessingException, Exception {
        ObjectMapper mapper = new ObjectMapper();
        String plainTextJson = mapper.writeValueAsString(segmentUpdateRequest);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.put(SegmentURI.SEGMENT_BASE_CONTEXT + endpoint, extUniqueKey).header("segmentCd", SEGMENT_CD)
                .accept(MediaType.APPLICATION_JSON).content(plainTextJson).contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        return result.getResponse();
    }

}
