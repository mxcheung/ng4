package au.com.lonsec.service.company.productDashboard;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.lonsec.service.company.web.DpProfile;

@RunWith(SpringRunner.class)
@WebMvcTest(value = ProductDashboardController.class, secure = false)
public class ProductDashboardControllerTest extends ProductDashboardTst {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ProductDashboardService productDashboardService;

    @Before
    public void setup() {
        product = getProduct();
        productDashboardRowsGetResponse = getProductDashboardRowsGetResponse();
        productDashboardRows = getProductDashboardRows();
    }
    private static final String PROFILE_TOKEN = "eyJpZCI6ICJmZjFjNjFiYS1iYWQzLTExZTctYWJjNC1jZWMyNzhiNmI1MGEiLCJ1c2VybmFtZSI6ICJEUF9TUl9FTVBfQURNSU4iLCJzZWdtZW50IjoiU1IiLCJleHRJZCI6IjAwMCIsInJvbGUiOiAiNDgifQ==";
    public static final String ACCESS_TOKEN_EMP_ADMIN = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX25hbWUiOiJEUF9MUl9FT"
            + "VBfQURNSU4iLCJzdXJuYW1lIjoiRW1wQWRtaW4iLCJzY29wZSI6WyJyZWFkIiwid3JpdGUiXSwiYXR0cmlidXRlcyI6eyJURUwxIjoiOTk5OT"
            + "k5OTkifSwiZXhwIjoxNTA5OTUzODc0LCJmaXJzdF9uYW1lIjoiTFIiLCJhdXRob3JpdGllcyI6WyJEUF9JTlRFUk5BTCJdLCJqdGkiOiIyMjR"
            + "jZTAzMS0zNjcyLTQ3ZTItOThhZC1mZTk1MGM0NDA1MjAiLCJlbWFpbCI6ImRwbHJlbXBhZG1pbi4yMC5pdGRldmxvbnNlY0BzcGFtZ291cm1l"
            + "dC5jb20iLCJjbGllbnRfaWQiOiJsb25zZWNBcHAifQ.oJar4XQQxnHv12rSQ7JRBRTtNCvOsNTLCMcYtoYUAnw-rX1ocYoR1PoZblIrr5vcPK"
            + "_ZRg1tyDUtG76hSzCVbf3ssKjoQO5roaTbZlYe-SowMA9eZhFcXIkA1n5M0cijbYdzt9ZoDsKahz3gF-U1Rkj-WzsjPPI90U4vnsryCnMqCtj"
            + "Mvd5PiQIYSd4wnmxFLOY4A3yGUE7aSnXxMfzripQJhgW_n_1YWOM90t_v5fnIC7ZPEIXlh5IWwzdBv_oOuFpthwMMUSXlw8AlDvLvQlXtHQfT"
            + "EfmTA8jfJzfveiKnN5_nj5cyTu0oAd8IwCa2ip73Hzb-opRomCKXjSSeuQ";

    @Test
    public void shouldFindProductsBySegment() throws Exception {
        DpProfile profileToken = DpProfile.fromToken(PROFILE_TOKEN, "test");
        when(productDashboardService.findProducts(SEGMENT_CD, profileToken)).thenReturn(productDashboardRows);
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get(ProductDashBoardURI.PRODUCT_BASE_CONTEXT + ProductDashBoardURI.GET_PRODUCTS_MAPPING).header("segmentCd", SEGMENT_CD)
                .header("profileToken", PROFILE_TOKEN).header("Authorization", "Bearer " + ACCESS_TOKEN_EMP_ADMIN).accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    private MockHttpServletResponse checkEndpoint(String endpoint) throws JsonProcessingException, Exception {
        ObjectMapper mapper = new ObjectMapper();
        String plainTextJson = mapper.writeValueAsString(productAddRequest);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.post(ProductDashBoardURI.PRODUCT_BASE_CONTEXT + endpoint)
                .header("segmentCd", SEGMENT_CD).accept(MediaType.APPLICATION_JSON).content(plainTextJson).contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        return result.getResponse();
    }

}
