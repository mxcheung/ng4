package au.com.lonsec.service.company.companyDashboard;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

@RunWith(SpringRunner.class)
@WebMvcTest(value = CompanyDashboardController.class, secure = false)
public class CompanyDashboardControllerTest extends CompanyDashboardTst {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CompanyDashboardService companyDashboardService;

    @Before
    public void setup() {
        segment = getSegment();
        companyDashboardRowsGetResponse = getCompanyDashboardRowsGetResponse();
        companyDashboardRows = getCompanyDashboardRows();
    }

    @Test
    public void shouldFindCompanysBySegment() throws Exception {
        when(companyDashboardService.findCompanies(SEGMENT_CD)).thenReturn(companyDashboardRows);
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get(CompanyDashBoardURI.COMPANY_BASE_CONTEXT + CompanyDashBoardURI.GET_COMPANIES_MAPPING).header("segmentCd", SEGMENT_CD)
                .accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

}
