package au.com.lonsec.service.company.productClassification;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.lonsec.service.company.productClassification.model.ProductClassification;

@RunWith(SpringRunner.class)
@WebMvcTest(value = ProductClassificationController.class, secure = false)
public class ProductClassificationControllerTest extends ProductClassificationTst {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ProductClassificationService productClassificationService;

    @Before
    public void setup() {
        productClassificationGetRequest = getProductClassificationGetRequest();
        productClassificationLoadRequest = getProductClassificationLoadRequest();
    }

    @Test
    public void shouldRejectInvalidURL() throws Exception {
        MockHttpServletResponse response = checkEndpoint("/doesNotExist");
        assertEquals(HttpStatus.NOT_FOUND.value(), response.getStatus());
    }

    @Test
    public void shouldFetchProductClassification() throws Exception {
        ProductClassification productClassification = getProductClassification();
        when(productClassificationService.findProductClassification(PRODUCT_ID)).thenReturn(productClassification);
        MockHttpServletResponse response = checkGetEndpoint(ProductClassificationURI.GET_PRODUCT_CLASSIFICATION_MAPPING);
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void shouldRefreshProductClassification() throws Exception {
        List<ProductClassificationEntity> productClassifications = new ArrayList<ProductClassificationEntity>();
        when(productClassificationService.productClassificationLoad(productClassificationLoadRequest)).thenReturn(productClassifications);
        MockHttpServletResponse response = checkEndpoint(ProductClassificationURI.PRODUCT_CLASSIFICATION_REFRESH);
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    private MockHttpServletResponse checkEndpoint(String endpoint) throws JsonProcessingException, Exception {
        ObjectMapper mapper = new ObjectMapper();
        String plainTextJson = mapper.writeValueAsString(productClassificationGetRequest);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.post(ProductClassificationURI.PRODUCT_CLASSIFICATION_BASE_CONTEXT + endpoint)
                .accept(MediaType.APPLICATION_JSON).content(plainTextJson).contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        return result.getResponse();
    }

    private MockHttpServletResponse checkGetEndpoint(String endpoint) throws JsonProcessingException, Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get(ProductClassificationURI.PRODUCT_CLASSIFICATION_BASE_CONTEXT + endpoint, PRODUCT_ID).header("segmentCd", SEGMENT_CD)
                .accept(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        return result.getResponse();
    }

}
