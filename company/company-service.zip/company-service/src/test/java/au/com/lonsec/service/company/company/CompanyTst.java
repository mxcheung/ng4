package au.com.lonsec.service.company.company;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import au.com.lonsec.service.company.company.client.model.CompaniesGetResponse;
import au.com.lonsec.service.company.company.client.model.CompanyAddRequest;
import au.com.lonsec.service.company.company.client.model.CompanyGetByIdsRequest;
import au.com.lonsec.service.company.company.client.model.CompanyUpdateRequest;
import au.com.lonsec.service.company.company.model.Company;

public abstract class CompanyTst {

    protected static final String ACTIVE = "ACTIVE";
    protected static final String ID = "81dd92a4-be95-47ca-9922-12f29c05da8c";
    protected static final UUID COMPANY_UUID = UUID.fromString(ID);

    protected static final String COMPANY_NAME = "bhp";
    protected static final String COMPANY_ABN = "12345678901";
    protected static final String COMPANY_ADDRESS = "1 Main rd somewhere";
    protected static final String COMPANY_PARENT_ID = "126be751-86ee-454f-bcce-4752df2c5594";
    protected static final String ANALYST = "analyst";
    protected static final String SEGMENT_CD = "SR";
    protected static final String SEGMENT_EXT_UNIQUE_KEY = "276";

    protected Company company;
    protected CompanyEntity companyEntity;
    protected CompanyAddRequest companyAddRequest;
    protected CompanyUpdateRequest companyUpdateRequest;
    protected CompaniesGetResponse companiesGetResponse;
    protected CompanyGetByIdsRequest companyGetByIdsRequest;

    protected List<Company> companies;
    protected Map<String, Company> companyMap;

    public CompanyTst() {
        super();
    }

    protected Company getCompanyDTO() {
        Company companyRequestDTO = new Company(COMPANY_NAME, COMPANY_ABN, COMPANY_ADDRESS, COMPANY_PARENT_ID);
        return companyRequestDTO;
    }

    protected Company getCompany() {
        Company company = new Company();
        populateCompany(company);
        return company;
    }

    private void populateCompany(Company company) {
        company.setId(ID);
        company.setAddress(COMPANY_ADDRESS);
        company.setAbn(COMPANY_ABN);
        company.setCompanyName(COMPANY_NAME);
        company.setParentId(COMPANY_PARENT_ID);
        company.setStatus(ACTIVE);
    }

    protected CompanyGetByIdsRequest getCompanyGetByIdsRequest() {
        CompanyGetByIdsRequest companyGetByIdsRequest = new CompanyGetByIdsRequest();
        List<String> abns = new ArrayList<String>();
        abns.add(COMPANY_ABN);
        companyGetByIdsRequest.setAbns(abns);
        return companyGetByIdsRequest;
    }

    protected CompanyAddRequest getCompanyAddRequest() {
        CompanyAddRequest companyAddRequest = new CompanyAddRequest();
        populateCompany(companyAddRequest);
        return companyAddRequest;
    }

    protected Map<String, Company> getCompanyMap() {
        Map<String, Company> companyMap = new HashMap<String, Company>();
        company = getCompany();
        companyMap.put(company.getId(), company);
        return companyMap;
    }

    protected CompanyUpdateRequest getCompanyUpdateRequest() {
        CompanyUpdateRequest companyUpdateRequest = new CompanyUpdateRequest();
        populateCompany(companyUpdateRequest);
        return companyUpdateRequest;
    }

    protected CompanyEntity getCompanyEntity() {
        CompanyEntity companyEntity = new CompanyEntity();
        companyEntity.setCompanyName(COMPANY_NAME);
        companyEntity.setAbn(COMPANY_ABN);
        companyEntity.setAddress(COMPANY_ADDRESS);
        companyEntity.setParentId(UUID.fromString(COMPANY_PARENT_ID));
        return companyEntity;
    }

    protected CompaniesGetResponse getCompaniesGetResponse() {
        CompaniesGetResponse CompaniesGetResponse = new CompaniesGetResponse();
        CompaniesGetResponse.setCompanies(getCompanies());
        return CompaniesGetResponse;

    }

    protected List<Company> getCompanies() {
        List<Company> Companies = new ArrayList<Company>();
        Companies.add(getCompany());
        return Companies;
    }

}