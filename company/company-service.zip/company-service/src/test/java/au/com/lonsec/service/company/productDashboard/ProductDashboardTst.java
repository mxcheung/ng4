package au.com.lonsec.service.company.productDashboard;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import au.com.lonsec.service.company.domain.DomainStereotypeUtil;
import au.com.lonsec.service.company.product.ProductEntity;
import au.com.lonsec.service.company.product.client.model.ProductAddRequest;
import au.com.lonsec.service.company.product.client.model.ProductGetRequest;
import au.com.lonsec.service.company.product.client.model.ProductGetResponse;
import au.com.lonsec.service.company.product.client.model.ProductRequest;
import au.com.lonsec.service.company.product.client.model.ProductUpdateRequest;
import au.com.lonsec.service.company.product.client.model.ProductsGetResponse;
import au.com.lonsec.service.company.product.model.Product;
import au.com.lonsec.service.company.productClassification.model.ProductClassification;
import au.com.lonsec.service.company.productDashboard.client.model.ProductDashboardRowsGetResponse;
import au.com.lonsec.service.company.productDashboard.model.ProductDashboardRow;
import au.com.lonsec.service.company.segment.model.Segment;

public abstract class ProductDashboardTst {

    private static final String SECTOR_LEAD = "SectorLead";
    private static final String RESEARCH_PLAN = "ResearchPlan";
    protected static final String ID = "81dd92a4-be95-47ca-9922-12f29c05da8c";
    protected static final UUID PRODUCT_UUID = UUID.fromString(ID);

    protected static final String SEGMENT_CD = "SR";
    protected static final String EXT_UNIQUE_KEY = "276";

    protected static final String SEGMENT_UUID = "126be751-86ee-454f-bcce-4752df2c5594";
    protected static final String PRODUCT_NAME = "Sunsuper for Life - Conservative";
    protected static final String PRODUCT_ID = "    MF-1-31215";
    protected static final String APIR_CODE = "APIR";
    protected static final String PRODUCT_TYPE = "productType";
    protected static final String NOTES = "notes";

    protected static final String ANALYST = "analyst";
    protected static final String COMPANY_ABN = "12345678901";
    protected static final String COMPANY_NAME = "Company_Name";
    protected static final String COMPANY_ID = "523be751-86ee-454f-bcce-4752df2c1234";

    protected static final String ASX_CODE = "ASX";
    protected static final String ASSET_CLASS_CODE = "AEQ";
    protected static final String ASSET_CLASS_NAME = "Australian Equities";
    protected static final String SECTOR_CODE = "AEQ:ASC";
    protected static final String SECTOR_NAME = "Australian Smaller Companies";
    protected static final String SUB_SECTOR_CODE = "SC";
    protected static final String SUB_SECTOR_NAME = "Small Cap";
    protected static final String PRODUCT_CLASS_CODE = "MF";
    protected static final String PRODUCT_CLASS_NAME = "Managed Fund";
    
    protected ProductDashboardDTO productDashboardDTO;
    protected ProductDashboardRow productDashboardRow;
    protected Product product;
    protected Segment segment;
    protected ProductClassification productClassification;
    protected ProductEntity productEntity;
    protected ProductAddRequest productAddRequest;
    protected ProductGetRequest productGetRequest;
    protected ProductUpdateRequest productUpdateRequest;
    protected ProductsGetResponse productsGetResponse;
    protected ProductGetResponse productGetResponse;
    protected ProductDashboardRowsGetResponse productDashboardRowsGetResponse;

    protected Date today = new Date();
    protected List<Product> products;
    protected List<ProductEntity> productEntityList;
    protected List<ProductDashboardRow> productDashboardRows;
    protected Map<String, Map<String, String>> lookups;

    public ProductDashboardTst() {
        super();
    }

    protected ProductDashboardRowsGetResponse getProductDashboardRowsGetResponse() {
        ProductDashboardRowsGetResponse productDashboardRowsGetResponse = new ProductDashboardRowsGetResponse();
        productDashboardRowsGetResponse.setProductDashboardRows(getProductDashboardRows());
        return productDashboardRowsGetResponse;
    }

    protected List<ProductDashboardRow> getProductDashboardRows() {
        List<ProductDashboardRow> products = new ArrayList<ProductDashboardRow>();
        products.add(getProductDashboardRow());
        return products;
    }
    
    protected static Map<String, Map<String, String>> getLookUps() {
        return DomainStereotypeUtil.getLookUps();
    }    

    public static ProductDashboardDTO getProductDashboardDTO() {
        ProductDashboardDTO productDashboardDTO = new ProductDashboardDTO();
        productDashboardDTO.setProduct(getProduct());
        productDashboardDTO.setSegment(getSegment());
        productDashboardDTO.setProductClassification(getProductClassification());
        return productDashboardDTO;
    }

    public static ProductDashboardRow getProductDashboardRow() {
        ProductDashboardRow product = new ProductDashboardRow();
        product.setId(ID);
        product.setSegmentId(SEGMENT_UUID);
        product.setProductName(PRODUCT_NAME);
        product.setProductId(PRODUCT_ID);
        product.setSegmentCd(SEGMENT_CD);
        product.setExtUniqueKey(EXT_UNIQUE_KEY);
        product.setProductType(PRODUCT_TYPE);
        product.setResearchPlan(RESEARCH_PLAN);
        product.setSectorLead(SECTOR_LEAD);
        product.setNotes(NOTES);
        product.setCompanyName(COMPANY_NAME);
        product.setAnalyst(ANALYST);

        product.setProductName(PRODUCT_NAME);
        product.setApirCd(APIR_CODE);
        product.setAsxCd(ASX_CODE);
        product.setAssetClassCd(ASSET_CLASS_CODE);
        product.setAssetClassName(ASSET_CLASS_NAME);
        product.setProductClassCd(PRODUCT_CLASS_CODE);
        product.setProductClassName(PRODUCT_CLASS_NAME);
        product.setSectorCd(SECTOR_CODE);
        product.setSectorName(SECTOR_NAME);
        product.setSubSectorCd(SUB_SECTOR_CODE);
        product.setSubSectorName(SUB_SECTOR_NAME);
        return product;
    }

    protected static Segment getSegment() {
        return DomainStereotypeUtil.getSegment();
    }

    public static Product getProduct() {
        return DomainStereotypeUtil.getProduct();
    }

    protected static ProductClassification getProductClassification() {
        return DomainStereotypeUtil.getProductClassification();
    }

    private ProductRequest populateProduct(ProductRequest productRequest) {
        productRequest.setApirCd(APIR_CODE);
        productRequest.setProductId(PRODUCT_ID);
        productRequest.setProductName(PRODUCT_NAME);
        productRequest.setSegmentId(SEGMENT_UUID);
        productRequest.setSegmentCd(SEGMENT_CD);
        productRequest.setExtUniqueKey(EXT_UNIQUE_KEY);
        productRequest.setProductType(PRODUCT_TYPE);
        productRequest.setResearchPlan(RESEARCH_PLAN);
        productRequest.setSectorLead(SECTOR_LEAD);
        productRequest.setNotes(NOTES);
        return productRequest;
    }

    protected ProductAddRequest getProductAddRequest() {
        ProductAddRequest productAddRequest = new ProductAddRequest();
        populateProduct(productAddRequest);
        return productAddRequest;
    }

    protected ProductGetRequest getProductGetRequest() {
        ProductGetRequest productGetRequest = new ProductGetRequest();
        populateProduct(productGetRequest);
        return productGetRequest;
    }

    protected ProductUpdateRequest getProductUpdateRequest() {
        ProductUpdateRequest productUpdateRequest = new ProductUpdateRequest();
        productUpdateRequest.setId(ID);
        populateProduct(productUpdateRequest);
        return productUpdateRequest;
    }

    protected ProductEntity getProductEntity() {
        return DomainStereotypeUtil.getProductEntity();
    }

    protected List<ProductEntity> getProductEntityList() {
        List<ProductEntity> productEntityList = new ArrayList<ProductEntity>();
        productEntityList.add(getProductEntity());
        return productEntityList;
    }

    protected ProductGetResponse getProductGetResponse() {
        ProductGetResponse productGetResponse = new ProductGetResponse();
        productGetResponse.setProduct(getProduct());
        return productGetResponse;
    }

    protected ProductsGetResponse getProductsGetResponse() {
        ProductsGetResponse productsGetResponse = new ProductsGetResponse();
        productsGetResponse.setProducts(getProducts());
        return productsGetResponse;
    }

    protected List<Product> getProducts() {
        List<Product> Products = new ArrayList<Product>();
        Products.add(getProduct());
        return Products;
    }

    protected void verifyProductDashboardRow(ProductDashboardRow product) {
        assertEquals(PRODUCT_NAME, product.getProductName());
        assertEquals(PRODUCT_ID, product.getProductId());
        assertEquals(APIR_CODE, product.getApirCd());
        assertEquals(SEGMENT_UUID, product.getSegmentId());
        assertEquals(PRODUCT_TYPE, product.getProductType());
        assertEquals(NOTES, product.getNotes());
    }
    
    

    
    protected void verifyProductClassification(ProductDashboardRow productClassification) {
        assertEquals(PRODUCT_ID, productClassification.getProductId());
        assertEquals(ASX_CODE, productClassification.getAsxCd());
        assertEquals(APIR_CODE, productClassification.getApirCd());
        assertEquals(PRODUCT_NAME, productClassification.getProductName());
        assertEquals(ASSET_CLASS_NAME, productClassification.getAssetClassName());
        assertEquals(SECTOR_NAME, productClassification.getSectorName());
        assertEquals(SUB_SECTOR_NAME, productClassification.getSubSectorName());
        assertEquals(PRODUCT_CLASS_NAME, productClassification.getProductClassName());
    }

    protected void verifySegment(ProductDashboardRow segment) {
        assertEquals(ANALYST, segment.getAnalyst());
        assertEquals(EXT_UNIQUE_KEY, segment.getExtUniqueKey());
        assertEquals(COMPANY_NAME, segment.getCompanyName());
    }

    protected void verifyEmptySegment(ProductDashboardRow segment) {
        assertNull( segment.getAnalyst());
        assertNull( segment.getCompanyName());
    }
    
    protected void verifyEmptyProductClassification(ProductDashboardRow productClassification) {
        assertNull( productClassification.getAsxCd());
        assertNull( productClassification.getAssetClassName());
        assertNull( productClassification.getSectorName());
        assertNull( productClassification.getSubSectorName());
        assertNull( productClassification.getProductClassName());
    }

    
    
    protected void verifyProduct(Product product) {
        assertEquals(PRODUCT_NAME, product.getProductName());
        assertEquals(PRODUCT_ID, product.getProductId());
        assertEquals(APIR_CODE, product.getApirCd());
        assertEquals(SEGMENT_UUID, product.getSegmentId());
        assertEquals(PRODUCT_TYPE, product.getProductType());
        assertEquals(NOTES, product.getNotes());
    }

    protected void verifyProduct(ProductEntity product) {
        assertEquals(PRODUCT_NAME, product.getProductName());
        assertEquals(PRODUCT_ID, product.getProductId());
        assertEquals(APIR_CODE, product.getApirCd());
        assertEquals(SEGMENT_UUID, product.getSegmentId());
        assertEquals(PRODUCT_TYPE, product.getProductType());
        assertEquals(NOTES, product.getNotes());
    }
}