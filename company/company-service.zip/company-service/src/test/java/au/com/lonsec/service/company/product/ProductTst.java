package au.com.lonsec.service.company.product;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import au.com.lonsec.service.company.domain.DomainStereotypeUtil;
import au.com.lonsec.service.company.product.client.model.ProductAddRequest;
import au.com.lonsec.service.company.product.client.model.ProductGetRequest;
import au.com.lonsec.service.company.product.client.model.ProductGetResponse;
import au.com.lonsec.service.company.product.client.model.ProductRequest;
import au.com.lonsec.service.company.product.client.model.ProductUpdateRequest;
import au.com.lonsec.service.company.product.client.model.ProductsGetResponse;
import au.com.lonsec.service.company.product.model.Product;

public abstract class ProductTst {

    private static final String ACTIVE = "ACTIVE";
    private static final String INACTIVE = "INACTIVE";
    private static final String SECTOR_LEAD = "SectorLead";
    private static final String RESEARCH_PLAN = "ResearchPlan";
    protected static final String ID = "81dd92a4-be95-47ca-9922-12f29c05da8c";
    protected static final UUID PRODUCT_UUID = UUID.fromString(ID);

    protected static final String SEGMENT_CD = "SR";
    protected static final String EXT_UNIQUE_KEY = "276";

    protected static final String SEGMENT_UUID = "126be751-86ee-454f-bcce-4752df2c5594";
    protected static final String PRODUCT_NAME = "Sunsuper for Life - Conservative";
    protected static final String PRODUCT_ID = "    MF-1-31215";
    protected static final String APIR_CODE = "APIR";
    protected static final String PRODUCT_TYPE = "productType";
    protected static final String NOTES = "notes";
    
    protected static final String ASX_CODE = "ASX";
    protected static final String ASSET_CLASS_CODE = "AE";
    protected static final String ASSET_CLASS_NAME = "Australian Equities";
    protected static final String SECTOR_NAME = "Australian Smaller Companies";
    protected static final String SECTOR_CODE = "ASC";
    protected static final String SUB_SECTOR_NAME = "Small Cap";
    protected static final String SUB_SECTOR_CODE = "SC";
    protected static final String PRODUCT_CLASS_NAME = "Managed Fund";
    protected static final String PRODUCT_CLASS_CODE = "MF";
    
    
    protected Product product;
    protected ProductEntity productEntity;
    protected ProductAddRequest productAddRequest;
    protected ProductGetRequest productGetRequest;
    protected ProductUpdateRequest productUpdateRequest;
    protected ProductsGetResponse productsGetResponse;
    protected ProductGetResponse productGetResponse;

    protected Date today = new Date();
    protected List<Product> products;
    protected List<ProductEntity> productEntityList;

    public ProductTst() {
        super();
    }

    protected Product getProduct() {
        return DomainStereotypeUtil.getProduct();
    }

    private ProductRequest populateProduct(ProductRequest productRequest) {
        productRequest.setApirCd(APIR_CODE);
        productRequest.setProductId(PRODUCT_ID);
        productRequest.setProductName(PRODUCT_NAME);
        productRequest.setSegmentId(SEGMENT_UUID);
        productRequest.setSegmentCd(SEGMENT_CD);
        productRequest.setExtUniqueKey(EXT_UNIQUE_KEY);
        productRequest.setProductType(PRODUCT_TYPE);
        productRequest.setResearchPlan(RESEARCH_PLAN);
        productRequest.setSectorLead(SECTOR_LEAD);
        productRequest.setNotes(NOTES);
        return productRequest;
    }

    protected ProductAddRequest getProductAddRequest() {
        ProductAddRequest productAddRequest = new ProductAddRequest();
        populateProduct(productAddRequest);
        return productAddRequest;
    }

    protected ProductGetRequest getProductGetRequest() {
        ProductGetRequest productGetRequest = new ProductGetRequest();
        populateProduct(productGetRequest);
        return productGetRequest;
    }

    protected ProductUpdateRequest getProductUpdateRequest() {
        ProductUpdateRequest productUpdateRequest = new ProductUpdateRequest();
        productUpdateRequest.setId(ID);
        populateProduct(productUpdateRequest);
        return productUpdateRequest;
    }

    protected ProductEntity getProductEntity() {
        return DomainStereotypeUtil.getProductEntity();

    }

    protected List<ProductEntity> getProductEntityList() {
        List<ProductEntity> productEntityList = new ArrayList<ProductEntity>();
        productEntityList.add(getProductEntity());
        return productEntityList;
    }

    protected ProductGetResponse getProductGetResponse() {
        ProductGetResponse productGetResponse = new ProductGetResponse();
        productGetResponse.setProduct(getProduct());
        return productGetResponse;
    }

    protected ProductsGetResponse getProductsGetResponse() {
        ProductsGetResponse productsGetResponse = new ProductsGetResponse();
        productsGetResponse.setProducts(getProducts());
        return productsGetResponse;
    }

    protected List<Product> getProducts() {
        List<Product> Products = new ArrayList<Product>();
        Products.add(getProduct());
        return Products;
    }

    protected void verifyProduct(Product product) {
        assertEquals(PRODUCT_NAME, product.getProductName());
        assertEquals(PRODUCT_ID, product.getProductId());
        assertEquals(APIR_CODE, product.getApirCd());
        assertEquals(SEGMENT_UUID, product.getSegmentId());
        assertEquals(PRODUCT_TYPE, product.getProductType());
        assertEquals(NOTES, product.getNotes());
        assertTrue(product.getActive());
    }

    protected void verifyProduct(ProductEntity product) {
        assertEquals(PRODUCT_NAME, product.getProductName());
        assertEquals(PRODUCT_ID, product.getProductId());
        assertEquals(SEGMENT_UUID, product.getSegmentId());
        assertEquals(PRODUCT_TYPE, product.getProductType());
        assertEquals(NOTES, product.getNotes());
    }
    
    protected void verifyProductClassification(ProductEntity product) {
        assertEquals(APIR_CODE, product.getApirCd());
        assertEquals(ASX_CODE, product.getAsxCd());
        assertEquals(ASSET_CLASS_CODE, product.getAssetClassCd());
        assertEquals(SECTOR_CODE, product.getSectorCd());
        assertEquals(SUB_SECTOR_CODE, product.getSubSectorCd());
        assertEquals(PRODUCT_CLASS_CODE, product.getProductClassCd());
    }
    
    
}