package au.com.lonsec.service.company.util;

import java.io.IOException;
import java.util.List;
import java.util.function.Consumer;

import org.antlr.stringtemplate.StringTemplate;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ProductSQLTest extends SqlTst {

    private static final Logger LOGGER = LoggerFactory.getLogger(ProductSQLTest.class);

    private static final String DATA_FILE = "dataload/product-setup.csv";
    
    private static final String MSSQL = 
            "IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='$segmentcd$' AND product_id = '$productId$' )\n"
            + "BEGIN\n"
            + "    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)\n" 
            + "    values ( NEWID(), getdate(),  getdate(), 1, '$segmentcd$', '$productId$','$productName$', '$productType$', '$extuniquekey$','$extuniquekey$','$sectorLead$','$researchPlan$')\n"
            + "END;\n\n";
                    

    private static final String H2SQL = "merge into PRODUCT(ID, INSERT_DATE, LAST_MODIFIED, ACTIVE, SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN ) "
            + "    VALUES (RANDOM_UUID(), CURRENT_TIMESTAMP,  CURRENT_TIMESTAMP, 1, '$segmentcd$', '$productId$','$productName$', '$productType$','$extuniquekey$','$extuniquekey$','$sectorLead$','$researchPlan$' ); \n";

    private static final StringTemplate H2Template = new StringTemplate(H2SQL);
    private static final StringTemplate MSSQLTemplate = new StringTemplate(MSSQL);

    @Test
    public void shouldGenerateMSSQL() throws IOException {
        generateScript(DATA_FILE, MSSQLTemplate);
    }

    @Test
    public void shouldGenerateH2SQL() throws IOException {
        generateScript(DATA_FILE, H2Template);
    }

    private void generateScript(String filename, StringTemplate template) throws IOException {
        StringBuilder result = new StringBuilder();
        result.append(NEWLINE + LINE_SEPARATER + NEWLINE);
        Consumer<List<String>> consumer = getConsumer(template, result);
        List<List<String>> rawvalues = readcsv(getResourceFilePath(filename));
        rawvalues.forEach(consumer);
        LOGGER.info(result.toString());
    }


    private Consumer<List<String>> getConsumer(StringTemplate template, StringBuilder builder) {
        Consumer<List<String>> consumer = product -> {
            String productId = product.get(0);
            String productName = product.get(1);
            String extuniquekey = product.get(2);
            String productType = product.get(3);
            String sectorLead = product.get(4);
            String researchPlan = product.get(5);
            String segmentcd = product.get(6);
            template.reset();
            template.setAttribute("productId", productId);
            template.setAttribute("extuniquekey", extuniquekey);
            template.setAttribute("productName", productName);
            template.setAttribute("productType", productType);
            template.setAttribute("sectorLead", sectorLead);
            template.setAttribute("researchPlan", researchPlan);
            template.setAttribute("segmentcd", segmentcd);
            builder.append(template.toString());
        };
        return consumer;
    }


}