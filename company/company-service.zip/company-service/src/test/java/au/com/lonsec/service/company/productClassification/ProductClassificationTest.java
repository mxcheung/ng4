package au.com.lonsec.service.company.productClassification;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;

import org.codehaus.jettison.json.JSONException;
import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.lonsec.service.company.productClassification.model.ProductClassification;

public class ProductClassificationTest extends ProductClassificationTst {

    private final static String JSON_STRING = "{\"productId\":\"MF-1-31215\",\"apirCd\":\"MAQ0061AU\",\"asxCd\":\"ASX\",\"productName\":\"BetaShares Australian Small Companies Select Fund\",\"assetClassName\":\"AEQ\",\"sectorName\":\"AEQ:ALP\",\"subSectorName\":\"AEQ:ALP:AR\",\"productClassName\":\"ETF\"}";

    private ObjectMapper mapper;

    @Before
    public void setup() {
        mapper = new ObjectMapper();
    }

    @Test
    public void shouldSerialize() throws JsonProcessingException {
        ProductClassification lookupValue = getProductClassification();
        String json = this.mapper.writeValueAsString(lookupValue);
        assertEquals(JSON_STRING, json);
    }

    @Test
    public void shouldDeserialize() throws JSONException, JsonParseException, JsonMappingException, IOException {
        ProductClassification productClassification = mapper.readValue(JSON_STRING, ProductClassification.class);
        assertEquals(PRODUCT_ID, productClassification.getProductId());
        assertEquals(APIR_CODE, productClassification.getApirCd());
        assertEquals(ASX_CODE, productClassification.getAsxCd());
        assertEquals(PRODUCT_NAME, productClassification.getProductName());
        assertEquals(ASSET_CLASS_CD, productClassification.getAssetClassName());
        assertEquals(SECTOR_CD, productClassification.getSectorName());
        assertEquals(SUB_SECTOR_CD, productClassification.getSubSectorName());
        assertEquals(PRODUCT_CLASS_NAME, productClassification.getProductClassName());

    }
    
    
    @Test
    public void testConstructorIsPrivate() throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
        Constructor<ProductClassificationURI> constructor = ProductClassificationURI.class.getDeclaredConstructor();
        assertTrue(Modifier.isPrivate(constructor.getModifiers()));
        constructor.setAccessible(true);
        constructor.newInstance();
    }

}