package au.com.lonsec.service.company.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SqlTst {

    protected static final String NEWLINE = "\n";
    protected static final String LINE_SEPARATER = "=================";

    private static final Logger LOGGER = LoggerFactory.getLogger(SqlTst.class);

    public SqlTst() {
        super();
    }

    protected List<List<String>> readcsv(String fileName) throws IOException {
        return readcsv(fileName, true);
    }

    protected List<List<String>> readcsv(String fileName, boolean dupcheck) throws IOException {
        try (Stream<String> lines = Files.lines(Paths.get(fileName))) {
            List<List<String>> values = lines.map(line -> Arrays.asList(line.split(","))).collect(Collectors.toList());
            return dupcheck ? checkdupes(values) : values;
        }
    }

    protected String getResourceFilePath(String filename) {
        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource(filename).getFile());
        return file.getAbsolutePath();
    }

    protected List<List<String>> checkdupes(List<List<String>> values) {
        Set<String> keys = new HashSet<String>();
        List<List<String>> filteredList = new ArrayList<List<String>>();
        for (List<String> value : values) {
            String uniqueKey = value.get(0);
            if (!keys.contains(uniqueKey)) {
                keys.add(uniqueKey);
                filteredList.add(value);
            } else {
                LOGGER.info("Skipping Duplicate:" + value);
            }
        }
        return filteredList;
    }

}