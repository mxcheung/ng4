package au.com.lonsec.service.company.segment;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;

import org.codehaus.jettison.json.JSONException;
import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.lonsec.service.company.segment.model.Segment;

public class SegmentTest extends SegmentTst {

    private final static String JSON_STRING = "{\"companyId\":\"523be751-86ee-454f-bcce-4752df2c1234\",\"segmentCd\":\"SR\",\"extUniqueKey\":\"276\",\"analyst\":\"analyst\",\"abn\":\"12345678901\",\"active\":true,\"companyName\":\"Company_Name\"}";

    private ObjectMapper mapper;

    @Before
    public void setup() {
        mapper = new ObjectMapper();
    }

    @Test
    public void shouldSerialize() throws JsonProcessingException {
        Segment segment = getSegment();
        String json = this.mapper.writeValueAsString(segment);
        assertEquals(JSON_STRING, json);
    }

    @Test
    public void shouldDeserialize() throws JSONException, JsonParseException, JsonMappingException, IOException {
        Segment segment = mapper.readValue(JSON_STRING, Segment.class);
        assertEquals(COMPANY_ID, segment.getCompanyId());
        assertEquals(ANALYST, segment.getAnalyst());
        assertEquals(EXT_UNIQUE_KEY, segment.getExtUniqueKey());
        assertEquals(COMPANY_ABN, segment.getAbn());
    }

    @Test
    public void testConstructorIsPrivate() throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
        Constructor<SegmentURI> constructor = SegmentURI.class.getDeclaredConstructor();
        assertTrue(Modifier.isPrivate(constructor.getModifiers()));
        constructor.setAccessible(true);
        constructor.newInstance();
    }

}