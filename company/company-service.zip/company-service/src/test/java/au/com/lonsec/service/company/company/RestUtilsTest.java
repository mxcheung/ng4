package au.com.lonsec.service.company.company;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.UUID;

import org.junit.Test;

public class RestUtilsTest {

    protected static final String SEGMENT_UUID = "126be751-86ee-454f-bcce-4752df2c5594";

    @Test
    public void shouldconvertUUID() {
        UUID id = RestUtils.convertUUID(SEGMENT_UUID);
        assertEquals(SEGMENT_UUID, id.toString());
        assertNull(RestUtils.convertUUID(null));
    }

}