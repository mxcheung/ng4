package au.com.lonsec.service.company.util;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

import org.antlr.stringtemplate.StringTemplate;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import au.com.lonsec.service.company.configproperty.ConfigPropertyType;

public class CompanyQuestionnaireSQLTest extends SqlTst {

    private static final Logger LOGGER = LoggerFactory.getLogger(CompanyQuestionnaireSQLTest.class);

    private static final String DATALOAD_COMPANY_SETUP_CSV = "dataload/company-questionnaire-setup.csv";
    private static final String MSSQL = "IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '$entityId$' and property_key= '$propertyKey$' ) \n " + "BEGIN \n"
            + "   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) \n"
            + "   values (NEWID(), '$properyType$', $entityId$,'$propertyKey$', 'true', getdate(), getdate()) \n " + "END; \n" + " \n";

    private static final String H2SQL = "merge into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) "
            + " values (RANDOM_UUID(), '$properyType$', $entityId$,'$propertyKey$', 'true', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP) " + "; \n";

    private static final StringTemplate H2Template = new StringTemplate(H2SQL);
    private static final StringTemplate MSSQLTemplate = new StringTemplate(MSSQL);
    private Map<String, String> qmap = getQuestionnaireMap();

    @Test
    public void shouldGenerateMSSQL() throws IOException {
        generateScript(DATALOAD_COMPANY_SETUP_CSV, MSSQLTemplate);
    }

    @Test
    public void shouldGenerateH2SQL() throws IOException {
        generateScript(DATALOAD_COMPANY_SETUP_CSV, H2Template);
    }

    private void generateScript(String filename, StringTemplate template) throws IOException {
        StringBuilder result = new StringBuilder();
        result.append(NEWLINE + LINE_SEPARATER + NEWLINE);
        Consumer<List<String>> consumerCompany = getCompanyConsumer(template, result);
        List<List<String>> rawvalues = readcsv(getResourceFilePath(filename),false);
        rawvalues.forEach(consumerCompany);
        LOGGER.info(result.toString());
    }


    private Consumer<List<String>> getCompanyConsumer(StringTemplate template, StringBuilder builder) {
        Consumer<List<String>> consumerCompany = company -> {
            String entityId = company.get(0);
            String propertyKey = company.get(1).replace("\"", "");
            propertyKey =  questionnaireType(propertyKey);
            template.reset();
            template.setAttribute("entityId", entityId);
            template.setAttribute("propertyKey", propertyKey);
            template.setAttribute("properyType", ConfigPropertyType.SEGMENT.ordinal());
            builder.append(template.toString());
        };
        return consumerCompany;
    }
    
    
    private String questionnaireType(String qtype) {
        return qmap.get(qtype);
    }

    private Map<String, String> getQuestionnaireMap() {
        Map<String, String> qmap  = new HashMap<String, String>();
        qmap.put("annual", "ANNUAL");
        qmap.put("month", "MONTH");
        qmap.put("infinity", "INFINITY");
        qmap.put("kiwi", "KIWISAVER");
        qmap.put("quart", "QUARTER");
        return qmap;
    }


}