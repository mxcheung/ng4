package au.com.lonsec.service.company.companyDashboard;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import au.com.lonsec.service.company.companyDashboard.model.CompanyDashboardRow;
import au.com.lonsec.service.company.configproperty.ConfigPropertyService;
import au.com.lonsec.service.company.segment.SegmentNotFoundException;
import au.com.lonsec.service.company.segment.SegmentService;

@RunWith(MockitoJUnitRunner.class)
public class CompanyDashboardServiceTest extends CompanyDashboardTst {

    private CompanyDashboardService companyDashboardService;

    @Mock
    private SegmentService segmentService;

    @Mock
    private  ConfigPropertyService configPropertyService;


    @Mock
    private CompanyDashboardMapper companyDashboardMapper;

    
    @Before
    public void setup() {
        companyDashboardDTO = getCompanyDashboardDTO();
        segment = getSegment();
        segments = getSegments();
        companyDashboardRow = getCompanyDashboardRow();
        companyDashboardService = new CompanyDashboardService(segmentService, configPropertyService,  companyDashboardMapper);
    }

    @Test
    public void shouldFindCompanys() throws SegmentNotFoundException {
        when(segmentService.findSegment(SEGMENT_CD)).thenReturn(segments);
        when(companyDashboardMapper.map(any(CompanyDashboardDTO.class), any(CompanyDashboardRow.class))).thenReturn(companyDashboardRow);
        List<CompanyDashboardRow> result = companyDashboardService.findCompanies(SEGMENT_CD);
        assertEquals(1, result.size());
        verifyCompanyDashboardRow(result.get(0));
    }


}