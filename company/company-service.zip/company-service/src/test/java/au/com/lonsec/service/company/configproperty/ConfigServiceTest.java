package au.com.lonsec.service.company.configproperty;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class ConfigServiceTest {

    private static final String VALUE1 = "Value1";
    private static final String KEY1 = "Key1";
    private static final String ENTITY_ID = "126be751-86ee-454f-bcce-4752df2c5594";

    private ConfigPropertyService configPropertyService;

    List<ConfigProperty> newPropertyList;
    List<ConfigProperty> existingPropertyList;

    @Mock
    private ConfigPropertyRepository configPropertyRepository;

    @Before
    public void setup() {
        configPropertyService = new ConfigPropertyServiceImpl(configPropertyRepository);
        newPropertyList = generatePreferences();
        existingPropertyList = generatePreferences();
    }

    @Test
    public void shouldUpdateEntityProperties() {
        List<ConfigPropertyEntity> existingConfig = getSingleEntityList();
        ConfigPropertyEntity configPropertyEntity = existingConfig.get(0);
        when(configPropertyRepository.findByEntityIdAndPropertyType(ENTITY_ID, ConfigPropertyType.COMPANY)).thenReturn(existingConfig);
        when(configPropertyRepository.findByEntityIdAndPropertyTypeAndPropertyKey(ENTITY_ID, ConfigPropertyType.COMPANY, KEY1))
                .thenReturn(configPropertyEntity);

        configPropertyService.updateEntityProperties(configPropertyEntity.getEntityId(), ConfigPropertyType.COMPANY, newPropertyList);
        verify(configPropertyRepository, times(1)).findByEntityIdAndPropertyTypeAndPropertyKey(ENTITY_ID, ConfigPropertyType.COMPANY, KEY1);
        verify(configPropertyRepository, times(1)).save(configPropertyEntity);
        verifyNoMoreInteractions(configPropertyRepository);
    }

    @Test
    public void shouldAddNewEntityProperties() {
        when(configPropertyRepository.findByEntityIdAndPropertyType(ENTITY_ID, ConfigPropertyType.COMPANY)).thenReturn(getEmptyEntityList());
        when(configPropertyRepository.findByEntityIdAndPropertyTypeAndPropertyKey(ENTITY_ID, ConfigPropertyType.COMPANY, KEY1)).thenReturn(null);

        configPropertyService.updateEntityProperties(ENTITY_ID, ConfigPropertyType.COMPANY, newPropertyList);
        verify(configPropertyRepository, times(1)).findByEntityIdAndPropertyTypeAndPropertyKey(ENTITY_ID, ConfigPropertyType.COMPANY, KEY1);
        verify(configPropertyRepository, times(1)).save(any(ConfigPropertyEntity.class));
        verifyNoMoreInteractions(configPropertyRepository);
    }

    @Test
    public void shouldFetchEntityProperties() {
        List<ConfigPropertyEntity> existingConfig = getSingleEntityList();
        when(configPropertyRepository.findByEntityIdAndPropertyType(ENTITY_ID, ConfigPropertyType.COMPANY)).thenReturn(existingConfig);
        List<ConfigProperty> result = configPropertyService.getEntityProperties(ENTITY_ID, ConfigPropertyType.COMPANY);
        assertEquals(1, result.size());
        verify(configPropertyRepository, times(1)).findByEntityIdAndPropertyType(ENTITY_ID, ConfigPropertyType.COMPANY);
        verifyNoMoreInteractions(configPropertyRepository);
    }

    private List<ConfigPropertyEntity> getSingleEntityList() {
        List<ConfigPropertyEntity> ret = new ArrayList<ConfigPropertyEntity>();
        ret.add(getConfigPropertyEntity());
        return ret;
    }

    private List<ConfigPropertyEntity> getEmptyEntityList() {
        return new ArrayList<ConfigPropertyEntity>();
    }

    private ConfigPropertyEntity getConfigPropertyEntity() {
        ConfigPropertyEntity configPropertyEntity = new ConfigPropertyEntity();
        configPropertyEntity.setEntityId(ENTITY_ID);
        configPropertyEntity.setPropertyKey(KEY1);
        configPropertyEntity.setPropertyType(ConfigPropertyType.COMPANY);
        return configPropertyEntity;
    }

    private List<ConfigProperty> generatePreferences() {
        List<ConfigProperty> properties = new ArrayList<ConfigProperty>();
        ConfigProperty configProperty = new ConfigProperty();
        configProperty.setKey(KEY1);
        configProperty.setValue(VALUE1);
        configProperty.setType(ConfigPropertyType.COMPANY);
        properties.add(configProperty);
        return properties;
    }

}