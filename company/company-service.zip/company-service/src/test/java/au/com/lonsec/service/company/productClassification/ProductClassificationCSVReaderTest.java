package au.com.lonsec.service.company.productClassification;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLDecoder;
import java.util.ArrayList;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.RuntimeJsonMappingException;

import au.com.lonsec.service.company.AppProperties;

public class ProductClassificationCSVReaderTest extends ProductClassificationTst {

    private ProductClassificationCSVReader productClassificationCSVReader;
    private AppProperties appProperties;
    
    private static final File resourcesDirectory = new File("src/test/resources/");
    
    
    @Before
    public void setup() {
        
        appProperties = new AppProperties();
        appProperties.setLookupFolder(resourcesDirectory.getAbsolutePath() + "//");
        
        productClassificationCSVReader = new ProductClassificationCSVReader(appProperties);
    }

    @Test(expected = FileNotFoundException.class)
    public void shouldThrowFileNotFoundExceptionWhenReadInvalidProductClassificationFile() throws FileNotFoundException, IOException {
        ArrayList<ProductClassificationRow> ProductClassificationRows = productClassificationCSVReader.readProductClassification("NonExistentFile");
        assertEquals(2, ProductClassificationRows.size());
    }

    @Test(expected = RuntimeJsonMappingException.class)
    public void shouldThrowExceptionReadInvalidProductClassificationFile() throws FileNotFoundException, IOException {
        InputStream inputStream = getInputStream("productClassification-invalid-file.txt");
        productClassificationCSVReader.readProductClassification(inputStream);
    }

    @Test(expected = IOException.class)
    public void shouldThrowIOExceptionReadInvalidProductClassificationFile() throws FileNotFoundException, IOException {
        productClassificationCSVReader.readProductClassification("actually_a_directory.csv");
    }


    @Test
    public void shouldReadLookupFromFile() throws JsonProcessingException, FileNotFoundException, IOException {
        ArrayList<ProductClassificationRow> rows = productClassificationCSVReader.readProductClassification(ProductClassification_CSV);
        assertEquals(2, rows.size());
    }

    
    @Test
    public void shouldReadProductClassificationInputStream() throws JsonProcessingException, FileNotFoundException, IOException {
 
        InputStream inputStream = getInputStream(ProductClassification_CSV);
        ArrayList<ProductClassificationRow> productClassificationRows = productClassificationCSVReader
                .readProductClassification(inputStream);
        assertEquals(2, productClassificationRows.size());
    }

    @Ignore
    @Test
    public void shouldReadProductClassificationFileFromFileSystem() throws JsonProcessingException, FileNotFoundException, IOException {
        ArrayList<ProductClassificationRow> ProductClassificationRows = productClassificationCSVReader
                .readProductClassification("E:\\csv\\ProductClassification.csv");
        assertEquals(12, ProductClassificationRows.size());
    }
    
    private InputStream getInputStream(String lookupFileName) throws FileNotFoundException, UnsupportedEncodingException {
        URL url = getClass().getClassLoader().getResource(lookupFileName);
        File lookupFile = new File(URLDecoder.decode(url.getFile(), "UTF-8"));
        InputStream inputStream = new FileInputStream(lookupFile);
        return inputStream;
    }

}