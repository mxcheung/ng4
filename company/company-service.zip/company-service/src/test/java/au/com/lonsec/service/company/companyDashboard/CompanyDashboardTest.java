package au.com.lonsec.service.company.companyDashboard;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;

import org.codehaus.jettison.json.JSONException;
import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.lonsec.service.company.companyDashboard.model.CompanyDashboardRow;


public class CompanyDashboardTest extends CompanyDashboardTst {

    private final static String JSON_STRING = "{\"companyId\":\"523be751-86ee-454f-bcce-4752df2c1234\",\"segmentCd\":\"SR\",\"extUniqueKey\":\"276\",\"analyst\":\"analyst\",\"abn\":\"12345678901\",\"active\":true,\"attributes\":[{\"key\":\"Key1\",\"value\":\"Value1\"}],\"id\":\"81dd92a4-be95-47ca-9922-12f29c05da8c\",\"companyName\":\"Company_Name\",\"notes\":\"notes\"}";

    private ObjectMapper mapper;

    @Before
    public void setup() {
        mapper = new ObjectMapper();
    }

    @Test
    public void shouldSerialize() throws JsonProcessingException {
        CompanyDashboardRow product = getCompanyDashboardRow();
        String json = this.mapper.writeValueAsString(product);
        assertEquals(JSON_STRING, json);
    }

    @Test
    public void shouldDeserialize() throws JSONException, JsonParseException, JsonMappingException, IOException {
        CompanyDashboardRow companyDashboardRow = mapper.readValue(JSON_STRING, CompanyDashboardRow.class);
        assertEquals(COMPANY_ID, companyDashboardRow.getCompanyId());
        assertEquals(ANALYST, companyDashboardRow.getAnalyst());
        assertEquals(EXT_UNIQUE_KEY, companyDashboardRow.getExtUniqueKey());
        assertEquals(COMPANY_ABN, companyDashboardRow.getAbn());
        assertNotNull(companyDashboardRow.getAttributes());
        assertEquals(1, companyDashboardRow.getAttributes().size());
        assertEquals(KEY1, companyDashboardRow.getAttributes().get(0).getKey());
        assertEquals(VALUE1, companyDashboardRow.getAttributes().get(0).getValue());
    }

    @Test
    public void testConstructorIsPrivate() throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
        Constructor<CompanyDashBoardURI> constructor = CompanyDashBoardURI.class.getDeclaredConstructor();
        assertTrue(Modifier.isPrivate(constructor.getModifiers()));
        constructor.setAccessible(true);
        constructor.newInstance();
    }

}