package au.com.lonsec.service.company.product;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import au.com.lonsec.service.company.product.model.Product;
import au.com.lonsec.service.company.segment.SegmentNotFoundException;
import au.com.lonsec.service.company.web.DpProfile;

@RunWith(MockitoJUnitRunner.class)
public class ProductServiceTest extends ProductTst {

    private ProductService productService;
    
    private ProductMapper productMapper;

    @Mock
    private ProductRepository productRepository;
    
    private static final String PROFILE_TOKEN = "eyJpZCI6ICJmZjFjNjFiYS1iYWQzLTExZTctYWJjNC1jZWMyNzhiNmI1MGEiLCJ1c2VybmFtZSI6ICJEUF9TUl9FTVBfQURNSU4iLCJzZWdtZW50IjoiU1IiLCJleHRJZCI6IjAwMCIsInJvbGUiOiAiNDgifQ==";

    @Before
    public void setup() {
        productMapper = new ProductMapper();
        productService = new ProductService(productRepository, productMapper);
        productEntity = getProductEntity();
        productEntityList = getProductEntityList();
        productUpdateRequest = getProductUpdateRequest();
        productAddRequest = getProductAddRequest();
    }

    @Test(expected = ProductNotFoundException.class)
    public void shouldThrowProductNotFoundException() throws ProductNotFoundException {
        String segmentId = "dummy";
        when(productRepository.findBySegmentCdAndProductId(SEGMENT_CD, PRODUCT_ID)).thenReturn(null);
        productService.findProduct(segmentId, PRODUCT_ID);
    }

    @Test
    public void shouldFindProduct() throws ProductNotFoundException, SegmentNotFoundException {
        when(productRepository.findBySegmentCdAndProductId(SEGMENT_CD, PRODUCT_ID)).thenReturn(productEntity);
        verifyProduct(productService.findProduct(SEGMENT_CD, PRODUCT_ID));
    }

    @Test
    public void shouldFindProductsBySegmentCdAndExtUniqueKey() {
        when(productRepository.findBySegmentCdAndExtUniqueKey(SEGMENT_CD, EXT_UNIQUE_KEY)).thenReturn(productEntityList);
        List<Product> result = productService.findBySegmentCdAndExtUniqueKey(SEGMENT_CD, EXT_UNIQUE_KEY);
        assertEquals(1, result.size());
        verifyProduct(result.get(0));
    }

    @Test
    public void shouldFindProductsBySegmentCd() throws Exception {
        DpProfile profile = DpProfile.fromToken(PROFILE_TOKEN, "test");
        when(productRepository.findBySegmentCd(SEGMENT_CD)).thenReturn(productEntityList);
        List<Product> result = productService.findProducts(SEGMENT_CD, profile);
        assertEquals(1, result.size());
        verifyProduct(result.get(0));
    }

    @Test
    public void shouldCreateProduct() throws ProductNotFoundException, SegmentNotFoundException {
        when(productRepository.findBySegmentCdAndProductId(productAddRequest.getSegmentCd(), PRODUCT_ID)).thenReturn(null);
        Product product = productService.createProduct(productAddRequest);
        verifyProduct(product);
        verify(productRepository, times(1)).findBySegmentCdAndProductId(productAddRequest.getSegmentCd(), PRODUCT_ID);
        verify(productRepository, times(1)).save(any(ProductEntity.class));
        verifyNoMoreInteractions(productRepository);
    }

    @Test
    public void shouldSaveExistingProduct() {
        when(productRepository.findBySegmentCdAndProductId(productAddRequest.getSegmentCd(), PRODUCT_ID)).thenReturn(productEntity);
        Product product = productService.createProduct(productAddRequest);
        verifyProduct(product);
        verify(productRepository, times(1)).findBySegmentCdAndProductId(productAddRequest.getSegmentCd(), PRODUCT_ID);
        verify(productRepository, times(1)).save(productEntity);
        verifyNoMoreInteractions(productRepository);
    }

    @Test
    public void shouldUpdateProduct() throws ProductNotFoundException, SegmentNotFoundException {
        assertEquals(SEGMENT_CD, productEntity.getSegmentCd());
        assertEquals(EXT_UNIQUE_KEY, productEntity.getExtUniqueKey());
        when(productRepository.findBySegmentCdAndProductId(SEGMENT_CD, PRODUCT_ID)).thenReturn(productEntity);
        Product product = productService.updateProduct(SEGMENT_CD, PRODUCT_ID,productUpdateRequest);
        verifyProduct(product);
        verify(productRepository, times(1)).findBySegmentCdAndProductId(SEGMENT_CD, PRODUCT_ID);
        verify(productRepository, times(1)).save(productEntity);
        verifyNoMoreInteractions(productRepository);
    }

    @Test
    public void shouldUpdateProductClassification() throws ProductNotFoundException, SegmentNotFoundException {
        assertEquals(SEGMENT_CD, productEntity.getSegmentCd());
        assertEquals(EXT_UNIQUE_KEY, productEntity.getExtUniqueKey());
        when(productRepository.findBySegmentCdAndProductId(SEGMENT_CD, PRODUCT_ID)).thenReturn(productEntity);
        Product product = productService.updateProductClassification(SEGMENT_CD, PRODUCT_ID,productUpdateRequest);
        verifyProduct(product);
        verify(productRepository, times(1)).findBySegmentCdAndProductId(SEGMENT_CD, PRODUCT_ID);
        verify(productRepository, times(1)).save(productEntity);
        verifyNoMoreInteractions(productRepository);
    }
    
    
    
    @Test(expected = ProductNotFoundException.class)
    public void unknownProductshouldThrowProductNotFoundException() throws ProductNotFoundException {
        when(productRepository.findBySegmentCdAndProductId(SEGMENT_CD, PRODUCT_ID)).thenReturn(null);
        productService.updateProduct(SEGMENT_CD, PRODUCT_ID, productUpdateRequest);
    }



}