package au.com.lonsec.service.company.productDashboard;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import au.com.lonsec.service.company.domain.DomainStereotypeUtil;
import au.com.lonsec.service.company.productDashboard.model.ProductDashboardRow;

public class ProductDashboardMapperTest extends ProductDashboardTst {

    private ProductDashboardMapper productDashboardMapper;

    @Before
    public void setup() {
        productDashboardMapper = new ProductDashboardMapper();
        productDashboardDTO = getProductDashboardDTO();
        productDashboardRow = getProductDashboardRow();
        productEntity = getProductEntity();
        product = getProduct();
        lookups = getLookUps();
    }

    @Test
    public void shouldMapProductToModel() {
        ProductDashboardRow result = productDashboardMapper.map(lookups, productDashboardDTO, new ProductDashboardRow());
        verifyProductDashboardRow(result);
        verifyProductClassification(result);
        verifySegment(result);
        assertTrue(result.getActive());
    }
    
    @Test
    public void shouldMapProductWithMissingClassificationModel() {
        productDashboardDTO.setProductClassification(null);
        ProductDashboardRow result = productDashboardMapper.map(lookups, productDashboardDTO, new ProductDashboardRow());
        verifyProductDashboardRow(result);
    }

    @Test
    public void shouldMapProductWithMissingSegmentModel() {
        productDashboardDTO.setSegment(null);
        ProductDashboardRow result = productDashboardMapper.map(lookups, productDashboardDTO, new ProductDashboardRow());
        verifyProductDashboardRow(result);
        verifyEmptySegment(result);
    }


    @Test
    public void shouldResolveAssetClassFromLookup() {
        String result = productDashboardMapper.getValue(lookups, DomainStereotypeUtil.ASSETCLASS_LOOKUP, "AEQ");
        assertEquals("Australian Equities", result);
    }

    @Test
    public void shouldReturnLookupKeyWhenNotInLookup() {
        String result = productDashboardMapper.getValue(lookups, DomainStereotypeUtil.ASSETCLASS_LOOKUP, "AEQXX");
        assertEquals("AEQXX", result);
    }

}