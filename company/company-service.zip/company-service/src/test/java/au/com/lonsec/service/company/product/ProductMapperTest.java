package au.com.lonsec.service.company.product;

import org.junit.Before;
import org.junit.Test;

import au.com.lonsec.service.company.product.model.Product;

public class ProductMapperTest extends ProductTst {

    private ProductMapper productMapper;

    @Before
    public void setup() {
        productMapper = new ProductMapper();
        productEntity = getProductEntity();
        product = getProduct();
    }

    @Test
    public void shouldMapEntityToModel() {
        Product result = productMapper.map(productEntity, new Product());
        verifyProduct(result);
    }

    @Test
    public void shouldMapModelToEntity() {
        ProductEntity result = productMapper.map(product, new ProductEntity());
        verifyProduct(result);
    }
    
    
    @Test
    public void shouldMapClassification() {
        ProductEntity result = productMapper.mapClassification(product, productEntity);
        verifyProduct(result);
        verifyProductClassification(result);
    }


}