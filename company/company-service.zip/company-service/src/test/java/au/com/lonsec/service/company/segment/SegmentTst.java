package au.com.lonsec.service.company.segment;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import au.com.lonsec.service.company.domain.DomainStereotypeUtil;
import au.com.lonsec.service.company.segment.client.model.SegmentAddRequest;
import au.com.lonsec.service.company.segment.client.model.SegmentRequest;
import au.com.lonsec.service.company.segment.client.model.SegmentUpdateRequest;
import au.com.lonsec.service.company.segment.client.model.SegmentsGetResponse;
import au.com.lonsec.service.company.segment.model.Segment;

public abstract class SegmentTst {

    protected static final String ACTIVE = "ACTIVE";
    protected static final String ID = "81dd92a4-be95-47ca-9922-12f29c05da8c";
    protected static final UUID SEGMENT_UUID = UUID.fromString(ID);

    protected static final String ANALYST = "analyst";
    protected static final String SEGMENT_CD = "SR";
    protected static final String EXT_UNIQUE_KEY = "276";
    protected static final String COMPANY_ABN = "12345678901";
    protected static final String COMPANY_NAME = "Company_Name";

    protected static final String COMPANY_ID = "523be751-86ee-454f-bcce-4752df2c1234";
    protected SegmentEntity segmentEntity;
    protected List<SegmentEntity> segmentEntityList;
    protected SegmentAddRequest segmentAddRequest;
    protected SegmentUpdateRequest segmentUpdateRequest;
    protected SegmentsGetResponse segmentsGetResponse;
    protected List<Segment> segments;
    
    protected Date today = DomainStereotypeUtil.getToday();

    public SegmentTst() {

        super();
    }

    protected Segment getSegment() {
        return DomainStereotypeUtil.getSegment();
    }

    protected SegmentRequest getSegmentRequest() {
        SegmentRequest segmentRequest = new SegmentRequest();
        segmentRequest.setSegmentCd(SEGMENT_CD);
        segmentRequest.setExtUniqueKey(EXT_UNIQUE_KEY);
        segmentRequest.setAnalyst(ANALYST);
        segmentRequest.setCompanyId(COMPANY_ID);
        segmentRequest.setActive(true);
        return segmentRequest;
    }

    private SegmentRequest populateSegment(SegmentRequest segmentDTO) {
        segmentDTO.setSegmentCd(SEGMENT_CD);
        segmentDTO.setExtUniqueKey(EXT_UNIQUE_KEY);
        segmentDTO.setAnalyst(ANALYST);
        segmentDTO.setCompanyId(COMPANY_ID);
        segmentDTO.setActive(true);
        return segmentDTO;
    }

    protected SegmentEntity getSegmentEntity() {
        return DomainStereotypeUtil.getSegmentEntity();
    }

    protected List<SegmentEntity> getSegmentEntityList() {
        List<SegmentEntity> segmentEntityList = new ArrayList<SegmentEntity>();
        segmentEntityList.add(getSegmentEntity());
        return segmentEntityList;
    }

    protected SegmentAddRequest getSegmentAddRequest() {
        SegmentAddRequest segmentAddRequest = new SegmentAddRequest();
        populateSegment(segmentAddRequest);
        return segmentAddRequest;
    }

    protected SegmentUpdateRequest getSegmentUpdateRequest() {
        SegmentUpdateRequest segmentUpdateRequest = new SegmentUpdateRequest();
        segmentUpdateRequest.setId(ID);
        ;
        populateSegment(segmentUpdateRequest);
        return segmentUpdateRequest;
    }

    protected SegmentsGetResponse getSegmentsGetResponse() {
        SegmentsGetResponse segmentsGetResponse = new SegmentsGetResponse();
        segmentsGetResponse.setSegments(getSegments());
        return segmentsGetResponse;

    }

    protected List<Segment> getSegments() {
        List<Segment> segments = new ArrayList<Segment>();
        segments.add(getSegmentRequest());
        return segments;
    }

}