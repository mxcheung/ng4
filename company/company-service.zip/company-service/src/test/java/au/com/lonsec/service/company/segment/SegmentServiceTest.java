package au.com.lonsec.service.company.segment;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import au.com.lonsec.service.company.segment.model.Segment;

@RunWith(MockitoJUnitRunner.class)
public class SegmentServiceTest extends SegmentTst {

    private SegmentService segmentService;

    @Mock
    private SegmentRepository segmentRepository;

    @Before
    public void setup() {
        segmentService = new SegmentService(segmentRepository);
        segmentEntity = getSegmentEntity();
        segmentEntityList = getSegmentEntityList();
        segmentAddRequest = getSegmentAddRequest();
        segmentUpdateRequest = getSegmentUpdateRequest();

    }

    @Test(expected = SegmentNotFoundException.class)
    public void shouldThrowSegmentNotFoundException() throws SegmentNotFoundException {
        String segmentCd = "invalidSegmentCd";
        String extUniqueKey = "dummy";
        when(segmentRepository.findBySegmentCdAndExtUniqueKey(segmentCd, extUniqueKey)).thenReturn(null);
        segmentService.findSegment(segmentCd, extUniqueKey);
        verify(segmentRepository, times(1)).findBySegmentCdAndExtUniqueKey(SEGMENT_CD, EXT_UNIQUE_KEY);
        verifyNoMoreInteractions(segmentRepository);
    }

    @Test
    public void shouldReturnValidSegment() throws SegmentNotFoundException {
        when(segmentRepository.findBySegmentCdAndExtUniqueKey(SEGMENT_CD, EXT_UNIQUE_KEY)).thenReturn(segmentEntity);
        Segment result = segmentService.findSegment(SEGMENT_CD, EXT_UNIQUE_KEY);
        assertEquals(SEGMENT_CD, result.getSegmentCd());
        assertEquals(EXT_UNIQUE_KEY, result.getExtUniqueKey());
        verify(segmentRepository, times(1)).findBySegmentCdAndExtUniqueKey(SEGMENT_CD, EXT_UNIQUE_KEY);
        verifyNoMoreInteractions(segmentRepository);
    }

    @Test
    public void shouldCreateSegment() throws SegmentNotFoundException {
        when(segmentRepository.findBySegmentCdAndExtUniqueKey(SEGMENT_CD, EXT_UNIQUE_KEY)).thenReturn(null);
        Segment result = segmentService.createSegment(segmentAddRequest);
        verifyResult(result);
        verify(segmentRepository, times(1)).findBySegmentCdAndExtUniqueKey(SEGMENT_CD, EXT_UNIQUE_KEY);
        verify(segmentRepository, times(1)).save(any(SegmentEntity.class));
        verifyNoMoreInteractions(segmentRepository);

    }

    @Test
    public void shouldFindSegmentsBySegmentCd() throws SegmentNotFoundException {
        when(segmentRepository.findBySegmentCd(SEGMENT_CD)).thenReturn(segmentEntityList);
        List<Segment> result = segmentService.findSegment(SEGMENT_CD);
        assertEquals(1, result.size());
        Segment segment = result.get(0);
        verifyResult(segment);
        verify(segmentRepository, times(1)).findBySegmentCd(SEGMENT_CD);
        verifyNoMoreInteractions(segmentRepository);
    }

    @Test
    public void shouldFindSegmentsBySegmentCdAndCompanyName() throws SegmentNotFoundException {
        when(segmentRepository.findBySegmentCdAndCompanyNameContainingIgnoreCase(SEGMENT_CD, COMPANY_NAME)).thenReturn(segmentEntityList);
        List<Segment> result = segmentService.findByCompanyNameContaining(SEGMENT_CD, COMPANY_NAME);
        assertEquals(1, result.size());
        Segment segment = result.get(0);
        verifyResult(segment);
        verify(segmentRepository, times(1)).findBySegmentCdAndCompanyNameContainingIgnoreCase(SEGMENT_CD, COMPANY_NAME);
        verifyNoMoreInteractions(segmentRepository);
    }

    @Test
    public void shouldSaveExistingSegment() {
        when(segmentRepository.findBySegmentCdAndExtUniqueKey(SEGMENT_CD, EXT_UNIQUE_KEY)).thenReturn(segmentEntity);
        Segment result = segmentService.createSegment(segmentAddRequest);
        verifyResult(result);
    }

    @Test
    public void shouldUpdateSegment() throws SegmentNotFoundException {
        assertEquals(today, segmentEntity.getInsertDate());
        assertEquals(today, segmentEntity.getLastModified());
        when(segmentRepository.findBySegmentCdAndExtUniqueKey(SEGMENT_CD, EXT_UNIQUE_KEY)).thenReturn(segmentEntity);
    
        Segment result = segmentService.updateSegment(SEGMENT_CD, EXT_UNIQUE_KEY, segmentUpdateRequest);
        verifyResult(result);
        assertEquals(ID, result.getId());
        verify(segmentRepository, times(1)).findBySegmentCdAndExtUniqueKey(SEGMENT_CD, EXT_UNIQUE_KEY);
        verify(segmentRepository, times(1)).save(segmentEntity);
        verifyNoMoreInteractions(segmentRepository);
    }

    @Test(expected = SegmentNotFoundException.class)
    public void unknownSegmentshouldThrowSegmentNotFoundException() throws SegmentNotFoundException {
        when(segmentRepository.findBySegmentCdAndExtUniqueKey(SEGMENT_CD, EXT_UNIQUE_KEY)).thenReturn(null);
        segmentService.updateSegment(SEGMENT_CD, EXT_UNIQUE_KEY, segmentUpdateRequest);
    }

    @Test
    public void shouldConvertUp() {
        List<Segment> result = segmentService.convertUp(segmentEntityList);
        assertEquals(1, result.size());
        Segment segment = result.get(0);
        verifyResult(segment);
    }

    private void verifyResult(Segment result) {
        assertEquals(SEGMENT_CD, result.getSegmentCd());
        assertEquals(EXT_UNIQUE_KEY, result.getExtUniqueKey());
        assertEquals(ANALYST, result.getAnalyst());
        assertEquals(COMPANY_ID, result.getCompanyId());
    }

}