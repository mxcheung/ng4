package au.com.lonsec.service.company.lookup;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import au.com.lonsec.service.company.domain.DomainStereotypeUtil;
import au.com.lonsec.service.company.lookup.client.model.LookupCompanyResponse;
import au.com.lonsec.service.company.lookup.client.model.LookupContactResponse;
import au.com.lonsec.service.company.lookup.model.LookupValue;

public class LookupTst {

    protected static final String ENTITY_ID = "entityId";
    protected static final String PARENTCODE = "parentcode";
    protected static final String CODE = "code";
    protected static final String VALUE = "value";
    protected static final String LOOKTYPE = "looktype";
    protected static final String LOOKTYPE_NAME = "looktypeName";
    protected static final String LOOKUP_CSV = "lookup-test.csv";
    protected static final String LOOKUP_FOLDER = "";

    protected LookupLoadRequest lookupLoadRequest;
    protected LookupGetRequest lookupGetRequest;
    protected LookupCompanyResponse lookupCompanyResponse;
    protected LookupContactResponse lookupContactResponse;
    protected LookupEntity lookupEntity;
    protected List<LookupEntity> lookupEntityList;
    protected List<LookupValue> lookupValueList;
    protected Map<String, List<LookupValue>> lookupMap;
    protected Map<String, Map<String, String>> lookups;

    public LookupTst() {
        super();
    }
    
    protected static Map<String, Map<String, String>> getLookUps() {
        return DomainStereotypeUtil.getLookUps();
    }

    protected LookupGetRequest getLookupGetRequest() {
        LookupGetRequest lookupGetRequest = new LookupGetRequest();
        lookupGetRequest.setLookupType(LOOKTYPE);
        lookupGetRequest.setShoppingList(getShoppingList());
        return lookupGetRequest;
    }

    protected List<String> getShoppingList() {
        List<String> shoppingList = new ArrayList<>();
        shoppingList.add("item1");
        return shoppingList;
    }

    protected LookupLoadRequest getLookupLoadRequest() {
        LookupLoadRequest lookupLoadRequest = new LookupLoadRequest();
        lookupLoadRequest.setFileName(LOOKUP_CSV);
        return lookupLoadRequest;
    }

    protected LookupCompanyResponse getLookupCompanyResponse() {
        LookupCompanyResponse lookupCompanyResponse = new LookupCompanyResponse();
        lookupCompanyResponse.setLookupMap(getLookupMap());
        return lookupCompanyResponse;
    }

    protected LookupContactResponse getLookupContactResponse() {
        LookupContactResponse lookupContactResponse = new LookupContactResponse();
        lookupContactResponse.setLookupMap(getLookupMap());
        return lookupContactResponse;
    }

    protected Map<String, List<LookupValue>> getLookupMap() {
        Map<String, List<LookupValue>> lookupMap = new HashMap<String, List<LookupValue>>();
        lookupMap.put(LOOKTYPE_NAME, getLookupValues());
        return lookupMap;
    }

    protected List<LookupValue> getLookupValues() {
        List<LookupValue> lookupValues = new ArrayList<LookupValue>();
        lookupValues.add(getLookupValue());
        return lookupValues;
    }

    protected LookupValue getLookupValue() {
        LookupValue lookupValue = new LookupValue();
        lookupValue.setKey(CODE);
        lookupValue.setValue(VALUE);
        return lookupValue;
    }

    protected LookupRow getLookUpRow() {
        LookupRow row = new LookupRow(ENTITY_ID, LOOKTYPE, LOOKTYPE_NAME, CODE, VALUE, PARENTCODE);
        row.setEntityId(ENTITY_ID);
        row.setLooktype(LOOKTYPE);
        row.setLooktypeName(LOOKTYPE_NAME);
        row.setCode(CODE);
        row.setValue(VALUE);
        row.setParentCode(PARENTCODE);
        return row;
    }

    protected LookupEntity getLookUpEntity() {
        LookupEntity lookupEntity = new LookupEntity();
        lookupEntity.setEntityId(ENTITY_ID);
        lookupEntity.setLookupType(LOOKTYPE);
        lookupEntity.setLookupTypeName(LOOKTYPE_NAME);
        lookupEntity.setLookupCode(CODE);
        lookupEntity.setLookupValue(VALUE);
        return lookupEntity;
    }

    protected List<LookupEntity> getLookUpEntityList() {
        List<LookupEntity> lookupEntityList = new ArrayList<LookupEntity>();
        lookupEntityList.add(getLookUpEntity());
        return lookupEntityList;
    }

}