package au.com.lonsec.service.company.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import au.com.lonsec.service.company.companyDashboard.model.SegmentAttribute;
import au.com.lonsec.service.company.product.ProductEntity;
import au.com.lonsec.service.company.product.model.Product;
import au.com.lonsec.service.company.productClassification.model.ProductClassification;
import au.com.lonsec.service.company.segment.SegmentEntity;
import au.com.lonsec.service.company.segment.model.Segment;

public final class DomainStereotypeUtil {

    protected static final String KEY1 = "Key1";
    protected static final String VALUE1 = "Value1";
    private static final String SECTOR_LEAD = "SectorLead";
    private static final String RESEARCH_PLAN = "ResearchPlan";
    protected static final String ID = "81dd92a4-be95-47ca-9922-12f29c05da8c";
    protected static final UUID PRODUCT_UUID = UUID.fromString(ID);

    protected static final UUID SEGMENT_UUID = UUID.fromString(ID);

    protected static final String SEGMENT_CD = "SR";
    protected static final String EXT_UNIQUE_KEY = "276";

    protected static final String SEGMENT_ID = "126be751-86ee-454f-bcce-4752df2c5594";
    protected static final String PRODUCT_NAME = "Sunsuper for Life - Conservative";
    protected static final String PRODUCT_ID = "    MF-1-31215";
    protected static final String APIR_CODE = "APIR";
    protected static final String PRODUCT_TYPE = "productType";
    protected static final String NOTES = "notes";

    protected static final String ANALYST = "analyst";
    protected static final String COMPANY_ABN = "12345678901";
    protected static final String COMPANY_NAME = "Company_Name";
    protected static final String COMPANY_ID = "523be751-86ee-454f-bcce-4752df2c1234";

    protected static final String ASX_CODE = "ASX";
    protected static final String ASSET_CLASS_CODE = "AE";
    protected static final String ASSET_CLASS_NAME = "Australian Equities";
    protected static final String SECTOR_NAME = "Australian Smaller Companies";
    protected static final String SECTOR_CODE = "ASC";
    protected static final String SUB_SECTOR_NAME = "Small Cap";
    protected static final String SUB_SECTOR_CODE = "SC";
    protected static final String PRODUCT_CLASS_CODE = "MF";
    protected static final String PRODUCT_CLASS_NAME = "Managed Fund";

    public static final String ASSETCLASS_LOOKUP = "ASSETCLASS";
    public static final String PRODUCTCLASS_LOOKUP = "PRODUCTCLASS";
    public static final String SECTOR_LOOKUP = "SECTOR";
    public static final String SUBSECTOR_LOOKUP = "SUBSECTOR";
    

    private static final boolean ACTIVE_FLAG_TRUE = true;
    private static final Date today = new Date();

    public static Product getProduct() {
        Product product = new Product(SEGMENT_ID, PRODUCT_NAME, PRODUCT_ID, APIR_CODE, SEGMENT_CD, EXT_UNIQUE_KEY, true);
        product.setId(ID);
        product.setSegmentId(SEGMENT_ID);
        product.setProductName(PRODUCT_NAME);
        product.setApirCd(APIR_CODE);
        product.setAsxCd(ASX_CODE);
        product.setAssetClassCd(ASSET_CLASS_CODE);
        product.setSectorCd(SECTOR_CODE);
        product.setSubSectorCd(SUB_SECTOR_CODE);
        product.setProductClassCd(PRODUCT_CLASS_CODE);
        product.setProductId(PRODUCT_ID);
        product.setSegmentCd(SEGMENT_CD);
        product.setExtUniqueKey(EXT_UNIQUE_KEY);
        product.setProductType(PRODUCT_TYPE);
        product.setResearchPlan(RESEARCH_PLAN);
        product.setSectorLead(SECTOR_LEAD);
        product.setNotes(NOTES);
        product.setActive(ACTIVE_FLAG_TRUE);
        return product;
    }

    public static ProductEntity getProductEntity() {
        ProductEntity productEntity = new ProductEntity(SEGMENT_ID, PRODUCT_NAME, PRODUCT_ID, APIR_CODE, ACTIVE_FLAG_TRUE);
        productEntity.setId(PRODUCT_UUID);
        productEntity.setApirCd(APIR_CODE);
        productEntity.setSegmentId(SEGMENT_ID);
        productEntity.setSegmentCd(SEGMENT_CD);
        productEntity.setExtUniqueKey(EXT_UNIQUE_KEY);
        productEntity.setProductType(PRODUCT_TYPE);
        productEntity.setNotes(NOTES);
        productEntity.setInsertDate(today);
        productEntity.setLastModified(today);
        productEntity.setActive(ACTIVE_FLAG_TRUE);
        return productEntity;
    }

    public static SegmentEntity getSegmentEntity() {
        SegmentEntity segmentEntity = new SegmentEntity();
        segmentEntity.setId(SEGMENT_UUID);
        segmentEntity.setSegmentCd(SEGMENT_CD);
        segmentEntity.setExtUniqueKey(EXT_UNIQUE_KEY);
        segmentEntity.setAnalyst(ANALYST);
        segmentEntity.setCompanyId(COMPANY_ID);
        segmentEntity.setInsertDate(today);
        segmentEntity.setLastModified(today);
        segmentEntity.setActive(ACTIVE_FLAG_TRUE);
        return segmentEntity;
    }

    public static ProductClassification getProductClassification() {
        ProductClassification productClassification = new ProductClassification();
        productClassification.setProductId(PRODUCT_ID);
        productClassification.setApirCd(APIR_CODE);
        productClassification.setAsxCd(ASX_CODE);
        productClassification.setProductName(PRODUCT_NAME);
        productClassification.setAssetClassName(ASSET_CLASS_NAME);
        productClassification.setSectorName(SECTOR_NAME);
        productClassification.setSubSectorName(SUB_SECTOR_NAME);
        productClassification.setProductClassName(PRODUCT_CLASS_NAME);
        return productClassification;
    }

    public static Segment getSegment() {
        Segment segment = new Segment();
        segment.setSegmentCd(SEGMENT_CD);
        segment.setExtUniqueKey(EXT_UNIQUE_KEY);
        segment.setAnalyst(ANALYST);
        segment.setCompanyId(COMPANY_ID);
        segment.setCompanyName(COMPANY_NAME);
        segment.setAbn(COMPANY_ABN);
        segment.setActive(ACTIVE_FLAG_TRUE);
        return segment;
    }
    
    public static List<Segment> getSegments() {
        List<Segment> segments = new ArrayList<Segment>();
        segments.add( getSegment() );
        return segments;
    }

    public static List<SegmentAttribute> getAttributes() {
        List<SegmentAttribute> attributes = new ArrayList<SegmentAttribute>();
        SegmentAttribute attribute = getSegmentAttribute();
        attributes.add(attribute );
        return attributes;
    }

    private static SegmentAttribute getSegmentAttribute() {
        SegmentAttribute attribute = new SegmentAttribute();
        attribute.setKey(KEY1);
        attribute.setValue(VALUE1);
        return attribute;
    }

    public static Map<String, Map<String, String>> getLookUps() {
        Map<String, Map<String, String>> map = new HashMap<String, Map<String, String>>();
        map.put(ASSETCLASS_LOOKUP, getAssetClassMap());
        map.put(PRODUCTCLASS_LOOKUP, getProductClassMap());
        map.put(SECTOR_LOOKUP, getSectorMap());
        map.put(SUBSECTOR_LOOKUP, getSubSectorMap());
        return map;
    }

    public static Map<String, String> getAssetClassMap() {
        Map<String, String> map = new HashMap<String, String>();
        map.put("AEQ", "Australian Equities");
        return map;
    }

    public static Map<String, String> getProductClassMap() {
        Map<String, String> map = new HashMap<String, String>();
        map.put(PRODUCT_CLASS_CODE, PRODUCT_CLASS_NAME);
        return map;
    }

    public static Map<String, String> getSectorMap() {
        Map<String, String> map = new HashMap<String, String>();
        map.put("AEQ:ALP", "Australian Large Cap");
        return map;
    }

    public static Map<String, String> getSubSectorMap() {
        Map<String, String> map = new HashMap<String, String>();
        map.put("AEQ:ALP:AR", "Absolute Return");
        return map;
    }

    
    public static Date getToday() {
        return today;
    }
}
