package au.com.lonsec.service.company.util;

import java.io.IOException;
import java.util.List;
import java.util.function.Consumer;

import org.antlr.stringtemplate.StringTemplate;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SegmentSQLTest extends SqlTst {

    private static final Logger LOGGER = LoggerFactory.getLogger(SegmentSQLTest.class);

    private static final String DATA_FILE = "dataload/segment-setup.csv";
    
    private static final String MSSQL = 
            "IF NOT EXISTS ( SELECT 1 FROM SEGMENT  WHERE SEGMENT_CD ='$segmentcd$' AND EXT_UNIQUE_KEY = '$extuniquekey$' )\n"
            + "BEGIN\n"
            + "    INSERT INTO SEGMENT(ID, INSERT_DATE, LAST_MODIFIED, ACTIVE, ABN, ANALYST, COMPANY_ID, COMPANY_NAME, EXT_UNIQUE_KEY, SEGMENT_CD)\n" 
            + "    VALUES (NEWID(), getdate(),  getdate(), 1, '$abn$', '$analyst$', '$extuniquekey$', '$companyName$', '$extuniquekey$', '$segmentcd$' )\n"
            + "END;\n\n";
                    

    private static final String H2SQL = "merge into SEGMENT(ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  ABN, ANALYST, COMPANY_ID, COMPANY_NAME, EXT_UNIQUE_KEY, SEGMENT_CD ) "
            + "    VALUES (RANDOM_UUID(), CURRENT_TIMESTAMP,  CURRENT_TIMESTAMP, 1,  '$abn$', '$analyst$', '$extuniquekey$', '$companyName$', '$extuniquekey$', '$segmentcd$' ); \n";

    private static final StringTemplate H2Template = new StringTemplate(H2SQL);
    private static final StringTemplate MSSQLTemplate = new StringTemplate(MSSQL);

    @Test
    public void shouldGenerateMSSQL() throws IOException {
        generateScript(DATA_FILE, MSSQLTemplate);
    }

    @Test
    public void shouldGenerateH2SQL() throws IOException {
        generateScript(DATA_FILE, H2Template);
    }

    private void generateScript(String filename, StringTemplate template) throws IOException {
        StringBuilder result = new StringBuilder();
        result.append(NEWLINE + LINE_SEPARATER + NEWLINE);
        Consumer<List<String>> consumerCompany = getConsumer(template, result);
        List<List<String>> rawvalues = readcsv(getResourceFilePath(filename));
        rawvalues.forEach(consumerCompany);
        LOGGER.info(result.toString());
    }


    private Consumer<List<String>> getConsumer(StringTemplate template, StringBuilder builder) {
        Consumer<List<String>> consumerCompany = company -> {
            String extuniquekey = company.get(0);
            String companyName = company.get(1);
            String abn = company.get(2);
            String analyst = company.get(3);
            String segmentcd = company.get(4);
            template.reset();
            template.setAttribute("extuniquekey", extuniquekey);
            template.setAttribute("companyName", companyName);
            template.setAttribute("abn", abn);
            template.setAttribute("analyst", analyst);
            template.setAttribute("segmentcd", segmentcd);
            builder.append(template.toString());
        };
        return consumerCompany;
    }


}