package au.com.lonsec.service.company.companyDashboard;

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import au.com.lonsec.service.company.companyDashboard.model.CompanyDashboardRow;

public class CompanyDashboardMapperTest extends CompanyDashboardTst {

    private CompanyDashboardMapper companyDashboardMapper;

    @Before
    public void setup() {
        companyDashboardMapper = new CompanyDashboardMapper();
        companyDashboardDTO = getCompanyDashboardDTO();
        companyDashboardRow = getCompanyDashboardRow();
        segmentEntity = getSegmentEntity();
        segment = getSegment();
    }

    @Test
    public void shouldMapCompanyToModel() {
        CompanyDashboardRow result = companyDashboardMapper.map(companyDashboardDTO, new CompanyDashboardRow());
        verifyCompanyDashboardRow(result);
        assertTrue(result.getActive());
    }

    @Test
    public void shouldMapCompanyWithMissingSegmentModel() {
        companyDashboardDTO.setSegment(null);
        CompanyDashboardRow result = companyDashboardMapper.map(companyDashboardDTO, new CompanyDashboardRow());
        verifyEmptySegment(result);
    }

}