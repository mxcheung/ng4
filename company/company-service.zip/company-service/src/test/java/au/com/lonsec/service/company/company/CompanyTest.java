package au.com.lonsec.service.company.company;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;

import org.codehaus.jettison.json.JSONException;
import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.lonsec.service.company.company.model.Company;
import au.com.lonsec.service.company.company.server.CompanyURI;

public class CompanyTest extends CompanyTst {

    private final static String JSON_STRING = "{\"companyName\":\"bhp\",\"abn\":\"12345678901\",\"address\":\"1 Main rd somewhere\",\"parentId\":\"126be751-86ee-454f-bcce-4752df2c5594\",\"id\":\"81dd92a4-be95-47ca-9922-12f29c05da8c\",\"status\":\"ACTIVE\"}";

    private ObjectMapper mapper;

    @Before
    public void setup() {
        mapper = new ObjectMapper();
    }

    @Test
    public void shouldSerialize() throws JsonProcessingException {
        Company company = getCompany();
        String json = this.mapper.writeValueAsString(company);
        assertEquals(JSON_STRING, json);
    }

    @Test
    public void shouldDeserialize() throws JSONException, JsonParseException, JsonMappingException, IOException {
        Company companyDTO = mapper.readValue(JSON_STRING, Company.class);
        assertEquals(COMPANY_NAME, companyDTO.getCompanyName());
        assertEquals(COMPANY_ABN, companyDTO.getAbn());
        assertEquals(COMPANY_ADDRESS, companyDTO.getAddress());
        assertEquals(COMPANY_PARENT_ID, companyDTO.getParentId());
    }

    @Test
    public void testConstructorIsPrivate() throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
        Constructor<CompanyURI> constructor = CompanyURI.class.getDeclaredConstructor();
        assertTrue(Modifier.isPrivate(constructor.getModifiers()));
        constructor.setAccessible(true);
        constructor.newInstance();
    }
}