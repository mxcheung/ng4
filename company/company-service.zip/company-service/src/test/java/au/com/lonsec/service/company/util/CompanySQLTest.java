package au.com.lonsec.service.company.util;

import java.io.IOException;
import java.util.List;
import java.util.function.Consumer;

import org.antlr.stringtemplate.StringTemplate;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CompanySQLTest extends SqlTst {

    private static final Logger LOGGER = LoggerFactory.getLogger(CompanySQLTest.class);

    private static final String DATALOAD_COMPANY_SETUP_CSV = "dataload/company-setup.csv";
    private static final String MSSQL = "IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '$abn$' ) \n " + "BEGIN \n"
            + "   insert into company (id, abn,  Company_Name, insert_date, last_modified) \n"
            + "   values (NEWID(), '$abn$','$companyName$', getdate(), getdate()) \n " + "END; \n" + " \n";

    private static final String H2SQL = "merge into company (id, abn,  Company_Name, insert_date, last_modified) "
            + " values (RANDOM_UUID(), '$abn$', '$companyName$', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP) " + "; \n";

    private static final StringTemplate H2Template = new StringTemplate(H2SQL);
    private static final StringTemplate MSSQLTemplate = new StringTemplate(MSSQL);

    @Test
    public void shouldGenerateMSSQL() throws IOException {
        generateScript(DATALOAD_COMPANY_SETUP_CSV, MSSQLTemplate);
    }

    @Test
    public void shouldGenerateH2SQL() throws IOException {
        generateScript(DATALOAD_COMPANY_SETUP_CSV, H2Template);
    }

    private void generateScript(String filename, StringTemplate template) throws IOException {
        StringBuilder result = new StringBuilder();
        result.append(NEWLINE + LINE_SEPARATER + NEWLINE);
        Consumer<List<String>> consumerCompany = getCompanyConsumer(template, result);
        List<List<String>> rawvalues = readcsv(getResourceFilePath(filename));
        rawvalues.forEach(consumerCompany);
        LOGGER.info(result.toString());
    }


    private Consumer<List<String>> getCompanyConsumer(StringTemplate template, StringBuilder builder) {
        Consumer<List<String>> consumerCompany = company -> {
            String abn = company.get(0);
            String companyName = company.get(1);
            template.reset();
            template.setAttribute("abn", abn);
            template.setAttribute("companyName", companyName);
            builder.append(template.toString());
        };
        return consumerCompany;
    }


}