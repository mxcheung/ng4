package au.com.lonsec.service.company.product;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;

import org.codehaus.jettison.json.JSONException;
import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.lonsec.service.company.product.client.model.ProductRequest;
import au.com.lonsec.service.company.product.model.Product;

public class ProductTest extends ProductTst {

    private final static String JSON_STRING = "{\"extUniqueKey\":\"276\",\"productName\":\"Sunsuper for Life - Conservative\",\"productId\":\"    MF-1-31215\",\"apirCd\":\"APIR\",\"segmentCd\":\"SR\",\"active\":true,\"segmentId\":\"126be751-86ee-454f-bcce-4752df2c5594\",\"id\":\"81dd92a4-be95-47ca-9922-12f29c05da8c\",\"asxCd\":\"ASX\",\"assetClassCd\":\"AE\",\"sectorCd\":\"ASC\",\"subSectorCd\":\"SC\",\"productClassCd\":\"MF\",\"productType\":\"productType\",\"researchPlan\":\"ResearchPlan\",\"sectorLead\":\"SectorLead\",\"notes\":\"notes\"}";

    private ObjectMapper mapper;

    @Before
    public void setup() {
        mapper = new ObjectMapper();
    }

    @Test
    public void shouldSerialize() throws JsonProcessingException {
        Product product = getProduct();
        String json = this.mapper.writeValueAsString(product);
        assertEquals(JSON_STRING, json);
    }

    @Test
    public void shouldDeserialize() throws JSONException, JsonParseException, JsonMappingException, IOException {
        ProductRequest productAddDTO = mapper.readValue(JSON_STRING, ProductRequest.class);
        assertEquals(SEGMENT_UUID, productAddDTO.getSegmentId());
        assertEquals(PRODUCT_NAME, productAddDTO.getProductName());
        assertEquals(PRODUCT_ID, productAddDTO.getProductId());
        assertEquals(APIR_CODE, productAddDTO.getApirCd());
    }
    
    
    @Test
    public void testConstructorIsPrivate() throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
        Constructor<ProductURI> constructor = ProductURI.class.getDeclaredConstructor();
        assertTrue(Modifier.isPrivate(constructor.getModifiers()));
        constructor.setAccessible(true);
        constructor.newInstance();
    }

}