package au.com.lonsec.service.company.productClassification;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.fasterxml.jackson.core.JsonProcessingException;

import au.com.lonsec.service.company.domain.DomainStereotypeUtil;
import au.com.lonsec.service.company.product.ProductNotFoundException;
import au.com.lonsec.service.company.product.ProductService;
import au.com.lonsec.service.company.product.model.Product;
import au.com.lonsec.service.company.productClassification.model.ProductClassification;

@RunWith(MockitoJUnitRunner.class)
public class ProductClassificationServiceTest extends ProductClassificationTst {

    @Mock
    private ProductClassificationRepository productClassificationRepository;

    @Mock
    private ProductClassificationCSVReader productClassificationCSVReader;

    private ProductClassificationService productClassificationService;

    @Mock
    private ProductClassificationMapper mockProductClassificationMapper;

    @Mock
    private ProductClassificationMapper productClassificationMapper;

    @Mock
    private ProductService productService;

    @Before
    public void setup() {

        productClassificationMapper = new ProductClassificationMapper();
        productClassificationEntity = getProductClassificationEntity();
        productClassificationGetRequest = getProductClassificationGetRequest();
        productClassificationLoadRequest = getProductClassificationLoadRequest();

        productClassificationService = new ProductClassificationService(productClassificationRepository, productClassificationCSVReader,
                productClassificationMapper, productService);
        productClassificationList = getProductClassifications();
        productClassificationEntityList = getProductClassificationEntityList();
    }

    @Test(expected = FileNotFoundException.class)
    public void shouldThrowFileNotFoundExceptionWhenReadInvalidProductClassificationFile() throws FileNotFoundException, IOException {
        productClassificationLoadRequest.setFileName("NonExistentFile");
        doThrow(new FileNotFoundException()).when(productClassificationCSVReader)
                .readProductClassification(productClassificationLoadRequest.getFileName());
        productClassificationService.productClassificationLoad(productClassificationLoadRequest);
    }

    @Test(expected = IOException.class)
    public void shouldThrowIOExceptionReadInvalidProductClassificationFile() throws FileNotFoundException, IOException {
        productClassificationLoadRequest.setFileName("actually_a_directory.csv");
        doThrow(new IOException()).when(productClassificationCSVReader).readProductClassification(productClassificationLoadRequest.getFileName());
        productClassificationService.productClassificationLoad(productClassificationLoadRequest);
    }

    @Test
    public void shouldConvertUp() {
        List<ProductClassification> result = productClassificationService.convertUp(productClassificationEntityList);
        assertEquals(1, result.size());
        ProductClassification productClassification = result.get(0);
        verifyProductClassificationResult(productClassification);
    }

    @Test
    public void shouldFindProduct() throws ProductClassificationNotFoundException {
        when(productClassificationRepository.findByProductId(PRODUCT_ID)).thenReturn(productClassificationEntity);
        verifyProductClassificationResult(productClassificationService.findProductClassification(PRODUCT_ID));
    }

    @Test(expected = ProductClassificationNotFoundException.class)
    public void unknownProductClassificationShouldThrowProductClassificationNotFoundException() throws ProductClassificationNotFoundException {
        when(productClassificationRepository.findByProductId(PRODUCT_ID)).thenReturn(null);
        productClassificationService.findProductClassification(PRODUCT_ID);
    }

    @Test
    public void shouldLoadProductClassification() throws JsonProcessingException, FileNotFoundException, IOException {
        ArrayList<ProductClassificationRow> data = new ArrayList<ProductClassificationRow>();
        data.add(getProductClassificationRow());
        when(productClassificationCSVReader.readProductClassification(productClassificationLoadRequest.getFileName())).thenReturn(data);
        List<ProductClassificationEntity> ProductClassificationRows = productClassificationService
                .productClassificationLoad(productClassificationLoadRequest);
        assertEquals(1, ProductClassificationRows.size());
    }

    @Test
    public void shouldSkipProductClassification() throws JsonProcessingException, FileNotFoundException, IOException, ProductNotFoundException {
        productClassificationService = new ProductClassificationService(productClassificationRepository, productClassificationCSVReader,
                mockProductClassificationMapper, productService);
        ArrayList<ProductClassificationRow> data = new ArrayList<ProductClassificationRow>();
        ProductClassificationRow productClassificationRow = getProductClassificationRow();
        data.add(getProductClassificationRow());
        Product product = DomainStereotypeUtil.getProduct();
        product.setProductId(productClassificationRow.getProductId());
        when(productClassificationCSVReader.readProductClassification(productClassificationLoadRequest.getFileName())).thenReturn(data);
        when(mockProductClassificationMapper.map(any(ProductClassificationEntity.class), any(Product.class))).thenReturn(product);
        doThrow(new ProductNotFoundException("")).when(productService).updateProductClassification(productClassificationLoadRequest.getSegmentCd(),
                product.getProductId(), product);
        List<ProductClassificationEntity> ProductClassificationRows = productClassificationService
                .productClassificationLoad(productClassificationLoadRequest);
        assertEquals(1, ProductClassificationRows.size());
    }

    @Test
    public void shouldSaveProductClassificationFile() {
        List<ProductClassificationEntity> newList = new ArrayList<ProductClassificationEntity>();
        productClassificationService.save(newList);
    }

    @Test
    public void shouldConvertToEntity() {
        List<ProductClassificationRow> rows = new ArrayList<ProductClassificationRow>();
        rows.add(getProductClassificationRow());
        List<ProductClassificationEntity> result = productClassificationService.convertDown(SEGMENT_CD, rows);
        assertEquals(1, result.size());
    }

    @Test
    public void verifyProductClassificationLoadRequest() {
        assertEquals(ProductClassification_CSV, productClassificationLoadRequest.getFileName());
    }

    private void verifyProductClassificationResult(ProductClassification productClassification) {
        assertEquals(PRODUCT_ID, productClassification.getProductId());
        assertEquals(ASX_CODE, productClassification.getAsxCd());
        assertEquals(APIR_CODE, productClassification.getApirCd());
        assertEquals(PRODUCT_NAME, productClassification.getProductName());
        assertEquals(ASSET_CLASS_CD, productClassification.getAssetClassName());
        assertEquals(SECTOR_CD, productClassification.getSectorName());
        assertEquals(SUB_SECTOR_CD, productClassification.getSubSectorName());
        assertEquals(PRODUCT_CLASS_NAME, productClassification.getProductClassName());
    }

    @Test
    public void verifyProductClassificationEntity() {
        assertEquals(PRODUCT_ID, productClassificationEntity.getProductId());
        assertEquals(SEGMENT_CD, productClassificationEntity.getSegmentCd());
        assertEquals(ASX_CODE, productClassificationEntity.getAsxCd());
        assertEquals(APIR_CODE, productClassificationEntity.getApirCd());
        assertEquals(PRODUCT_NAME, productClassificationEntity.getProductName());
        assertEquals(ASSET_CLASS_CD, productClassificationEntity.getAssetClassName());
        assertEquals(SECTOR_CD, productClassificationEntity.getSectorName());
        assertEquals(SUB_SECTOR_CD, productClassificationEntity.getSubSectorName());
        assertEquals(PRODUCT_CLASS_NAME, productClassificationEntity.getProductClass());
    }

}