package au.com.lonsec.service.company.configproperty;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.codehaus.jettison.json.JSONException;
import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ConfigPropertyTest {

    private static final String KEY2 = "KEY2";

    private static final String KEY1 = "KEY1";

    private final static String JSON_STRING = "{\"entityId\":\"entityId\",\"type\":\"COMPANY\",\"propertyList\":[{\"key\":\"key1\",\"value\":\"value1\",\"type\":\"COMPANY\"}]}";

    private ObjectMapper mapper;

    @Before
    public void setup() {
        mapper = new ObjectMapper();
    }

    @Test
    public void shouldSerialize() throws JsonProcessingException {
        ConfigDTO configDTO = new ConfigDTO();
        List<ConfigProperty> propertyList = new ArrayList<ConfigProperty>();
        ConfigProperty configProperty = new ConfigProperty();
        configProperty.setKey("key1");
        configProperty.setValue("value1");
        configProperty.setType(ConfigPropertyType.COMPANY);
        propertyList.add(configProperty);
        configDTO.setType(ConfigPropertyType.COMPANY.name());
        configDTO.setPropertyList(propertyList);
        configDTO.setEntityId("entityId");

        String json = this.mapper.writeValueAsString(configDTO);
        assertEquals(JSON_STRING, json);
    }

    @Test
    public void shouldDeserializeConfigType() {
        ConfigPropertyType configPropertyType = ConfigPropertyType.valueOf("COMPANY");
        assertEquals(ConfigPropertyType.COMPANY, configPropertyType);
    }

    @Test
    public void shouldDeserialize() throws JSONException, JsonParseException, JsonMappingException, IOException {
        ConfigDTO configDTO = mapper.readValue(JSON_STRING, ConfigDTO.class);
        ConfigPropertyType config = ConfigPropertyType.valueOf(configDTO.getType());
        assertEquals(ConfigPropertyType.COMPANY, config);
        assertEquals(1, configDTO.getPropertyList().size());
    }

    @Test
    public void testEquality() {
        ConfigProperty configProperty1 = createConfigProperty(KEY1, ConfigPropertyType.COMPANY);
        ConfigProperty configProperty2 = createConfigProperty(KEY1, ConfigPropertyType.COMPANY);
        configProperty2.setKey(KEY1);
        configProperty2.setType(ConfigPropertyType.COMPANY);
        assertTrue(configProperty1.equals(configProperty2));
        assertTrue(configProperty1.toString().contains(KEY1));
    }

    private ConfigProperty createConfigProperty(String key, ConfigPropertyType type) {
        ConfigProperty configProperty = new ConfigProperty();
        configProperty.setKey(key);
        configProperty.setType(type);
        return configProperty;
    }

    @Test
    public void testInEquality() {
        ConfigProperty configProperty1 = createConfigProperty(KEY1, ConfigPropertyType.COMPANY);
        ConfigProperty configProperty2 = createConfigProperty(KEY2, ConfigPropertyType.COMPANY);
        ConfigPropertyEntity configPropertyEntity = new ConfigPropertyEntity();
        assertFalse(configProperty1.equals(configProperty2));
        assertFalse(configProperty1.equals(configPropertyEntity));
    }

}