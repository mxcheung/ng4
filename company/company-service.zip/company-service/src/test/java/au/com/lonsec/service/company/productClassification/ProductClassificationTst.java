package au.com.lonsec.service.company.productClassification;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import au.com.lonsec.service.company.product.model.Product;
import au.com.lonsec.service.company.productClassification.client.model.ProductClassificationGetRequest;
import au.com.lonsec.service.company.productClassification.client.model.ProductClassificationLoadRequest;
import au.com.lonsec.service.company.productClassification.model.ProductClassification;

public class ProductClassificationTst {

    protected static final String ProductClassification_CSV = "productclassification-test.csv";
    protected static final String ProductClassification_FOLDER = "src/test/";

    protected static final String SEGMENT_CD = "LR";

    protected static final String PRODUCT_ID = "MF-1-31215";
    protected static final String APIR_CODE = "MAQ0061AU";
    protected static final String ASX_CODE = "ASX";
    protected static final String PRODUCT_NAME = "BetaShares Australian Small Companies Select Fund";
    protected static final String ASSET_CLASS_NAME = "Australian Equities";
    protected static final String SECTOR_NAME = "Australian Smaller Companies";
    protected static final String ASSET_CLASS_CD = "AEQ";
    protected static final String SECTOR_CD = "AEQ:ALP";
    protected static final String SUB_SECTOR_CD = "AEQ:ALP:AR";
    protected static final String PRODUCT_CLASS_CD = "ETF";
    protected static final String PRODUCT_CLASS_NAME = "ETF";

    protected ProductClassificationLoadRequest productClassificationLoadRequest;
    protected ProductClassificationGetRequest productClassificationGetRequest;
    protected ProductClassificationEntity productClassificationEntity;
    protected ProductClassificationRow productClassificationRow;
    protected List<ProductClassificationEntity> productClassificationEntityList;
    protected List<ProductClassification> productClassificationList;

    public ProductClassificationTst() {
        super();
    }

    protected ProductClassificationGetRequest getProductClassificationGetRequest() {
        ProductClassificationGetRequest ProductClassificationGetRequest = new ProductClassificationGetRequest();
        return ProductClassificationGetRequest;
    }

    protected ProductClassificationLoadRequest getProductClassificationLoadRequest() {
        ProductClassificationLoadRequest productClassificationLoadRequest = new ProductClassificationLoadRequest();
        productClassificationLoadRequest.setSegmentCd(SEGMENT_CD);
        productClassificationLoadRequest.setFileName(ProductClassification_CSV);
        return productClassificationLoadRequest;
    }

    protected List<ProductClassification> getProductClassifications() {
        List<ProductClassification> ProductClassifications = new ArrayList<ProductClassification>();
        ProductClassifications.add(getProductClassification());
        return ProductClassifications;
    }

    protected ProductClassification getProductClassification() {
        ProductClassification productClassification = new ProductClassification();
        productClassification.setProductId(PRODUCT_ID);
        productClassification.setApirCd(APIR_CODE);
        productClassification.setAsxCd(ASX_CODE);
        productClassification.setProductName(PRODUCT_NAME);
        productClassification.setAssetClassName(ASSET_CLASS_CD);
        productClassification.setSectorName(SECTOR_CD);
        productClassification.setSubSectorName(SUB_SECTOR_CD);
        productClassification.setProductClassName(PRODUCT_CLASS_NAME);

        return productClassification;
    }

    protected ProductClassificationRow getProductClassificationRow() {
        ProductClassificationRow row = new ProductClassificationRow(APIR_CODE, PRODUCT_ID, ASX_CODE, PRODUCT_NAME, ASSET_CLASS_CD, SECTOR_CD,
                SUB_SECTOR_CD, PRODUCT_CLASS_NAME);
        row.setProductId(PRODUCT_ID);
        row.setApirCd(APIR_CODE);
        row.setAsxCd(ASX_CODE);
        row.setProductName(PRODUCT_NAME);
        row.setAssetClassName(ASSET_CLASS_CD);
        row.setSectorName(SECTOR_CD);
        row.setSubSectorName(SUB_SECTOR_CD);
        row.setProductClass(PRODUCT_CLASS_NAME);
        return row;
    }

    protected ProductClassificationEntity getProductClassificationEntity() {
        ProductClassificationEntity productClassificationEntity = new ProductClassificationEntity();
        productClassificationEntity.setProductId(PRODUCT_ID);
        productClassificationEntity.setSegmentCd(SEGMENT_CD);
        productClassificationEntity.setApirCd(APIR_CODE);
        productClassificationEntity.setAsxCd(ASX_CODE);
        productClassificationEntity.setProductName(PRODUCT_NAME);
        productClassificationEntity.setAssetClassName(ASSET_CLASS_CD);
        productClassificationEntity.setSectorName(SECTOR_CD);
        productClassificationEntity.setSubSectorName(SUB_SECTOR_CD);
        productClassificationEntity.setProductClass(PRODUCT_CLASS_NAME);
        return productClassificationEntity;
    }

    protected List<ProductClassificationEntity> getProductClassificationEntityList() {
        List<ProductClassificationEntity> productClassificationEntityList = new ArrayList<ProductClassificationEntity>();
        productClassificationEntityList.add(getProductClassificationEntity());
        return productClassificationEntityList;
    }
    
    protected void verifyProductClassification(ProductClassificationEntity productClassification) {
        assertEquals(PRODUCT_ID, productClassification.getProductId());
        assertEquals(ASX_CODE, productClassification.getAsxCd());
        assertEquals(APIR_CODE, productClassification.getApirCd());
        assertEquals(PRODUCT_NAME, productClassification.getProductName());
        assertEquals(ASSET_CLASS_CD, productClassification.getAssetClassName());
        assertEquals(SECTOR_CD, productClassification.getSectorName());
        assertEquals(SUB_SECTOR_CD, productClassification.getSubSectorName());
        assertEquals(PRODUCT_CLASS_NAME, productClassification.getProductClass());
    }
    
    protected void verifyProductClassification(ProductClassification productClassification) {
        assertEquals(PRODUCT_ID, productClassification.getProductId());
        assertEquals(ASX_CODE, productClassification.getAsxCd());
        assertEquals(APIR_CODE, productClassification.getApirCd());
        assertEquals(PRODUCT_NAME, productClassification.getProductName());
        assertEquals(ASSET_CLASS_CD, productClassification.getAssetClassName());
        assertEquals(SECTOR_CD, productClassification.getSectorName());
        assertEquals(SUB_SECTOR_CD, productClassification.getSubSectorName());
        assertEquals(PRODUCT_CLASS_NAME, productClassification.getProductClassName());
    }
    
    
    protected void verifyProductClassification(Product product) {
        assertEquals(APIR_CODE, product.getApirCd());
        assertEquals(ASX_CODE, product.getAsxCd());
        assertEquals(ASSET_CLASS_CD, product.getAssetClassCd());
        assertEquals(SECTOR_CD, product.getSectorCd());
        assertEquals(SUB_SECTOR_CD, product.getSubSectorCd());
        assertEquals(PRODUCT_CLASS_CD, product.getProductClassCd());
    }

}