package au.com.lonsec.service.company.lookup;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLDecoder;
import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.RuntimeJsonMappingException;

public class LookupCSVReaderTest extends LookupTst {

    private LookupCSVReader lookupCSVReader;

    private static final Logger LOGGER = LoggerFactory.getLogger(LookupCSVReaderTest.class);
    
    private static final File resourcesDirectory = new File("src/test/resources/");
    

    @Before
    public void setup() {
        lookupCSVReader = new LookupCSVReader();
        lookupCSVReader.setLookupFolder(LOOKUP_FOLDER);
    }

    @Test(expected = FileNotFoundException.class)
    public void shouldThrowFileNotFoundExceptionWhenReadInvalidLookupFile() throws FileNotFoundException, IOException {
        lookupCSVReader.readLookup("NonExistentFile");
    }

    @Test(expected = RuntimeJsonMappingException.class)
    public void shouldThrowExceptionReadInvalidLookupFile() throws FileNotFoundException, IOException {
        InputStream inputStream = getInputStream("lookup-invalid-file.txt");
        LOGGER.info("Read invalid lookup file");
        lookupCSVReader.readLookup(inputStream);
    }

    @Test(expected = IOException.class)
    public void shouldThrowIOExceptionReadInvalidLookupFile() throws FileNotFoundException, IOException {
        lookupCSVReader.readLookup("actually_a_directory.csv");
    }

    @Test
    public void shouldReadLookupFolder() {
        assertEquals(LOOKUP_FOLDER, lookupCSVReader.getLookupFolder());
    }

    @Test
    public void shouldReadLookupFromFile() throws JsonProcessingException, FileNotFoundException, IOException {
        lookupCSVReader.setLookupFolder(resourcesDirectory.getAbsolutePath() + "//");
        ArrayList<LookupRow> lookupRows = lookupCSVReader.readLookup(LOOKUP_CSV);
        assertEquals(12, lookupRows.size());
    }

    
    
    @Test
    public void shouldReadLookupFromInputStream() throws JsonProcessingException, FileNotFoundException, IOException {
        InputStream inputStream = getInputStream(LOOKUP_CSV);
        LOGGER.info("File to InputStream");
        ArrayList<LookupRow> lookupRows = lookupCSVReader.readLookup(inputStream);
        assertEquals(12, lookupRows.size());
    }

    private InputStream getInputStream(String lookupFileName) throws FileNotFoundException, UnsupportedEncodingException {
        URL url = getClass().getClassLoader().getResource(lookupFileName);
        File lookupFile = new File(URLDecoder.decode(url.getFile(), "UTF-8"));
        InputStream inputStream = new FileInputStream(lookupFile);
        return inputStream;
    }

}