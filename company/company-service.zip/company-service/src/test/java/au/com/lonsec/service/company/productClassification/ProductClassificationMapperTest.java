package au.com.lonsec.service.company.productClassification;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.Test;

import au.com.lonsec.service.company.product.model.Product;
import au.com.lonsec.service.company.productClassification.model.ProductClassification;

public class ProductClassificationMapperTest extends ProductClassificationTst {

    private static final String HIERARCHY_DELIMITER = ":";
    private static final String EMPTY_STRING = "";
    private static final String AEQ_ALP = "AEQ:ALP";
    private static final String AEQ = "AEQ";
    private static final String AEQ_ALP_AR = "AEQ:ALP:AR";
    private ProductClassificationMapper productClassificationMapper;

    @Before
    public void setup() {
        productClassificationMapper = new ProductClassificationMapper();
        productClassificationRow = getProductClassificationRow();
        productClassificationEntity = getProductClassificationEntity();
    }

    @Test
    public void shouldMapRowToEntity() {
        ProductClassificationEntity result = productClassificationMapper.map(productClassificationRow, new ProductClassificationEntity());
        verifyProductClassification(result);
    }

    @Test
    public void shouldMapEntityToModel() {
        ProductClassification result = productClassificationMapper.map(productClassificationEntity, new ProductClassification());
        verifyProductClassification(result);
    }

    @Test
    public void shouldMapEntityToProduct() {
        Product result = productClassificationMapper.map(productClassificationEntity, new Product());
        verifyProductClassification(result);
    }


    @Test
    public void shouldMapEntityWithMissingSubSectorCdToProduct() {
        productClassificationEntity.setAssetClassName(ASSET_CLASS_NAME);
        productClassificationEntity.setSectorName(SECTOR_NAME);
        productClassificationEntity.setSubSectorName(null);
        Product result = productClassificationMapper.map(productClassificationEntity, new Product());
        assertEquals(EMPTY_STRING, result.getAssetClassCd());
        assertEquals(EMPTY_STRING, result.getSectorCd());
        assertEquals(EMPTY_STRING, result.getSubSectorCd());
    }
    
    
    @Test
    public void shouldDeriveClassificationPart() {
        List<String> hierarchy;
        hierarchy = getHierarchy(AEQ_ALP_AR);
        assertEquals(AEQ, productClassificationMapper.getClassificationPart(hierarchy, 1));
        assertEquals(AEQ_ALP, productClassificationMapper.getClassificationPart(hierarchy, 2));
        assertEquals(AEQ_ALP_AR, productClassificationMapper.getClassificationPart(hierarchy, 3));
        
        hierarchy = getHierarchy(AEQ_ALP);
        assertEquals(AEQ, productClassificationMapper.getClassificationPart(hierarchy, 1));
        assertEquals(AEQ_ALP, productClassificationMapper.getClassificationPart(hierarchy, 2));

    
        hierarchy = getHierarchy(AEQ);
        assertEquals(AEQ, productClassificationMapper.getClassificationPart(hierarchy, 1));
        assertEquals(EMPTY_STRING, productClassificationMapper.getClassificationPart(hierarchy, 2));
        
        hierarchy = getHierarchy(AEQ_ALP);
        assertEquals(AEQ, productClassificationMapper.getClassificationPart( hierarchy, 1));
        assertEquals(AEQ_ALP, productClassificationMapper.getClassificationPart(hierarchy, 2));
        assertEquals(EMPTY_STRING, productClassificationMapper.getClassificationPart(hierarchy, 3));
    }
    
    private List<String> getHierarchy(String productHierarchy ){
        String[] hierarchy = StringUtils.split(productHierarchy, HIERARCHY_DELIMITER);
        return  Optional.ofNullable(hierarchy).map(Arrays::stream).orElseGet(Stream::empty).collect(Collectors.toList());
    }

}