package au.com.lonsec.service.company.productDashboard;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import au.com.lonsec.service.company.lookup.LookupService;
import au.com.lonsec.service.company.product.ProductService;
import au.com.lonsec.service.company.productClassification.ProductClassificationNotFoundException;
import au.com.lonsec.service.company.productClassification.ProductClassificationService;
import au.com.lonsec.service.company.productDashboard.model.ProductDashboardRow;
import au.com.lonsec.service.company.segment.SegmentNotFoundException;
import au.com.lonsec.service.company.segment.SegmentService;
import au.com.lonsec.service.company.web.DpProfile;

@RunWith(MockitoJUnitRunner.class)
public class ProductDashboardServiceTest extends ProductDashboardTst {

    private ProductDashboardService productDashboardService;

    @Mock
    private SegmentService segmentService;

    @Mock
    private ProductService productService;

    @Mock
    private ProductClassificationService productClassificationService;

    @Mock
    private ProductDashboardMapper productDashboardMapper;

    @Mock
    private LookupService lookupService;
    
    private static final String PROFILE_TOKEN = "eyJpZCI6ICJmZjFjNjFiYS1iYWQzLTExZTctYWJjNC1jZWMyNzhiNmI1MGEiLCJ1c2VybmFtZSI6ICJEUF9TUl9FTVBfQURNSU4iLCJzZWdtZW50IjoiU1IiLCJleHRJZCI6IjAwMCIsInJvbGUiOiAiNDgifQ==";
    
    
    @Before
    public void setup() {
        productDashboardDTO = getProductDashboardDTO();
        product = getProduct();
        products = getProducts();
        segment = getSegment();
        lookups = getLookUps();
        productDashboardRow = getProductDashboardRow();
        productDashboardService = new ProductDashboardService(segmentService, productService, productClassificationService, productDashboardMapper, lookupService);
    }

    @Test
    public void shouldFindProducts() throws Exception {
        DpProfile profile = DpProfile.fromToken(PROFILE_TOKEN, "test");
        when(productService.findProducts(SEGMENT_CD, profile)).thenReturn(products);
        when(segmentService.findSegment(SEGMENT_CD, EXT_UNIQUE_KEY)).thenReturn(segment);
        when(productDashboardMapper.map(any(),any(ProductDashboardDTO.class), any(ProductDashboardRow.class))).thenReturn(productDashboardRow);
        List<ProductDashboardRow> result = productDashboardService.findProducts(SEGMENT_CD, profile);
        assertEquals(1, result.size());
        verifyProductDashboardRow(result.get(0));
    }

    @Test
    public void shouldHandleMissingSegment() throws SegmentNotFoundException {
        doThrow(new SegmentNotFoundException("")).when(segmentService).findSegment(SEGMENT_CD, EXT_UNIQUE_KEY);
        ProductDashboardDTO result = productDashboardService.fetchAssociation(SEGMENT_CD, product);
        assertNull(result.getSegment());
    }

    @Test
    public void shouldHandleMissingClassification() throws ProductClassificationNotFoundException {
        doThrow(new ProductClassificationNotFoundException("")).when(productClassificationService).findProductClassification(PRODUCT_ID);
        ProductDashboardDTO result = productDashboardService.fetchAssociation(SEGMENT_CD, product);
        assertNull(result.getProductClassification());
    }

}