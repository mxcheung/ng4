package au.com.lonsec.service.company.company;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import au.com.lonsec.service.company.company.model.Company;

@RunWith(MockitoJUnitRunner.class)
public class CompanyServiceTest extends CompanyTst {

    private CompanyService companyService;

    @Mock
    private CompanyRepository companyRepository;

    @Before
    public void setup() {
        companyService = new CompanyService(companyRepository);
        company = getCompany();
        companyEntity = getCompanyEntity();
        companyAddRequest = getCompanyAddRequest();
        companyUpdateRequest = getCompanyUpdateRequest();
        companyGetByIdsRequest = getCompanyGetByIdsRequest();
    }

    @Test(expected = CompanyNotFoundException.class)
    public void shouldThrowCompanyNotFoundException() throws CompanyNotFoundException {
        when(companyRepository.findById(COMPANY_UUID)).thenReturn(null);
        companyService.findCompany(COMPANY_ABN);
    }

    @Test
    public void shouldReturnValidCompany() throws CompanyNotFoundException {
        when(companyRepository.findById(COMPANY_UUID)).thenReturn(companyEntity);
        when(companyRepository.findByAbn(COMPANY_ABN)).thenReturn(companyEntity);
        Company company = companyService.findCompany(COMPANY_ABN);
        verifyResult(company);
        verify(companyRepository, times(1)).findByAbn(COMPANY_ABN);
        verifyNoMoreInteractions(companyRepository);
    }

    @Test
    public void shouldCreateCompany() {
        when(companyRepository.findByAbn(COMPANY_ABN)).thenReturn(null);
        Company company = companyService.createCompany(companyAddRequest);
        verifyResult(company);
        assertEquals(companyAddRequest.getParentId(), company.getParentId());
        verify(companyRepository, times(1)).findByAbn(COMPANY_ABN);
        verify(companyRepository, times(1)).save(any(CompanyEntity.class));
        verifyNoMoreInteractions(companyRepository);
    }

    @Test
    public void shouldfetchByABNs() {
        when(companyRepository.findByAbn(COMPANY_ABN)).thenReturn(companyEntity);
        Map<String, Company> companyMap = companyService.fetchByABNs(companyGetByIdsRequest);
        assertEquals(1, companyMap.size());
        verify(companyRepository, times(1)).findByAbn(COMPANY_ABN);
        verifyNoMoreInteractions(companyRepository);
    }

    @Test
    public void fetchByABNsReturnEmptyList() {
        when(companyRepository.findByAbn(COMPANY_ABN)).thenReturn(null);
        Map<String, Company> companyMap = companyService.fetchByABNs(companyGetByIdsRequest);
        assertEquals(0, companyMap.size());
        verify(companyRepository, times(1)).findByAbn(COMPANY_ABN);
        verifyNoMoreInteractions(companyRepository);
    }

    @Test
    public void shouldSaveExistingCompany() {
        when(companyRepository.findByAbn(COMPANY_ABN)).thenReturn(companyEntity);
        Company company = companyService.createCompany(companyAddRequest);
        verifyResult(company);
        assertEquals(companyAddRequest.getParentId(), company.getParentId());
        verify(companyRepository, times(1)).findByAbn(COMPANY_ABN);
        verify(companyRepository, times(1)).save(companyEntity);
        verifyNoMoreInteractions(companyRepository);
    }

    @Test
    public void shouldUpdateCompany() throws CompanyNotFoundException {
        when(companyRepository.findByAbn(COMPANY_ABN)).thenReturn(companyEntity);
        when(companyRepository.findById(COMPANY_UUID)).thenReturn(companyEntity);
        Company company = companyService.updateCompany(companyUpdateRequest);
        verifyResult(company);
    }

    @Test(expected = CompanyNotFoundException.class)
    public void unknownCompanyshouldThrowCompanyNotFoundException() throws CompanyNotFoundException {
        when(companyRepository.findByAbn(COMPANY_ABN)).thenReturn(null);
        companyService.updateCompany(companyUpdateRequest);
    }

    private void verifyResult(Company company) {
        assertEquals(COMPANY_NAME, company.getCompanyName());
        assertEquals(COMPANY_ABN, company.getAbn());
        assertEquals(COMPANY_ADDRESS, company.getAddress());
        assertEquals(ACTIVE, company.getStatus());
    }

}