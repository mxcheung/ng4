package au.com.lonsec.service.company.companyDashboard;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import au.com.lonsec.service.company.company.model.Company;
import au.com.lonsec.service.company.companyDashboard.client.model.CompanyDashboardRowsGetResponse;
import au.com.lonsec.service.company.companyDashboard.model.CompanyDashboardRow;
import au.com.lonsec.service.company.companyDashboard.model.SegmentAttribute;
import au.com.lonsec.service.company.configproperty.ConfigProperty;
import au.com.lonsec.service.company.configproperty.ConfigPropertyType;
import au.com.lonsec.service.company.domain.DomainStereotypeUtil;
import au.com.lonsec.service.company.segment.SegmentEntity;
import au.com.lonsec.service.company.segment.model.Segment;

public abstract class CompanyDashboardTst {

    protected static final String ID = "81dd92a4-be95-47ca-9922-12f29c05da8c";
    protected static final UUID PRODUCT_UUID = UUID.fromString(ID);

    protected static final String SEGMENT_CD = "SR";
    protected static final String EXT_UNIQUE_KEY = "276";

    protected static final String SEGMENT_UUID = "126be751-86ee-454f-bcce-4752df2c5594";
    protected static final String NOTES = "notes";

    protected static final String ANALYST = "analyst";
    protected static final String COMPANY_ABN = "12345678901";
    protected static final String COMPANY_NAME = "Company_Name";
    protected static final String COMPANY_ID = "523be751-86ee-454f-bcce-4752df2c1234";

    
    protected static final String VALUE1 = "Value1";
    protected static final String KEY1 = "Key1";
    
    protected CompanyDashboardDTO companyDashboardDTO;
    protected CompanyDashboardRow companyDashboardRow;
    protected Company product;
    protected Segment segment;
    protected List<Segment> segments;    
    protected SegmentEntity segmentEntity;
    protected CompanyDashboardRowsGetResponse companyDashboardRowsGetResponse;

    protected Date today = new Date();
    protected List<Company> products;
    protected List<SegmentEntity> segmentEntityList;
    protected List<CompanyDashboardRow> companyDashboardRows;
    protected Map<String, Map<String, String>> lookups;

    public CompanyDashboardTst() {
        super();
    }

    protected CompanyDashboardRowsGetResponse getCompanyDashboardRowsGetResponse() {
        CompanyDashboardRowsGetResponse companyDashboardRowsGetResponse = new CompanyDashboardRowsGetResponse();
        companyDashboardRowsGetResponse.setCompanyDashboardRows(getCompanyDashboardRows());
        return companyDashboardRowsGetResponse;
    }

    protected List<CompanyDashboardRow> getCompanyDashboardRows() {
        List<CompanyDashboardRow> products = new ArrayList<CompanyDashboardRow>();
        products.add(getCompanyDashboardRow());
        return products;
    }
    
    protected static Map<String, Map<String, String>> getLookUps() {
        return DomainStereotypeUtil.getLookUps();
    }    

    public static CompanyDashboardDTO getCompanyDashboardDTO() {
        CompanyDashboardDTO companyDashboardDTO = new CompanyDashboardDTO();
        companyDashboardDTO.setSegment(getSegment());
        companyDashboardDTO.setPropertyList(getPropertyList());
        return companyDashboardDTO;
    }

    private static List<ConfigProperty> getPropertyList() {
        List<ConfigProperty> propertyList = new ArrayList<ConfigProperty>();
        ConfigProperty configProperty1 = createConfigProperty(KEY1, ConfigPropertyType.COMPANY);
        propertyList.add(configProperty1);
        return propertyList;
    }
    
    private static ConfigProperty createConfigProperty(String key, ConfigPropertyType type) {
        ConfigProperty configProperty = new ConfigProperty();
        configProperty.setKey(key);
        configProperty.setType(type);
        return configProperty;
    }

    public static CompanyDashboardRow getCompanyDashboardRow() {
        CompanyDashboardRow company = new CompanyDashboardRow();
        company.setId(ID);
        company.setSegmentCd(SEGMENT_CD);
        company.setExtUniqueKey(EXT_UNIQUE_KEY);
        company.setAnalyst(ANALYST);
        company.setCompanyId(COMPANY_ID);
        company.setCompanyName(COMPANY_NAME);
        company.setAbn(COMPANY_ABN);
        company.setNotes(NOTES);
        company.setActive(true);
        company.setAttributes(getAttributes());
        return company;
    }
    
    protected static List<SegmentAttribute> getAttributes(){
        return DomainStereotypeUtil.getAttributes();
    }

    protected static Segment getSegment() {
        return DomainStereotypeUtil.getSegment();
    }

    protected static List<Segment> getSegments() {
        return DomainStereotypeUtil.getSegments();
    }

    protected SegmentEntity getSegmentEntity() {
        return DomainStereotypeUtil.getSegmentEntity();
    }

    protected List<SegmentEntity> getSegmentEntityList() {
        List<SegmentEntity> segmentEntityList = new ArrayList<SegmentEntity>();
        segmentEntityList.add(getSegmentEntity());
        return segmentEntityList;
    }

    protected void verifyCompanyDashboardRow(CompanyDashboardRow segment) {
        assertEquals(ANALYST, segment.getAnalyst());
        assertEquals(EXT_UNIQUE_KEY, segment.getExtUniqueKey());
        assertEquals(COMPANY_NAME, segment.getCompanyName());
    }

    protected void verifyEmptySegment(CompanyDashboardRow segment) {
        assertNull( segment.getAnalyst());
        assertNull( segment.getCompanyName());
    }
    

    
    

}