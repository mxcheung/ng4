
---------------------------------------------------------------------------------------
-- Add product additional classification fields
---------------------------------------------------------------------------------------
IF NOT EXISTS ( SELECT * FROM syscolumns WHERE id = OBJECT_ID('product') AND name = 'asx_cd' )
BEGIN
	ALTER TABLE product ADD asx_cd VARCHAR(255);
END

IF NOT EXISTS ( SELECT * FROM syscolumns WHERE id = OBJECT_ID('product') AND name = 'asset_class_cd' )
BEGIN
	ALTER TABLE product ADD asset_class_cd VARCHAR(255);
END

IF NOT EXISTS ( SELECT * FROM syscolumns WHERE id = OBJECT_ID('product') AND name = 'sector_cd' )
BEGIN
	ALTER TABLE product ADD sector_cd VARCHAR(255);
END

IF NOT EXISTS ( SELECT * FROM syscolumns WHERE id = OBJECT_ID('product') AND name = 'sub_sector_cd' )
BEGIN
	ALTER TABLE product ADD sub_sector_cd VARCHAR(255);
END

IF NOT EXISTS ( SELECT * FROM syscolumns WHERE id = OBJECT_ID('product') AND name = 'product_class_cd' )
BEGIN
	ALTER TABLE product ADD product_class_cd VARCHAR(255);
END


---------------------------------------------------------------------------------------
-- Add segment notes fields
---------------------------------------------------------------------------------------

IF NOT EXISTS ( SELECT * FROM syscolumns WHERE id = OBJECT_ID('segment') AND name = 'notes' )
BEGIN
	ALTER TABLE segment ADD notes VARCHAR(255);
END

 