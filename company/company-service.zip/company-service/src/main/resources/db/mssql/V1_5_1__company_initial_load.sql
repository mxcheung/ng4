IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '11008423372' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '11008423372','Zurich Financial Services Australia Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '11079147809' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '11079147809','Cromwell Property Securities Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '11158929143' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '11158929143','Auscap Asset Management Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '11162591568' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '11162591568','Channel Capital Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '11789425178' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '11789425178','Mercy Super', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '12004021809' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '12004021809','The Colonial Mutual Life Assurance Society Limited ', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '12004044937' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '12004044937','National Australia Bank Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '12098327809' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '12098327809','CBG Asset Management Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '12126526690' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '12126526690','Newmark Capital Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '12737334298' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '12737334298','Club Super', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '13006165975' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '13006165975','BlackRock Investment Management (Australia) Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '13050064287' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '13050064287','Platinum Asset Management', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '13064523619' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '13064523619','Lazard Asset Management Pacific Co', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '13073845931' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '13073845931','Fiducian Portfolio Services Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '13355603448' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '13355603448','ING DIRECT Superannuation Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '13704288646' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '13704288646','LESF Super', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '14078030752' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '14078030752','Investors Mutual Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '14125715004' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '14125715004','Grant Samuel Fund Management Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '14602032302' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '14602032302','Tasplan Super', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '15101387964' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '15101387964','Orbis Investment Advisory Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '15149971808' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '15149971808','Farnam Investment Management Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '15201768813' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '15201768813','Nationwide Superannuation Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '15549636673' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '15549636673','QIEC Super', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '16004030737' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '16004030737','Sandhurst Trustees Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '16107084640' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '16107084640','Goldman Sachs Financial Markets Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '16457520308' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '16457520308','Mine Wealth and Wellbeing Superannuation Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '17129606775' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '17129606775','Arnhem Investment Management Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '17137088745' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '17137088745','Atrium Investment Management Pty Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '17317520544' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '17317520544','Meat Industry Employees Super Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '17608890083' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '17608890083','Oracle Superannuation Plan', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '18000866535' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '18000866535','Perpetual Investment Management Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '18136960775' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '18136960775','Sanlam Private Wealth Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '18159499614' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '18159499614','WA Local Government Superannuation Plan', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '18838658991' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '18838658991','EmPlus Superannuation Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '19381443479' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '19381443479','LGM Investments Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '19385614067' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '19385614067','FSP Super Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '19905422981' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '19905422981','Mercer Super Trust', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '20101634146' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '20101634146','MFS Investment Management Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '20135656236' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '20135656236','Triple Three Partners Pty Ltd ', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '20891605180' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '20891605180','TAL Superannuation and Insurance Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '21004715226' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '21004715226','Folkestone Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '21006797897' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '21006797897','JBWere Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '21059451252' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '21059451252','Concept One the Industry Superannuation Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '21125378145' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '21125378145','L1 Capital Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '21141096120' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '21141096120','Spire Capital Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '21871924959' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '21871924959','Progressive Superannuation Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '22000443274' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '22000443274','Schroder Investment Management Australia Limited ', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '22092872056' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '22092872056','OC Funds Management Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '22277243559' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '22277243559','Energy Industries Superannuation Scheme', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '22439141985' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '22439141985','Millennium Master Trust', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '22508720840' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '22508720840','max Super Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '22599554834' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '22599554834','Guild Retirement Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '22600471430' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '22600471430','Prodigy Investment Partners Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '23006715573' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '23006715573','Lincoln Indicators Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '23053121564' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '23053121564','Local Government Investment Australia (QLD)', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '23080376110' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '23080376110','Prime Value Asset Management Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '23107624126' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '23107624126','NAOS Asset Management Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '24000893292' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '24000893292','ING Direct', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '24248426878' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '24248426878','Commonwealth Bank Group Super', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '24496637884' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '24496637884','Local Authorities Superannuation Fund (Vision Super)', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '24680629023' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '24680629023','Australian Catholic Superannuation', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '25082852364' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '25082852364','Certitude Global Investments Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '26074398404' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '26074398404','Shed Enterprises Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '26076316473' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '26076316473','Ausbil Investment Management Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '26089987388' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '26089987388','Macquarie Private Portfolio Management ', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '26100409890' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '26100409890','Cooper Investors Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '26382680883' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '26382680883','Labour Union Cooperative Retirement Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '26458298557' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '26458298557','Colonial First State FirstChoice Superannuation Trust', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '28010639219' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '28010639219','DDH Graham Limited ', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '28163522254' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '28163522254','Munro Asset Management Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '28342064803' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '28342064803','Australian Meat Industry Super Trust (AMIST)', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '28901371321' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '28901371321','Local Government Super (NSW)', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '29082494362' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '29082494362','WHTM Capital Management Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '29125092677' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '29125092677','Insync Funds Management', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '29159382813' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '29159382813','Winston Capital Partners Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '29239066746' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '29239066746','State Super Pooled Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '29602042035' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '29602042035','Antipodes Partners Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '30006479527' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '30006479527','La Trobe Financial Services Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '30071502639' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '30071502639','GMO Australia Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '30099320583' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '30099320583','AMG Super Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '30103800568' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '30103800568','Pengana Capital Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '31003146290' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '31003146290','UBS Asset Management (Australia) Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '31096442198' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '31096442198','Spectrum Asset Management Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '31120593946' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '31120593946','Magellan Asset Management Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '32111283357' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '32111283357','Millinium Capital Managers Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '32367272075' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '32367272075','Grosvenor Pirie Master Super Fund - Series 2', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '32611709927' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '32611709927','MHOR Asset Management Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '33129188450' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '33129188450','VGI Partners Global Investments Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '33155937901' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '33155937901','Morphic Asset Management Pty Limited ', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '33632838393' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '33632838393','Zurich Master Superannuation Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '33761363685' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '33761363685','Energy Super', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '33813823017' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '33813823017','Equip Superannuation Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '34002542038' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '34002542038','Nikko Asset Management Australia Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '34006773575' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '34006773575','FIL Investments Management (Australia) Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '34110397674' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '34110397674','Ellerston Capital Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '34155984955' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '34155984955','Realm Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '34300938877' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '34300938877','Tidswell Master Superannuation Plan', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '35007519520' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '35007519520','Argo Investments Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '35600756241' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '35600756241','Pan-Tribal Asset Management Pty Ltd  ', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '36142665227' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '36142665227','Standard Life Investments Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '37024873660' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '37024873660','Victorian Independent Schools Superannuation Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '37124085883' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '37124085883','Alpha Fund Managers Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '37150161765' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '37150161765','Elston Asset Management Pty Ltd ', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '37155801817' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '37155801817','Cor Capital Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '38087480331' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '38087480331','BT Financial Group Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '38095135694' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '38095135694','Macquarie Financial Products Management Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '38099932920' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '38099932920','Treasury Group Ltd ', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '38116067255' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '38116067255','AQR Pty Ltd ', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '38531644711' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '38531644711','EquitySuper Master Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '38604095954' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '38604095954','India Avenue Investment Management Australia Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '38876896681' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '38876896681','Avanteos Superannuation Trust', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '39111214085' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '39111214085','Bennelong Funds Management Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '39827542991' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '39827542991','Retirement Wrap', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '40022701955' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '40022701955','MLC Superannuation Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '40236806679' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '40236806679','The Retirement Plan', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '40651037780' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '40651037780','Super SA', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '41006099681' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '41006099681','Goldman Sachs Asset Management Australia Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '41130021484' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '41130021484','Partners Group (UK) Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '41272198829' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '41272198829','Qantas Superannuation Plan', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '41772007500' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '41772007500','Perpetual WealthFocus Superannuation Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '42003914225' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '42003914225','State Street Global Advisors; Australia; Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '42045077895' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '42045077895','Australia Post Superannuation Scheme', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '42159623873' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '42159623873','Paragon Funds Management Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '42574421650' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '42574421650','Media Super', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '42611081326' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '42611081326','Spheria Asset Management ', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '43198502058' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '43198502058','Fire and Emergency Services Superannuation Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '43418292917' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '43418292917','Government Employees Superannuation Board (GESB)', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '43905581638' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '43905581638','Smartsave Members Choice Superannuation Master Plan', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '44128813016' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '44128813016','Instreet Investment Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '45003278831' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '45003278831','The Trust Company (RE Services) Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '45102488068' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '45102488068','Principal Global Investors (Australia) Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '45125580305' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '45125580305','Supervised Investments Australia Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '45828721007' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '45828721007','ClearView Retirement Plan', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '45960194277' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '45960194277','The Future Super Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '46004031298' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '46004031298','Equity Trustees Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '46008583542' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '46008583542','Macquarie Bank Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '46065937671' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '46065937671','DFA Australia Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '46921400504' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '46921400504','Combined Super', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '47002747480' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '47002747480','Man Investments Australia Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '47003188930' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '47003188930','Australian Ethical Investment Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '47088129613' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '47088129613','"UBS AG', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '47114316059' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '47114316059','Treasury Asia Asset Management Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '47124279518' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '47124279518','Janus Henderson Investors (Australia) Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '48000142049' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '48000142049','Perpetual Trust Services Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '48001693232' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '48001693232','Invesco Australia Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '48112316168' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '48112316168','Allan Gray Australia Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '48115826741' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '48115826741','Cbus Property Pty Ltd ', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '48123123124' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '48123123124','Commonwealth Bank of Australia', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '49092375258' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '49092375258','Ventura Investment Management Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '49620344668' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '49620344668','BOC Gases Superannuation Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '49633667743' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '49633667743','Australian Ethical Retail Superannuation Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '50002993302' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '50002993302','Challenger Financial Services Group Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '50108584167' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '50108584167','Resolution Capital Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '50237896957' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '50237896957','Catholic Superannuation Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '50436122863' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '50436122863','Robeco Hong Kong Limited ', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '50925523120' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '50925523120','Military Superannuation and Benefits Fund No. 1', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '51068260563' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '51068260563','Perpetuals Select Superannuation Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '51079960419' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '51079960419','Armytage Private Proprietary Limited ', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '51093828418' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '51093828418','Milliman Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '51097263628' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '51097263628','SG Hiscock & Company Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '51737334954' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '51737334954','Retirement Benefits Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '52137160528' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '52137160528','Market Vectors Australia Pty Ltd ', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '53006695021' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '53006695021','IOOF Investment Management Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '53095022718' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '53095022718','AllianceBernstein Australia Limited ', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '53136679420' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '53136679420','Ironbark Asset Management Pty Ltd ', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '53226460365' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '53226460365','First State Superannuation Scheme', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '53398474034' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '53398474034','BT Super for Life', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '53789980697' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '53789980697','OnePath MasterFund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '54007016195' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '54007016195','Industry Fund Services Limited (IFS)', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '54071808501' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '54071808501','Morningstar Investment Management', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '54084280508' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '54084280508','PIMCO Australia Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '54145196298' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '54145196298','Statewide Superannuation Trust', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '55118336584' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '55118336584','Deutsche Managed Investments Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '55159088516' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '55159088516','William Blair & Company LLC', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '55697537183' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '55697537183','Goldman Sachs JBWere Superannuation Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '56073623784' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '56073623784','Charter Hall Direct Property Management Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '56080277998' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '56080277998','Contango Asset Management Ltd ', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '56102482815' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '56102482815','BNY Mellon Asset Management Australia ', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '56286625181' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '56286625181','First Super', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '56601925435' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '56601925435','Commonwealth Essential Super', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '57526653420' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '57526653420','The Bendigo Superannuation Plan', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '57923283236' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '57923283236','Electricity Industry Superannuation Scheme', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '58152028094' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '58152028094','Forum Australia Pty Ltd ', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '58244115920' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '58244115920','IAG & NRMA Superannuation Plan', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '59001777591' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '59001777591','AMP Capital Investors Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '59002123364' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '59002123364','Aberdeen Asset Management Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '59087901620' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '59087901620','Perennial Investment Partners Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '60000000779' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '60000000779','OnePath Australia Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '60071497115' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '60071497115','Australian Unity Funds Management Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '60080674479' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '60080674479','APN Funds Management Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '60346078879' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '60346078879','legalsuper', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '60562335823' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '60562335823','Prime Super', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '60905115063' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '60905115063','State Public Sector Superannuation Scheme (QSuper)', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '60910190523' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '60910190523','HUB24 Super Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '60998717367' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '60998717367','The Executive Superannuation Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '61808189263' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '61808189263','The Retirement Portfolio Service', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '62126975282' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '62126975282','Concise Asset Management Limited ', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '62653671394' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '62653671394','Retail Employees Superannuation Trust', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '63114782777' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '63114782777','Cromwell Funds Management Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '64003114832' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '64003114832','Citigroup Global Markets Australia Pty Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '64080430100' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '64080430100','Tribeca Investment Partners Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '64090148619' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '64090148619','Paradice Investment Management Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '64168772387' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '64168772387','"Ranger International Management', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '64971749321' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '64971749321','HESTA Super Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '65127917725' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '65127917725','Public Sector Superannuation Accumulation Plan', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '65508799106' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '65508799106','Macquarie Superannuation', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '65704511371' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '65704511371','Intrust Super Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '65714394898' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '65714394898','AustralianSuper', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '66002867003' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '66002867003','Macquarie Investment Management Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '66008612397' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '66008612397','Mercer Global Investments (Australia)', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '66102271812' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '66102271812','Eley Griffiths Group Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '66109659109' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '66109659109','Pinnacle Investment Management Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '66628776348' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '66628776348','Christian Super', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '67145459936' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '67145459936','Sequoia Specialist Investments Pty Ltd ', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '68152846261' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '68152846261','ETF Securities (Australia) Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '68569795856' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '68569795856','Incitec Pivot Employees Superannuation Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '68657495890' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '68657495890','HOSTPLUS Superannuation Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '68964712340' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '68964712340','Aon Master Trust', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '69063081612' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '69063081612','Hunter Hall Investment Management Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '69083644731' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '69083644731','P.M. Capital Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '70135907550' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '70135907550','Sequoia Asset Management Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '70732426024' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '70732426024','MLC Super Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '70815369818' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '70815369818','IOOF Portfolio Service Superannuation Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '71603157863' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '71603157863','MAP Superannuation Plan', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '72000700247' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '72000700247','BT Financial Group Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '72072881086' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '72072881086','Vanguard Investments Australia Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '72098420770' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '72098420770','Clime Asset Management Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '72099071637' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '72099071637','DNR Capital Pty Limited ', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '72128512621' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '72128512621','Solaris Investment Management Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '72229227691' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '72229227691','NESS Super', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '73001208564' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '73001208564','Maple-Brown Abbott Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '73125601096' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '73125601096','Integrity Investment Management', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '73139161701' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '73139161701','Montgomery Investment Management Pty Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '73310248809' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '73310248809','AMP Retirement Trust', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '73549180515' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '73549180515','NGS Super', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '74114108879' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '74114108879','NWQ Capital Management Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '74559365913' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '74559365913','MTAA Superannuation Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '75100537200' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '75100537200','Gateway Financial Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '75103478897' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '75103478897','Virgin Money Super', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '75493363262' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '75493363262','Construction and Building Industry Super (Cbus)', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '75703857864' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '75703857864','Praemium SMA Superannuation Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '76004835849' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '76004835849','Legg Mason Asset Management Australia Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '76514770399' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '76514770399','AMP Superannuation Savings Trust', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '76641658449' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '76641658449','REI Super', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '77087181600' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '77087181600','Peters Macgregor Capital Management Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '77120730136' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '77120730136','Plato Investment Management Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '77136871924' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '77136871924','Alexander Funds Management Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '77343563307' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '77343563307','TWUSUPER', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '77455663441' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '77455663441','Maritime Super', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '78008576449' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '78008576449','BNP Paribas Investment Partners (Australia) Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '78098628605' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '78098628605','Celeste Funds Management Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '78099959958' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '78099959958','Freehold Investment Management Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '78138351345' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '78138351345','Forager Funds', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '78139566868' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '78139566868','Betashares Capital Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '78421957449' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '78421957449','Super Directions Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '78984178687' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '78984178687','Kinetic Superannuation Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '79004717533' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '79004717533','Mercer Global Investments ', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '79008634704' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '79008634704','Hostplus Pty Ltd ', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '79087649054' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '79087649054','Centuria Life Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '80080135897' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '80080135897','Hyperion Asset Management Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '80928800255' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '80928800255','Alcoa of Australia Retirement Plan', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '81102843809' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '81102843809','MPG Funds Management Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '81154851339' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '81154851339','Oasis Superannuation Master Trust', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '81236903448' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '81236903448','Westpac Master Trust', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '82890650204' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '82890650204','Powerwrap Master Plan', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '83131134613' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '83131134613','Martin Currie Investment Management Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '83262385409' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '83262385409','PineBridge Investments LLC', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '83810127567' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '83810127567','ANZ Australian Staff Superannuation Scheme', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '83953436008' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '83953436008','BT Lifetime Super Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '84092278647' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '84092278647','Bell Asset Management Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '84104852191' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '84104852191','T Rowe Price International Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '84119339052' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '84119339052','RARE Infrastructure Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '84421446069' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '84421446069','AvSuper Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '85090569109' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '85090569109','netwealth Investments Limited  ', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '85125338785' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '85125338785','Evans and Partners Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '85502108833' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '85502108833','Telstra Superannuation Scheme', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '85571332201' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '85571332201','Building Unions Superannuation Scheme (Queensland) (BUSSQ)', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '85894637037' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '85894637037','Emergency Services Superannuation Scheme', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '85977964496' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '85977964496','VicSuper Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '86664654341' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '86664654341','StatePlus Retirement Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '87006972247' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '87006972247','Franklin Templeton Investments Australia Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '87153200278' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '87153200278','Aviva Investors Pacific Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '87165750078' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '87165750078','Placer Property Management Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '87883998803' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '87883998803','Challenger Retirement Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '88010720840' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '88010720840','Sunsuper Pty Ltd ', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '88148215570' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '88148215570','"Capital International', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '88436608094' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '88436608094','Virgin Superannuation', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '88556625125' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '88556625125','IRIS Superannuation Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '88854638840' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '88854638840','Colonial First State Rollover & Superannuation Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '89092626090' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '89092626090','Smallco Investment Manager Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '89384753567' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '89384753567','Russell Investments Master Trust', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '89615320262' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '89615320262','URB Investments Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '90146033801' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '90146033801','Neuberger Berman Australia Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '90153020029' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '90153020029','Cameron Harrison Investment Management Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '90168653521' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '90168653521','Mirabella Financial Services LLP', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '90194410365' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '90194410365','Asgard Superannuation Account', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '90302247344' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '90302247344','Australian Defence Force Superannuation Scheme', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '91006670060' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '91006670060','CareSuper Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '91092873160' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '91092873160','Orion Asset Management Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '91141447207' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '91141447207','Mason Stevens Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '91385943850' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '91385943850','UniSuper Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '92003066859' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '92003066859','Russell Investment Group Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '92181844838' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '92181844838','Mercer Portfolio Service Superannuation Plan', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '92381911598' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '92381911598','Wealth Personal Superannuation and Pension Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '92398191503' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '92398191503','AustSafe Super', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '92615545536' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '92615545536','Fat Prophets Funds Management Pty Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '92861884632' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '92861884632','The Portfolio Service Retirement Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '93371348387' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '93371348387','Lutheran Super', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '94101103011' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '94101103011','Select Asset Management Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '94106888662' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '94106888662','AZ Sestante Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '94573747704' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '94573747704','netwealth Superannuation Master Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '95068282166' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '95068282166','Advance Retirement Suite Accounts Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '95085445094' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '95085445094','K2 Asset Management Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '95275115088' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '95275115088','Club Plus Superannuation Scheme', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '96010528597' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '96010528597','AustSafe Pty Ltd ', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '98002348352' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '98002348352','Colonial First State Investments Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '98002538329' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '98002538329','Advance Asset Management Limited ', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '98106302505' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '98106302505','Watermark Funds Management Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '98113856214' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '98113856214','Premium China Fund Management Pty Ltd ', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '98172275725' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '98172275725','CARE Super', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '98350952022' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '98350952022','Suncorp Master Trust', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '98438661856' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '98438661856','Rio Tinto Staff Superannuation Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '98503137921' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '98503137921','Sunsuper Superannuation Fund', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '99003376252' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '99003376252','Tyndall Investment Management Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '31085290928 ' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '31085290928 ','Mirrabooka Investments Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '38006862693 ' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '38006862693 ','Djerriwarrh Investments Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '54614316595 ' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '54614316595 ','Contact Asset Management Pty Ltd', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '55143832080 ' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '55143832080 ','JPMorgan Asset Management (Australia) Limited', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN = '57073990735 ' ) 
 BEGIN 
   insert into company (id, abn,  Company_Name, insert_date, last_modified) 
   values (NEWID(), '57073990735 ','AMCIL Limited', getdate(), getdate()) 
 END; 
 

