---------------------------------------------------------------------------------------
--INSERT INTO PUBLIC.COMPANY internal company
---------------------------------------------------------------------------------------

IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN ='94151658534' )
BEGIN
    INSERT INTO COMPANY(ID, INSERT_DATE, LAST_MODIFIED, ABN, ADDRESS, COMPANY_NAME, PARENT_ID) 
    VALUES (NEWID(), getdate(),  getdate(), '94151658534', '7/90 Collins St, Melbourne VIC 3000', 'Lonsec', NULL )
END

IF NOT EXISTS ( SELECT 1 FROM COMPANY  WHERE ABN ='95100192283' )
BEGIN
    INSERT INTO COMPANY(ID, INSERT_DATE, LAST_MODIFIED, ABN, ADDRESS, COMPANY_NAME, PARENT_ID) 
    VALUES (NEWID(), getdate(),  getdate(), '95100192283', 'Level 21, 200 George Street, Sydney NSW 2000', 'SuperRatings', NULL )
END


---------------------------------------------------------------------------------------
-- INSERT INTO PUBLIC.SEGMENT internal company 
---------------------------------------------------------------------------------------

IF NOT EXISTS ( SELECT 1 FROM SEGMENT  WHERE SEGMENT_CD ='LR' AND EXT_UNIQUE_KEY = 'FM-50001' )
BEGIN
    INSERT INTO SEGMENT(ID, INSERT_DATE, LAST_MODIFIED, ABN, ANALYST, COMPANY_ID, COMPANY_NAME, EXT_UNIQUE_KEY, SEGMENT_CD) 
    VALUES (NEWID(), getdate(),  getdate(), '94151658534', NULL, 'FM-50001', 'Lonsec Research', 'FM-50001', 'LR' )
END

IF NOT EXISTS ( SELECT 1 FROM SEGMENT  WHERE SEGMENT_CD ='SR' AND EXT_UNIQUE_KEY = '284' )
BEGIN
    INSERT INTO SEGMENT(ID, INSERT_DATE, LAST_MODIFIED, ABN, ANALYST, COMPANY_ID, COMPANY_NAME, EXT_UNIQUE_KEY, SEGMENT_CD)
    VALUES (NEWID(), getdate(),  getdate(), '95100192283', NULL, '284', 'SuperRatings', '284', 'SR' )
END



