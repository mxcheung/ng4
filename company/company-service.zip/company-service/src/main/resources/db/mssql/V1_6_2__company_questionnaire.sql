---------------------------------------------------------------------------------------
-- Add company questionnaire
---------------------------------------------------------------------------------------
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '437' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 437,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '437' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 437,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '437' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 437,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '10045' and property_key= 'KIWISAVER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 10045,'KIWISAVER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '289' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 289,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '289' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 289,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '289' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 289,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '286' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 286,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '286' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 286,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '10050' and property_key= 'KIWISAVER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 10050,'KIWISAVER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '10003' and property_key= 'KIWISAVER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 10003,'KIWISAVER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '10024' and property_key= 'KIWISAVER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 10024,'KIWISAVER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '353' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 353,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '353' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 353,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '353' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 353,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '297' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 297,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '297' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 297,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '297' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 297,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '10022' and property_key= 'KIWISAVER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 10022,'KIWISAVER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '10082' and property_key= 'KIWISAVER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 10082,'KIWISAVER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '332' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 332,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '332' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 332,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '229' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 229,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '229' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 229,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '229' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 229,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '5555' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 5555,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '5555' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 5555,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '5555' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 5555,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '270' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 270,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '270' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 270,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '270' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 270,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '308' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 308,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '308' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 308,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '308' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 308,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '301' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 301,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '301' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 301,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '301' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 301,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '374' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 374,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '374' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 374,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '246' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 246,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '246' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 246,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '246' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 246,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '350' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 350,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '350' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 350,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '350' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 350,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '231' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 231,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '231' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 231,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '231' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 231,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '0' and property_key= 'KIWISAVER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 0,'KIWISAVER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '437' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 437,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '289' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 289,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '286' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 286,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '353' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 353,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '297' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 297,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '229' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 229,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '5555' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 5555,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '270' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 270,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '308' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 308,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '301' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 301,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '374' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 374,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '246' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 246,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '10035' and property_key= 'KIWISAVER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 10035,'KIWISAVER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '350' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 350,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '10054' and property_key= 'KIWISAVER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 10054,'KIWISAVER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '888888' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 888888,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '288' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 288,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '288' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 288,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '231' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 231,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '288' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 288,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '226' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 226,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '226' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 226,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '226' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 226,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '226' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 226,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '288' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 288,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '328' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 328,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '336' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 336,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '336' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 336,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '336' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 336,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '336' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 336,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '236' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 236,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '236' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 236,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '236' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 236,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '236' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 236,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '239' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 239,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '239' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 239,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '239' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 239,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '239' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 239,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '429' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 429,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '429' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 429,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '429' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 429,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '429' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 429,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '358' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 358,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '358' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 358,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '251' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 251,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '251' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 251,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '251' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 251,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '251' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 251,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '310' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 310,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '310' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 310,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '310' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 310,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '310' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 310,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '306' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 306,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '306' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 306,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '306' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 306,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '306' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 306,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '385' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 385,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '385' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 385,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '0' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 0,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '0' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 0,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '0' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 0,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '0' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 0,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '238' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 238,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '238' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 238,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '238' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 238,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '238' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 238,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '253' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 253,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '253' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 253,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '253' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 253,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '253' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 253,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '638000' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 638000,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '303' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 303,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '295' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 295,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '343' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 343,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '343' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 343,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '343' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 343,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '343' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 343,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '368' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 368,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '368' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 368,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '368' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 368,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '368' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 368,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '411' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 411,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '0' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 0,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '0' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 0,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '349' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 349,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '349' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 349,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '349' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 349,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '461' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 461,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '461' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 461,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '461' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 461,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '397' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 397,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '397' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 397,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '397' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 397,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '397' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 397,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '220' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 220,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '220' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 220,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '220' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 220,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '220' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 220,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '371' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 371,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '371' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 371,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '371' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 371,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '371' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 371,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '224' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 224,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '224' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 224,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '224' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 224,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '224' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 224,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '533' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 533,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '298' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 298,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '298' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 298,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '298' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 298,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '461' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 461,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '298' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 298,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '367' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 367,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '367' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 367,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '367' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 367,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '367' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 367,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '392' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 392,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '245' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 245,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '245' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 245,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '245' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 245,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '245' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 245,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '391' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 391,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '389' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 389,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '389' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 389,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '389' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 389,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '389' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 389,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '375' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 375,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '375' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 375,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '375' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 375,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '375' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 375,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '10002' and property_key= 'KIWISAVER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 10002,'KIWISAVER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '10077' and property_key= 'KIWISAVER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 10077,'KIWISAVER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '265' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 265,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '265' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 265,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '342' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 342,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '342' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 342,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '342' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 342,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '342' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 342,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '265' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 265,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '258' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 258,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '258' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 258,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '0' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 0,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '0' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 0,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '282' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 282,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '282' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 282,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '282' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 282,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '282' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 282,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '390' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 390,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '341' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 341,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '369' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 369,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '369' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 369,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '369' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 369,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '369' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 369,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '340' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 340,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '340' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 340,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '340' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 340,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '340' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 340,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '361' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 361,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '361' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 361,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '361' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 361,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '361' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 361,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '355' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 355,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '355' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 355,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '355' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 355,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '355' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 355,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '254' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 254,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '254' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 254,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '254' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 254,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '254' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 254,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '410' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 410,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '410' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 410,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '410' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 410,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '410' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 410,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '363' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 363,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '363' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 363,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '363' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 363,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '363' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 363,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '234' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 234,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '237' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 237,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '237' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 237,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '237' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 237,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '237' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 237,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '376' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 376,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '376' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 376,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '376' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 376,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '376' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 376,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '319' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 319,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '319' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 319,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '319' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 319,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '319' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 319,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '242' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 242,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '242' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 242,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '242' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 242,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '242' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 242,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '252' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 252,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '252' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 252,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '252' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 252,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '252' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 252,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '430' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 430,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '430' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 430,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '430' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 430,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '430' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 430,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '568' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 568,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '568' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 568,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '568' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 568,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '568' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 568,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '25000' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 25000,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '25000' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 25000,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '25000' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 25000,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '25000' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 25000,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '264' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 264,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '264' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 264,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '264' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 264,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '264' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 264,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '250' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 250,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '250' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 250,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '250' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 250,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '250' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 250,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '2500' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 2500,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '2500' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 2500,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '2500' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 2500,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '1182' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 1182,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '1182' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 1182,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '249' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 249,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '249' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 249,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '249' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 249,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '249' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 249,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '311' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 311,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '311' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 311,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '311' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 311,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '311' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 311,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '394' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 394,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '394' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 394,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '394' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 394,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '394' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 394,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '356' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 356,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '356' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 356,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '356' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 356,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '356' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 356,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '267' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 267,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '267' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 267,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '267' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 267,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '267' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 267,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '414' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 414,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '414' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 414,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '414' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 414,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '414' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 414,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '325' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 325,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '325' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 325,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '325' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 325,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '269' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 269,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '269' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 269,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '269' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 269,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '269' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 269,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '313' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 313,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '313' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 313,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '313' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 313,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '313' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 313,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '229' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 229,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '229' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 229,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '229' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 229,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '229' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 229,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '254' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 254,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '254' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 254,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '254' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 254,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '254' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 254,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '357' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 357,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '357' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 357,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '357' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 357,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '357' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 357,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '317' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 317,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '317' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 317,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '317' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 317,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '317' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 317,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '316' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 316,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '316' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 316,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '316' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 316,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '316' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 316,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '329' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 329,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '329' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 329,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '329' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 329,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '329' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 329,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '500' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 500,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '500' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 500,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '500' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 500,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '500' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 500,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '366' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 366,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '366' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 366,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '366' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 366,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '366' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 366,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '279' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 279,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '279' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 279,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '279' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 279,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '279' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 279,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '326' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 326,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '326' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 326,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '326' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 326,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '326' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 326,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '333' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 333,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '365' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 365,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '365' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 365,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '365' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 365,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '365' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 365,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '10074' and property_key= 'KIWISAVER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 10074,'KIWISAVER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '10067' and property_key= 'KIWISAVER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 10067,'KIWISAVER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '321' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 321,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '321' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 321,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '321' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 321,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '321' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 321,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '888' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 888,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '230' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 230,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '263' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 263,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '263' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 263,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '263' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 263,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '263' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 263,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '340' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 340,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '340' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 340,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '340' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 340,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '340' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 340,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '340' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 340,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '340' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 340,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '340' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 340,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '340' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 340,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '340' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 340,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '340' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 340,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '340' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 340,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '340' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 340,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '302' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 302,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '302' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 302,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '302' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 302,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '302' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 302,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '372' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 372,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '402' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 402,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '402' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 402,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '402' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 402,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '402' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 402,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '352' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 352,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '352' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 352,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '352' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 352,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '352' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 352,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '412' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 412,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '412' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 412,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '412' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 412,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '412' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 412,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '423' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 423,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '423' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 423,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '423' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 423,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '423' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 423,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '422' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 422,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '422' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 422,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '422' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 422,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '422' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 422,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '283' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 283,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '283' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 283,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '283' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 283,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '283' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 283,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '532' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 532,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '532' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 532,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '532' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 532,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '364' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 364,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '364' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 364,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '364' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 364,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '364' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 364,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '225' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 225,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '347' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 347,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '347' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 347,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '347' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 347,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '347' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 347,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '348' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 348,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '348' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 348,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '348' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 348,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '348' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 348,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '259' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 259,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '259' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 259,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '259' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 259,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '259' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 259,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '413' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 413,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '260' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 260,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '260' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 260,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '260' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 260,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '260' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 260,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '312' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 312,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '255' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 255,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '255' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 255,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '320' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 320,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '320' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 320,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '320' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 320,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '320' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 320,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '345' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 345,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '345' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 345,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '345' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 345,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '345' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 345,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '314' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 314,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '314' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 314,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '314' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 314,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '314' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 314,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '344' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 344,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '344' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 344,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '344' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 344,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '344' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 344,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '262' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 262,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '271' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 271,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '271' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 271,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '271' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 271,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '271' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 271,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '10025' and property_key= 'KIWISAVER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 10025,'KIWISAVER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '10038' and property_key= 'KIWISAVER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 10038,'KIWISAVER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '10069' and property_key= 'KIWISAVER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 10069,'KIWISAVER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '10072' and property_key= 'KIWISAVER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 10072,'KIWISAVER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '272' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 272,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '334' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 334,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '334' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 334,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '334' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 334,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '334' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 334,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '276' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 276,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '276' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 276,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '276' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 276,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '276' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 276,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '304' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 304,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '304' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 304,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '304' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 304,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '384' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 384,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '10029' and property_key= 'KIWISAVER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 10029,'KIWISAVER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '344' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 344,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '344' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 344,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '344' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 344,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '344' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 344,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '285' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 285,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '407' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 407,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '254' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 254,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '254' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 254,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '254' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 254,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '222' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 222,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '222' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 222,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '222' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 222,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '222' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 222,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '421' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 421,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '433' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 433,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '433' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 433,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '431' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 431,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '431' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 431,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '431' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 431,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '10023' and property_key= 'KIWISAVER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 10023,'KIWISAVER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '638' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 638,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '638' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 638,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '274' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 274,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '274' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 274,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '274' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 274,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '10051' and property_key= 'KIWISAVER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 10051,'KIWISAVER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '10081' and property_key= 'KIWISAVER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 10081,'KIWISAVER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '10076' and property_key= 'KIWISAVER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 10076,'KIWISAVER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '10005' and property_key= 'KIWISAVER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 10005,'KIWISAVER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '10001' and property_key= 'KIWISAVER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 10001,'KIWISAVER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '10030' and property_key= 'KIWISAVER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 10030,'KIWISAVER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '10021' and property_key= 'KIWISAVER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 10021,'KIWISAVER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '10006' and property_key= 'KIWISAVER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 10006,'KIWISAVER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '10075' and property_key= 'KIWISAVER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 10075,'KIWISAVER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '10026' and property_key= 'KIWISAVER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 10026,'KIWISAVER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '638' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 638,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '638' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 638,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '644' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 644,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '644' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 644,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '644' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 644,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '235' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 235,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '235' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 235,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '235' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 235,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '235' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 235,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '639' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 639,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '10028' and property_key= 'KIWISAVER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 10028,'KIWISAVER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '637' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 637,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '637' and property_key= 'INFINITY' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 637,'INFINITY', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '637' and property_key= 'ANNUAL' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 637,'ANNUAL', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '332' and property_key= 'MONTH' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 332,'MONTH', 'true', getdate(), getdate()) 
 END; 
 
IF NOT EXISTS ( SELECT 1 FROM entityproperty  WHERE entity_id = '332' and property_key= 'QUARTER' ) 
 BEGIN 
   insert into entityproperty (id, property_type,  entity_id,  property_key, property_value, insert_date, last_modified) 
   values (NEWID(), '1', 332,'QUARTER', 'true', getdate(), getdate()) 
 END; 
 

