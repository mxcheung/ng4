IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1927' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1927','Acuity SuperWrap - Pension Plan', 'Pension', '361','361','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1925' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1925','Acuity SuperWrap - Personal Super Plan', 'Accumulation', '361','361','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '596' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '596','Acumen Super', 'Accumulation', '222','222','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1117' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1117','Advance Retirement Suite - Allocated Pension', 'Pension', '411','411','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1103' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1103','Advance Retirement Suite - Super Account', 'Accumulation', '411','411','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1146' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1146','Alcoa - Accumulation Plan', 'Accumulation', '417','417','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1147' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1147','Alcoa - Pensions', 'Pension', '417','417','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '998' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '998','AMG Super - Account Based Pension', 'Pension', '368','368','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '996' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '996','AMG Super - Corporate Super', 'Accumulation', '368','368','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1541' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1541','AMG Super - MySuper', 'MySuper', '368','368','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '997' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '997','AMG Super - Personal', 'Accumulation', '368','368','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1451' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1451','AMIST MySuper', 'MySuper', '231','231','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '940' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '940','AMIST Pension', 'Pension', '231','231','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '598' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '598','AMIST Super', 'Accumulation', '231','231','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1001' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1001','AMIST Super Personal Division', 'Accumulation', '231','231','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '599' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '599','AMP CustomSuper', 'Accumulation', '297','297','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1658' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1658','AMP CustomSuper - MySuper', 'MySuper', '297','297','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '808' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '808','AMP Flexible Lifetime - Allocated Pension', 'Pension', '297','297','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1659' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1659','AMP Flexible Lifetime - MySuper', 'MySuper', '297','297','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '683' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '683','AMP Flexible Lifetime - Super', 'Accumulation', '297','297','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1157' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1157','AMP Flexible Super (Choice Package)', 'Accumulation', '532','532','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1155' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1155','AMP Flexible Super (Core Package)', 'Accumulation', '532','532','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1156' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1156','AMP Flexible Super (Select Package)', 'Accumulation', '532','532','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1160' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1160','AMP Flexible Super Retirement (Choice Package)', 'Pension', '532','532','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1158' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1158','AMP Flexible Super Retirement (Core Package)', 'Pension', '532','532','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1159' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1159','AMP Flexible Super Retirement (Select Package)', 'Pension', '532','532','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1513' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1513','AMP MySuper Balanced', 'MySuper', '532','532','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1077' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1077','AMP Retirement Savings Account', 'Accumulation', '297','297','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1514' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1514','AMP SDF MySuper', 'MySuper', '437','437','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '684' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '684','AMP SignatureSuper', 'Accumulation', '297','297','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1512' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1512','AMP SignatureSuper - MySuper', 'MySuper', '297','297','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '985' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '985','AMP SignatureSuper Allocated Pension', 'Pension', '297','297','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '928' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '928','AMP SignatureSuper Personal Superannuation', 'Accumulation', '297','297','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1571' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1571','AMP SignatureSuper Select', 'Accumulation', '297','297','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1572' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1572','AMP SignatureSuper Select Personal Superannuation', 'Accumulation', '297','297','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1947' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1947','AMP SignatureSuper Water Corporation Super', 'Accumulation', '297','297','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1948' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1948','AMP SignatureSuper Water Corporation Super - MySuper', 'MySuper', '297','297','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1949' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1949','AMP SignatureSuper Water Corporation Super AP', 'Pension', '297','297','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '600' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '600','AMP SuperLeader', 'Accumulation', '297','297','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1660' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1660','AMP SuperLeader - MySuper', 'MySuper', '297','297','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '810' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '810','ANZ OneAnswer Pension', 'Pension', '254','254','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '809' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '809','ANZ OneAnswer Personal Super', 'Accumulation', '254','254','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1744' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1744','ANZ Smart Choice - Emp', 'Accumulation', '254','254','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1247' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1247','ANZ Smart Choice - Pers', 'Accumulation', '254','254','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1249' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1249','ANZ Smart Choice Pension', 'Pension', '254','254','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1554' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1554','ANZ Smart Choice Super - MySuper', 'MySuper', '254','254','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1097' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1097','ANZ Staff Super - Account Based Pension', 'Pension', '402','402','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1525' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1525','ANZ Staff Super - MySuper', 'MySuper', '402','402','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1096' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1096','ANZ Staff Super - Section A', 'Accumulation', '402','402','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '597' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '597','ANZ Super Advantage', 'Accumulation', '254','254','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '767' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '767','ARC Allocated Pension', 'Pension', '328','328','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '721' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '721','ARC Corporate Superannuation', 'Accumulation', '328','328','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '766' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '766','ARC Personal Superannuation', 'Accumulation', '328','328','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '758' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '758','Asgard Allocated Pension Account - SMAF', 'Pension', '340','340','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '756' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '756','Asgard Elements Allocated Pension Account', 'Pension', '340','340','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '755' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '755','Asgard Elements Superannuation Account', 'Accumulation', '340','340','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '602' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '602','Asgard Employee Superannuation Account', 'Accumulation', '340','340','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1537' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1537','Asgard Employee Superannuation Account - MySuper', 'MySuper', '340','340','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '932' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '932','Asgard eWRAP Allocated Pension Account', 'Pension', '340','340','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '931' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '931','Asgard eWRAP Super Account', 'Accumulation', '340','340','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1237' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1237','Asgard Infinity eWRAP Allocated Pension Account (Core Package)', 'Pension', '340','340','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1239' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1239','Asgard Infinity eWRAP Allocated Pension Account (Full Package)', 'Pension', '340','340','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1238' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1238','Asgard Infinity eWRAP Allocated Pension Account (Select Package)', 'Pension', '340','340','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1234' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1234','Asgard Infinity eWRAP Super Account (Core Package)', 'Accumulation', '340','340','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1236' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1236','Asgard Infinity eWRAP Super Account (Full Package)', 'Accumulation', '340','340','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1235' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1235','Asgard Infinity eWRAP Super Account (Select Package)', 'Accumulation', '340','340','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '757' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '757','Asgard Superannuation Account - SMAF', 'Accumulation', '340','340','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1987' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1987','Aspen Pharma Superannuation Plan', 'Accumulation', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1988' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1988','Aspen Pharma Superannuation Plan - MySuper', 'MySuper', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1993' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1993','Asset Administrator - Pension', 'Pension', '644','644','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1989' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1989','Asset Administrator - Super', 'Accumulation', '644','644','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1101' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1101','AustChoice Super - Account Based Pension', 'Pension', '250','250','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1111' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1111','AustChoice Super - Employer Sponsored', 'Accumulation', '250','250','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1068' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1068','AustChoice Super - Personal', 'Accumulation', '250','250','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1142' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1142','Australia Post Superannuation Scheme - Allocated Pension', 'Pension', '421','421','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '690' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '690','Australian Catholic Superannuation - Employer Sponsored Plan', 'Accumulation', '363','363','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1449' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1449','Australian Catholic Superannuation - MySuper', 'MySuper', '363','363','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '935' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '935','Australian Catholic Superannuation - Personal Plan', 'Accumulation', '363','363','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '782' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '782','Australian Catholic Superannuation - RetireChoice', 'Pension', '363','363','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1820' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1820','Australian Catholic Superannuation - RetireSmart', 'Pension', '363','363','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1905' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1905','Australian Defence Force Superannuation', 'Accumulation', '635','635','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1906' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1906','Australian Defence Force Superannuation - MySuper', 'MySuper', '635','635','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '795' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '795','Australian Ethical Retail Superannuation Fund - Account Based Pension', 'Pension', '352','352','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1337' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1337','Australian Ethical Retail Superannuation Fund - Employer', 'Accumulation', '352','352','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1522' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1522','Australian Ethical Retail Superannuation Fund - MySuper', 'MySuper', '352','352','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '791' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '791','Australian Ethical Retail Superannuation Fund - Personal', 'Accumulation', '352','352','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1946' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1946','Australian Expatriate Superannuation Account Based Pension', 'Pension', '639','639','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1945' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1945','Australian Expatriate Superannuation Fund', 'Accumulation', '639','639','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '744' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '744','AustralianSuper', 'Accumulation', '349','349','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1452' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1452','AustralianSuper - MySuper', 'MySuper', '349','349','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1964' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1964','AustralianSuper - Select', 'Accumulation', '349','349','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '964' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '964','AustralianSuper Choice Income Account', 'Pension', '349','349','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '991' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '991','AustralianSuper Corporate Divison', 'Accumulation', '349','349','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '913' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '913','AustralianSuper Personal Plan', 'Accumulation', '349','349','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1697' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1697','AustralianSuper Public Sector Division', 'Accumulation', '349','349','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '726' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '726','AustSafe Super', 'Accumulation', '332','332','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1508' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1508','AustSafe Super - MySuper', 'MySuper', '332','332','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '815' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '815','AustSafe Super Account Based Pension', 'Pension', '332','332','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '990' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '990','AustSafe Super Personal', 'Accumulation', '332','332','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '607' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '607','AvSuper - Accumulation', 'Accumulation', '225','225','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1504' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1504','AvSuper - MySuper', 'MySuper', '225','225','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '946' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '946','AvSuper - Public Offer Account', 'Accumulation', '225','225','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '816' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '816','AvSuper Retirement Income Stream', 'Pension', '225','225','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1705' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1705','Bendigo SmartOptions Pension', 'Pension', '385','385','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1703' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1703','Bendigo SmartOptions Super', 'Accumulation', '385','385','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1482' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1482','Bendigo SmartStart Pension', 'Pension', '385','385','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1543' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1543','Bendigo SmartStart Super - Bendigo MySuper', 'MySuper', '385','385','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1544' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1544','Bendigo SmartStart Super - Employer-sponsored Division', 'Accumulation', '385','385','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1025' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1025','Bendigo SmartStart Super - Personal Division', 'Accumulation', '385','385','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1323' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1323','Best Super Portfolio - Balanced', 'Accumulation', '340','340','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1335' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1335','Best Super Portfolio - Balanced Growth', 'Accumulation', '340','340','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1332' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1332','Best Super Portfolio - Conservative', 'Accumulation', '340','340','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1334' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1334','Best Super Portfolio - Growth', 'Accumulation', '340','340','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1333' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1333','Best Super Portfolio - Moderate', 'Accumulation', '340','340','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1547' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1547','BHP Billiton Super Fund - MySuper', 'MySuper', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1694' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1694','BHP Billiton Super Fund - Pension Division', 'Pension', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1907' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1907','BHP Billiton Super Plan', 'Accumulation', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1908' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1908','BHP Billiton Super Plan - MySuper', 'MySuper', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1104' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1104','BHP Billiton Superannuation Fund', 'Accumulation', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1118' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1118','BOC Super', 'Accumulation', '412','412','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1486' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1486','BOC Super - MySuper', 'MySuper', '412','412','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1119' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1119','BOC Super - Retirement Pension', 'Pension', '412','412','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1710' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1710','brightday Complete Pension', 'Pension', '314','314','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1709' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1709','brightday Complete Super', 'Accumulation', '314','314','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '689' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '689','BT Business Super', 'Accumulation', '397','397','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1519' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1519','BT Business Super - MySuper', 'MySuper', '397','397','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '748' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '748','BT Lifetime - Flexible Pension', 'Pension', '220','220','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '746' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '746','BT Lifetime - Personal Super', 'Accumulation', '220','220','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1516' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1516','BT Lifetime Super - Employer MySuper', 'MySuper', '220','220','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '609' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '609','BT Lifetime Super - Employer Plan', 'Accumulation', '220','220','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1980' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1980','BT Panorama - Pension', 'Pension', '644','644','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1978' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1978','BT Panorama - Super', 'Accumulation', '644','644','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1517' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1517','BT Super for Life - MySuper', 'MySuper', '371','371','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '984' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '984','BT Super for Life - Retirement Account', 'Pension', '371','371','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '983' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '983','BT Super for Life - Savings', 'Accumulation', '371','371','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '926' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '926','BT SuperWrap - Allocated Pension Plan', 'Pension', '361','361','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '925' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '925','BT SuperWrap - Personal Super Plan', 'Accumulation', '361','361','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '936' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '936','BUSSQ - Premium Choice', 'Accumulation', '224','224','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '610' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '610','BUSSQ MySuper', 'MySuper', '224','224','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '818' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '818','BUSSQ Pension Choice', 'Pension', '224','224','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '611' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '611','CareSuper', 'Accumulation', '347','347','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '735' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '735','CareSuper Corporate', 'Accumulation', '347','347','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1457' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1457','CareSuper MySuper', 'MySuper', '347','347','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '955' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '955','CareSuper Pension', 'Pension', '347','347','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '819' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '819','CareSuper Personal Plan', 'Accumulation', '347','347','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '614' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '614','Catholic Super', 'Accumulation', '237','237','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1476' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1476','Catholic Super - Default Strategy', 'MySuper', '237','237','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '820' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '820','Catholic Super - Personal Plan', 'Accumulation', '237','237','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1471' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1471','Cbus - Growth (MySuper)', 'MySuper', '245','245','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '613' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '613','Cbus Industry Super', 'Accumulation', '245','245','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '827' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '827','Cbus Personal Super', 'Accumulation', '245','245','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1143' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1143','Cbus Sole Trader', 'Accumulation', '245','245','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1056' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1056','Cbus Super Income Stream', 'Pension', '245','245','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '615' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '615','Challenger Corporate Superannuation Plan', 'Accumulation', '244','244','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1003' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1003','Challenger Guaranteed Allocated Pension', 'Pension', '244','244','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1002' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1002','Challenger Guaranteed Personal Super', 'Accumulation', '244','244','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '995' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '995','Child Care Super - MyMix', 'Accumulation', '375','375','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1502' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1502','Child Care Super - MySuper', 'MySuper', '375','375','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '691' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '691','Christian Super', 'Accumulation', '298','298','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1521' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1521','Christian Super - MyEthicalSuper', 'MySuper', '298','298','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '822' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '822','Christian Super Pension', 'Pension', '298','298','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1011' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1011','Clearview Pension Plan', 'Pension', '367','367','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1010' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1010','ClearView Superannuation and Roll-overs', 'Accumulation', '367','367','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1702' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1702','ClearView WealthFoundations - Pension', 'Pension', '367','367','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1701' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1701','ClearView WealthFoundations - Super', 'Accumulation', '367','367','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '823' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '823','Club Plus Pension', 'Pension', '302','302','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1187' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1187','Club Plus Personal', 'Accumulation', '302','302','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1450' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1450','Club Plus Super - MySuper', 'MySuper', '302','302','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '692' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '692','Club Plus Superannuation', 'Accumulation', '302','302','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '612' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '612','Club Super', 'Accumulation', '236','236','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '824' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '824','Club Super - Income Stream', 'Pension', '236','236','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1493' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1493','Club Super - MySuper', 'MySuper', '236','236','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '618' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '618','Colonial First State - FirstChoice Employer Super', 'Accumulation', '235','235','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '752' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '752','Colonial First State - FirstChoice Pension', 'Pension', '235','235','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '751' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '751','Colonial First State - FirstChoice Personal Super', 'Accumulation', '235','235','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1533' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1533','Colonial First State - FirstChoice Super MySuper', 'MySuper', '235','235','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '754' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '754','Colonial First State - FirstChoice Wholesale Pension', 'Pension', '235','235','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '753' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '753','Colonial First State - FirstChoice Wholesale Personal Super', 'Accumulation', '235','235','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1005' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1005','Colonial Rollover & Superannuation Fund', 'Accumulation', '392','392','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '619' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '619','Combined Super', 'Accumulation', '239','239','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1518' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1518','Combined Super - MySuper', 'MySuper', '239','239','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '826' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '826','Combined Super - Pension', 'Pension', '239','239','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '825' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '825','Combined Super - Personal Benefit Account', 'Accumulation', '239','239','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '933' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '933','Commonwealth Bank Group Super - Accumulate Plus', 'Accumulation', '364','364','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1511' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1511','Commonwealth Bank Group Super - MySuper', 'MySuper', '364','364','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '987' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '987','Commonwealth Bank Group Super - Retirement Access', 'Pension', '364','364','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1491' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1491','Commonwealth Essential Super', 'Accumulation', '533','533','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1531' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1531','Commonwealth Essential Super - MySuper', 'MySuper', '533','533','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1338' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1338','Commonwealth Superannuation Corporation retirement income', 'Pension', '336','336','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1982' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1982','Compass YourChoice Pension', 'Pension', '314','314','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1983' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1983','Compass YourChoice Super', 'Accumulation', '314','314','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1014' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1014','Concept One', 'Accumulation', '376','376','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1561' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1561','Concept One - MySuper', 'MySuper', '376','376','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1226' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1226','Concept One Pension', 'Pension', '376','376','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '620' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '620','Connelly Temple Employer Super Plan', 'Accumulation', '355','355','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1042' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1042','Connelly Temple Super Savings', 'Accumulation', '355','355','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '731' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '731','CSC PSS accumulation plan', 'Accumulation', '336','336','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1462' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1462','CSC PSSap - MySuper', 'MySuper', '336','336','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1046' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1046','Dominion Employer Superannuation Plan', 'Accumulation', '407','407','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1006' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1006','Dominion Personal Superannuation Plan', 'Accumulation', '407','407','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1045' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1045','Dominion Superannuation Master Trust - Allocated Pension', 'Pension', '407','407','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1047' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1047','Dominion Superannuation Master Trust - Superannuation and Rollovers', 'Accumulation', '407','407','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1523' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1523','EISS MySuper', 'MySuper', '348','348','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '829' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '829','Electricity Industry Super Scheme - Pension Scheme (Division 3)', 'Pension', '303','303','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '697' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '697','Electricity Industry Super Scheme Accumulation (Division 5)', 'Accumulation', '303','303','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1054' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1054','Electricity Industry Superannuation Scheme - Retirement Income Stream', 'Pension', '303','303','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1080' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1080','EmPlus', 'Accumulation', '413','413','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1300' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1300','EmPlus Employer Division', 'Accumulation', '413','413','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1580' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1580','EmPlus MySuper', 'MySuper', '413','413','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '832' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '832','Energy Industries Superannuation Scheme Pension', 'Pension', '348','348','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '741' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '741','Energy Industries Superannuation Scheme Retirement', 'Accumulation', '348','348','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1483' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1483','Energy Industries Superannuation Scheme Super', 'Accumulation', '348','348','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '622' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '622','Energy Super - Accumulation', 'Accumulation', '238','238','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '830' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '830','Energy Super - Allocated Pension', 'Pension', '238','238','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '963' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '963','Energy Super - Income Stream', 'Pension', '238','238','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1496' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1496','Energy Super - MySuper', 'MySuper', '238','238','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '834' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '834','Equip - Account Based Pension', 'Pension', '242','242','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '623' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '623','Equip - MyFuture', 'Accumulation', '242','242','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '833' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '833','Equip - MyFuture Personal', 'Accumulation', '242','242','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1657' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1657','Equip - MyPension', 'Pension', '242','242','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1478' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1478','Equip - MySuper', 'MySuper', '242','242','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1955' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1955','Equip Rio Tinto Fund - Employee', 'Accumulation', '242','242','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1954' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1954','Equip Rio Tinto Fund - MySuper', 'MySuper', '242','242','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1957' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1957','Equip Rio Tinto Fund - Pensions', 'Pension', '242','242','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1956' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1956','Equip Rio Tinto Fund - Personal', 'Accumulation', '242','242','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '698' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '698','ESSSuper - Accumulation Plan for Emergency Services Participating Employers', 'Accumulation', '319','319','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1069' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1069','ESSSuper - Accumulation Plan for State Super and Personal Members', 'Accumulation', '319','319','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '967' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '967','ESSSuper - Beneficiary Account', 'Accumulation', '319','319','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '831' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '831','ESSSuper - Retirement Income Stream', 'Pension', '319','319','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1038' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1038','Fire and Emergency Services Superannuation Fund - Accumulation Account', 'Accumulation', '391','391','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1040' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1040','First State Super Ambulance Officers Super', 'Accumulation', '259','259','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '627' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '627','First State Super Employer Sponsored Division', 'Accumulation', '259','259','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1454' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1454','First State Super MySuper Life Cycle', 'MySuper', '259','259','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '792' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '792','First State Super Personal Division', 'Accumulation', '259','259','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '992' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '992','First State Super Police Blue Ribbon Super', 'Accumulation', '259','259','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '942' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '942','First State Super Retirement Income Stream', 'Pension', '259','259','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1051' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1051','First Super - Allocated Pension', 'Pension', '389','389','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1049' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1049','First Super - Industry', 'Accumulation', '389','389','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1506' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1506','First Super - MySuper', 'MySuper', '389','389','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1050' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1050','First Super - Personal', 'Accumulation', '389','389','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1377' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1377','FirstWrap Plus Pension', 'Pension', '498','498','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1374' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1374','FirstWrap Plus Super', 'Accumulation', '498','498','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '606' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '606','Freedom of Choice - Corporate Superannuation', 'Accumulation', '496','496','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '839' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '839','Freedom of Choice - Employer Superannuation Service', 'Accumulation', '496','496','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1578' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1578','Freedom of Choice - MySuper MyLife', 'MySuper', '496','496','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '838' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '838','Freedom of Choice - Personal Retirement Service', 'Pension', '496','496','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '837' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '837','Freedom of Choice - Personal Superannuation Service', 'Accumulation', '496','496','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1166' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1166','FSP Super Fund Pension Service', 'Pension', '427','427','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1165' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1165','FSP Super Fund Superannuation Service', 'Accumulation', '427','427','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1961' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1961','Future Super', 'Accumulation', '642','642','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1962' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1962','Future Super Pension Plan', 'Pension', '642','642','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1076' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1076','FuturePlus Wrap - Pension Manager', 'Pension', '312','312','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1075' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1075','FuturePlus Wrap - Super Manager', 'Accumulation', '312','312','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '927' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '927','Generations Personal Pension', 'Pension', '344','344','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '774' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '774','Generations Personal Super', 'Accumulation', '344','344','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '629' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '629','GESB-West State Super', 'Accumulation', '252','252','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '783' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '783','GESB Retirement Income Allocated Pension', 'Pension', '252','252','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '949' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '949','GESB Super', 'Accumulation', '252','252','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1916' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1916','Glencoresuper', 'Accumulation', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1917' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1917','Glencoresuper - MySuper', 'MySuper', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1936' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1936','Gold Fields Superannuation Plan', 'Accumulation', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1937' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1937','Gold Fields Superannuation Plan - MySuper', 'MySuper', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1540' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1540','Goldman Sachs & JBWere Superannuation Fund - MySuper', 'MySuper', '423','423','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1154' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1154','Goldman Sachs JBWere - Account Based Pension', 'Pension', '423','423','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1745' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1745','Good Super', 'Accumulation', '341','341','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1970' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1970','Grow Super - Employer', 'Accumulation', '308','308','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1969' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1969','Grow Super - MySuper', 'MySuper', '308','308','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1967' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1967','Grow Super - Personal', 'Accumulation', '308','308','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1924' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1924','Grow Wrap Pension', 'Pension', '357','357','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1922' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1922','Grow Wrap Super', 'Accumulation', '357','357','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1013' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1013','GuildPension', 'Pension', '375','375','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1012' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1012','GuildSuper - MyMix', 'Accumulation', '375','375','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1498' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1498','GuildSuper - MySuper', 'MySuper', '375','375','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '632' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '632','HESTA - Industry Super Plan', 'Accumulation', '260','260','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1463' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1463','HESTA - MySuper', 'MySuper', '260','260','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '842' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '842','HESTA - Personal Super Plan', 'Accumulation', '260','260','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1048' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1048','HESTA Income Stream', 'Pension', '260','260','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '734' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '734','HOSTPLUS Executive', 'Accumulation', '343','343','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1133' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1133','HOSTPLUS Pension Plan', 'Pension', '343','343','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '843' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '843','HOSTPLUS Personal Super Plan', 'Accumulation', '343','343','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '633' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '633','HOSTPLUS Superannuation Fund', 'Accumulation', '343','343','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1467' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1467','HOSTPLUS Superannuation Fund - MySuper', 'MySuper', '343','343','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1752' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1752','HUB24 Super Fund - Account Based Pension', 'Pension', '568','568','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1751' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1751','HUB24 Super Fund - Personal Super', 'Accumulation', '568','568','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1144' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1144','IAG & NRMA Superannuation Plan - IAG Sub-Plan', 'Accumulation', '422','422','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1501' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1501','IAG & NRMA Superannuation Plan - MySuper', 'MySuper', '422','422','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1145' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1145','IAG & NRMA Superannuation Plan - NRMA Sub-Plan', 'Accumulation', '422','422','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1963' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1963','IAG & NRMA Superannuation Plan - Pension', 'Pension', '422','422','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1294' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1294','ING Living Super', 'Accumulation', '461','461','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1295' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1295','ING Pension Account', 'Pension', '461','461','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1468' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1468','Intrust Core Super - MySuper', 'MySuper', '249','249','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '634' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '634','Intrust Super - Core Super', 'Accumulation', '249','249','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '907' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '907','Intrust Super - Executive Super', 'Accumulation', '249','249','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '930' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '930','Intrust Super - Select Super', 'Accumulation', '249','249','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '845' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '845','Intrust Super - Super Stream', 'Pension', '249','249','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '660' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '660','IOOF Employer Super - Employer Division', 'Accumulation', '250','250','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1555' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1555','IOOF Employer Super - MySuper', 'MySuper', '250','250','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '884' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '884','IOOF Employer Super - Personal Division', 'Accumulation', '250','250','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1252' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1252','IOOF Employer Super (Corporate 100)', 'Accumulation', '250','250','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1253' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1253','IOOF Employer Super AP (Corporate 100)', 'Pension', '250','250','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '885' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '885','IOOF Employer Super Pension', 'Pension', '250','250','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '846' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '846','IOOF Portfolio Service - Allocated Pension', 'Pension', '250','250','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '847' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '847','IOOF Portfolio Service - Personal Superannuation', 'Accumulation', '250','250','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '960' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '960','IOOF Pursuit - Core Allocated Pension', 'Pension', '250','250','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '959' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '959','IOOF Pursuit - Core Personal Superannuation', 'Accumulation', '250','250','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1263' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1263','IOOF Pursuit - Focus Allocated Pension', 'Pension', '250','250','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1254' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1254','IOOF Pursuit - Focus Personal Superannuation', 'Accumulation', '250','250','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '958' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '958','IOOF Pursuit - Select Allocated Pension', 'Pension', '250','250','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '957' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '957','IOOF Pursuit - Select Personal Superannuation', 'Accumulation', '250','250','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '951' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '951','ipac iAccess Allocated Pension', 'Pension', '344','344','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '950' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '950','ipac iAccess Personal Superannuation', 'Accumulation', '344','344','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1552' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1552','IPE Super - MySuper', 'MySuper', '431','431','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1168' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1168','IPE Super Account Based Pension', 'Pension', '431','431','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1167' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1167','IPE Super Accumulation', 'Accumulation', '431','431','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '848' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '848','IRIS Super Income Stream', 'Pension', '354','354','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1929' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1929','ITW Superannuation Plan', 'Accumulation', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1930' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1930','ITW Superannuation Plan - MySuper', 'MySuper', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1921' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1921','John Holland Superannuation Plan', 'Accumulation', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1923' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1923','John Holland Superannuation Plan - MySuper', 'MySuper', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1055' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1055','Kinetic Smart Pension', 'Pension', '229','229','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1465' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1465','Kinetic Super', 'Accumulation', '229','229','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1456' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1456','Kinetic Super Growth (MySuper)', 'MySuper', '229','229','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '702' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '702','legalsuper', 'Accumulation', '320','320','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1458' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1458','legalsuper MySuper Balanced', 'MySuper', '320','320','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '938' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '938','legalsuper Pension', 'Pension', '320','320','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '937' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '937','legalsuper Personal', 'Accumulation', '320','320','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1574' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1574','LESF MySuper', 'MySuper', '308','308','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1753' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1753','LESF Pension Plan', 'Pension', '308','308','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '701' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '701','LESF Super', 'Accumulation', '308','308','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '704' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '704','LGIAsuper - Accumulation Account', 'Accumulation', '311','311','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '780' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '780','LGIAsuper - Accumulation Account (Retained Benefits)', 'Accumulation', '311','311','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1542' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1542','LGIAsuper - MySuper Lifecycle', 'MySuper', '311','311','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '781' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '781','LGIAsuper - Pension Account', 'Pension', '311','311','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1931' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1931','Lion Dairy & Drinks Superannuation Plan', 'Accumulation', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1932' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1932','Lion Dairy & Drinks Superannuation Plan - MySuper', 'MySuper', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '947' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '947','Local Government Super Account Based Pension', 'Pension', '345','345','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '703' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '703','Local Government Super Accumulation Scheme', 'Accumulation', '345','345','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1475' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1475','Local Government Super MySuper Age Based Investment Strategy', 'MySuper', '345','345','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1182' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1182','Local Government Super Personal Division', 'Accumulation', '345','345','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '742' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '742','Local Government Super Retirement Scheme', 'Accumulation', '345','345','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1102' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1102','LUCRF Personal Plan', 'Accumulation', '253','253','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '968' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '968','LUCRF Retirement Pension', 'Pension', '253','253','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '640' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '640','LUCRF Super', 'Accumulation', '253','253','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1474' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1474','LUCRF Super - MySuper Balanced', 'MySuper', '253','253','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1063' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1063','Lutheran Super', 'Accumulation', '394','394','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1064' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1064','Lutheran Super - Account Based Pension', 'Pension', '394','394','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1619' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1619','Lutheran Super - MySuper', 'MySuper', '394','394','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1943' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1943','Lutheran Super - Retained Benefit', 'Accumulation', '394','394','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1965' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1965','LVMH Super Plan', 'Accumulation', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1966' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1966','LVMH Super Plan - MySuper', 'MySuper', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '794' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '794','Macquarie SuperOptions - Allocated Pension Plan', 'Pension', '312','312','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '705' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '705','Macquarie SuperOptions - Super Plan', 'Accumulation', '312','312','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1696' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1696','Macquarie Wrap - Pension Consolidator', 'Pension', '312','312','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1700' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1700','Macquarie Wrap - Pension Manager', 'Pension', '312','312','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '982' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '982','Macquarie Wrap - Super Accumulator', 'Accumulation', '312','312','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1695' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1695','Macquarie Wrap - Super Consolidator', 'Accumulation', '312','312','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1699' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1699','Macquarie Wrap - Super Manager', 'Accumulation', '312','312','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '864' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '864','MAP Pension Plan', 'Pension', '314','314','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '706' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '706','MAP Superannuation Plan', 'Accumulation', '314','314','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1138' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1138','Maritime Super - Accumulation Advantage', 'Accumulation', '283','283','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '889' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '889','Maritime Super - Allocated Pension', 'Pension', '283','283','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1479' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1479','Maritime Super - MySuper', 'MySuper', '283','283','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '917' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '917','Maritime Super - Seafarers Contributory Accumulation', 'Accumulation', '283','283','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '916' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '916','Maritime Super - Stevedores Accumulation Basic', 'Accumulation', '283','283','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '663' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '663','Maritime Super - Stevedores Accumulation PLUS', 'Accumulation', '283','283','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '881' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '881','Matrix Employer Superannuation Plan', 'Accumulation', '407','407','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '880' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '880','Matrix Personal Superannuation Plan', 'Accumulation', '407','407','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '883' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '883','Matrix Superannuation Master Trust - Allocated Pension', 'Pension', '407','407','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '882' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '882','Matrix Superannuation Master Trust - Superannuation & Rollover', 'Accumulation', '407','407','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '981' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '981','max Super Fund - Corporate Plan', 'Accumulation', '341','341','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1577' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1577','max Super Fund - MySuper', 'MySuper', '341','341','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '737' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '737','max Super Fund - Personal', 'Accumulation', '341','341','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '867' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '867','Meat Industry Employees Super Fund - Allocated Pension', 'Pension', '255','255','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '641' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '641','Meat Industry Employees Superannuation Fund', 'Accumulation', '255','255','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1556' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1556','Meat Industry Employees Superannuation Fund - MySuper', 'MySuper', '255','255','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '654' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '654','Media Super', 'Accumulation', '270','270','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1455' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1455','Media Super MySuper', 'MySuper', '270','270','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '872' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '872','Media Super Personal Account', 'Accumulation', '270','270','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '873' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '873','Media Super Retirement Pension', 'Pension', '270','270','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1106' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1106','Mentor Employer Superannuation Plan', 'Accumulation', '407','407','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1107' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1107','Mentor Personal Superannuation Plan', 'Accumulation', '407','407','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1113' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1113','Mentor Superannuation Master Trust - Allocated Pension', 'Pension', '407','407','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1112' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1112','Mentor Superannuation Master Trust - Superannuation and Rollovers', 'Accumulation', '407','407','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '861' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '861','Mercer Portfolio Allocated Pension Account', 'Pension', '356','356','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '860' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '860','Mercer Portfolio Super Account- Category 1', 'Accumulation', '356','356','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1336' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1336','Mercer Portfolio Super Account- Category 2', 'Accumulation', '356','356','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1559' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1559','Mercer SmartPath - MySuper', 'MySuper', '267','267','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '796' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '796','Mercer Super Trust - Allocated Pension', 'Pension', '267','267','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '642' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '642','Mercer Super Trust - Corporate Superannuation Division', 'Accumulation', '267','267','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '798' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '798','Mercer Super Trust - Personal Superannuation Division', 'Accumulation', '267','267','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1123' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1123','Mercy Super - Award & SG Category', 'Accumulation', '414','414','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1124' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1124','Mercy Super - Contributory Accumulation Category', 'Accumulation', '414','414','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1125' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1125','Mercy Super - Income Stream', 'Pension', '414','414','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1560' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1560','Mercy Super - MySuper', 'MySuper', '414','414','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1507' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1507','Mine Wealth + Wellbeing MySuper', 'MySuper', '342','342','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '813' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '813','Mine Wealth + Wellbeing Pension', 'Pension', '342','342','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '685' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '685','Mine Wealth + Wellbeing Super', 'Accumulation', '342','342','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '978' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '978','MLC MasterKey - Pension', 'Pension', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '776' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '776','MLC MasterKey Account Based Pension', 'Pension', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '644' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '644','MLC MasterKey Business Super', 'Accumulation', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1524' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1524','MLC MasterKey Business Super - MLC MySuper', 'MySuper', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1053' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1053','MLC MasterKey Pension Fundamentals', 'Pension', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '974' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '974','MLC MasterKey Super', 'Accumulation', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1052' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1052','MLC MasterKey Super Fundamentals', 'Accumulation', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '775' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '775','MLC MasterKey Superannuation', 'Accumulation', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '797' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '797','MLC Navigator Retirement Plan - Account Based Pension', 'Pension', '358','358','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '800' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '800','MLC Navigator Retirement Plan - Superannuation Service', 'Accumulation', '358','358','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1656' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1656','MLC Navigator Retirement Plan Series 2 - Account Based Pension', 'Pension', '358','358','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1654' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1654','MLC Navigator Retirement Plan Series 2 - Super', 'Accumulation', '358','358','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1510' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1510','MLC Wrap Pension', 'Pension', '358','358','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1582' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1582','MLC Wrap Pension Series 2', 'Pension', '358','358','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1509' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1509','MLC Wrap Super', 'Accumulation', '358','358','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1581' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1581','MLC Wrap Super Series 2', 'Accumulation', '358','358','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1534' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1534','MTAA MySuper', 'MySuper', '271','271','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '645' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '645','MTAA Super', 'Accumulation', '271','271','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '929' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '929','MTAA Super Pension', 'Pension', '271','271','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1090' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1090','MX SuperWrap Pension Plan', 'Pension', '361','361','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1089' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1089','MX SuperWrap Personal Super Plan', 'Accumulation', '361','361','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '821' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '821','MyLife MyPension', 'Pension', '237','237','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1746' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1746','MyLife MySuper', 'Accumulation', '567','567','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1748' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1748','MyLife MySuper - Default Strategy', 'MySuper', '567','567','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1747' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1747','MyLife MySuper - Personal Plan', 'Accumulation', '567','567','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1891' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1891','MyNorth Pension', 'Pension', '344','344','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1890' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1890','MyNorth Super', 'Accumulation', '344','344','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1099' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1099','NAB Group Super - Fund A', 'Accumulation', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1553' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1553','NAB Group Super Fund A - MySuper', 'MySuper', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '709' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '709','Nationwide Super - Employer Sponsored Division', 'Accumulation', '313','313','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1503' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1503','Nationwide Super - Employer Sponsored Division MySuper', 'MySuper', '313','313','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1241' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1241','Nationwide Super - Pension Division', 'Pension', '313','313','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '859' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '859','Nationwide Super - Personal Division', 'Accumulation', '313','313','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1915' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1915','NEO SuperSMA - Account Based Pension', 'Pension', '637','637','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1914' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1914','NEO SuperSMA Accumulation Account', 'Accumulation', '637','637','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1081' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1081','NESS Account Based Pension', 'Pension', '262','262','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '648' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '648','NESS Super', 'Accumulation', '262','262','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1469' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1469','NESS Super - MySuper', 'MySuper', '262','262','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1264' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1264','netwealth Super Accelerator Core - Employer Sponsored Super', 'Accumulation', '369','369','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1265' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1265','netwealth Super Accelerator Core - Personal Super', 'Accumulation', '369','369','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1266' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1266','netwealth Super Accelerator Core - Standard Income Stream', 'Pension', '369','369','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1268' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1268','netwealth Super Accelerator Plus - Employer Sponsored Super', 'Accumulation', '369','369','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1269' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1269','netwealth Super Accelerator Plus - Personal Super', 'Accumulation', '369','369','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1271' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1271','netwealth Super Accelerator Plus - Standard Income Stream', 'Pension', '369','369','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '970' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '970','netwealth Super Wrap - Employer Sponsored Super', 'Accumulation', '369','369','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '969' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '969','netwealth Super Wrap - Personal Super', 'Accumulation', '369','369','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '971' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '971','netwealth Super Wrap - Standard Income Stream', 'Pension', '369','369','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '972' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '972','netwealth Super Wrap - Transition to Retirement Income Stream', 'Pension', '369','369','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '855' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '855','NGS Super - Income Account', 'Pension', '269','269','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '647' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '647','NGS Super - Industry Plan', 'Accumulation', '269','269','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1472' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1472','NGS Super - MySuper', 'MySuper', '269','269','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '854' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '854','NGS Super - Personal Plan', 'Accumulation', '269','269','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1016' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1016','North Pension', 'Pension', '344','344','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1015' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1015','North Super', 'Accumulation', '344','344','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '636' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '636','OnePath Corporate Super', 'Accumulation', '254','254','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '844' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '844','OnePath Corporate Super Personal', 'Accumulation', '254','254','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '700' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '700','OnePath Integra Super', 'Accumulation', '254','254','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1186' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1186','OnePath OneAnswer Frontier Pension', 'Pension', '254','254','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1185' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1185','OnePath OneAnswer Frontier Personal Super', 'Accumulation', '254','254','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '750' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '750','OnePath OneAnswer Pension', 'Pension', '254','254','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '749' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '749','OnePath OneAnswer Personal Super', 'Accumulation', '254','254','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '793' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '793','OnePath OptiMix Allocated Pension', 'Pension', '254','254','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '790' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '790','OnePath OptiMix Super', 'Accumulation', '254','254','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1173' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1173','Oracle Superannuation Plan', 'Accumulation', '433','433','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1520' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1520','Perpetual MySuper', 'MySuper', '263','263','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '779' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '779','Perpetual Select Pension Plan', 'Pension', '263','263','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '652' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '652','Perpetual Select Superannuation Plan', 'Accumulation', '263','263','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '778' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '778','Perpetual WealthFocus Pension Plan', 'Pension', '350','350','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '777' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '777','Perpetual WealthFocus Super Plan', 'Accumulation', '350','350','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1245' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1245','Perpetual WealthFocus Wholesale Pension Plan', 'Pension', '350','350','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1244' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1244','Perpetual WealthFocus Wholesale Super Plan', 'Accumulation', '350','350','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '923' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '923','Plum Personal Plan', 'Accumulation', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1911' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1911','Plum Retirement Income', 'Pension', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '653' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '653','Plum Super', 'Accumulation', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1536' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1536','Plum Super - MySuper', 'MySuper', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '896' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '896','PortfolioOne Allocated Pension Service', 'Pension', '357','357','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '895' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '895','PortfolioOne Superannuation Service', 'Accumulation', '357','357','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1913' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1913','Praemium SuperSMA Account Based Pension', 'Pension', '637','637','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1912' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1912','Praemium SuperSMA Accumulation Account', 'Accumulation', '637','637','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '922' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '922','Prime Super', 'Accumulation', '304','304','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1583' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1583','Prime Super HIP Division', 'Accumulation', '304','304','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1459' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1459','Prime Super MySuper', 'MySuper', '304','304','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '943' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '943','Prime Super Retirement Income Stream', 'Pension', '304','304','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1121' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1121','QANTAS Super - Division 6', 'Accumulation', '274','274','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1492' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1492','QANTAS Super Gateway', 'Accumulation', '274','274','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '939' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '939','QANTAS Super Gateway - Income Account', 'Pension', '274','274','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1532' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1532','QANTAS Super Gateway - MySuper', 'MySuper', '274','274','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '728' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '728','QIEC Super', 'Accumulation', '334','334','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '945' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '945','QIEC Super - Income Stream', 'Pension', '334','334','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1495' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1495','QIEC Super - MySuper', 'MySuper', '334','334','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '628' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '628','QSuper - Accumulation', 'Accumulation', '251','251','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '799' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '799','QSuper - Income Account', 'Pension', '251','251','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1527' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1527','QSuper Lifetime', 'MySuper', '251','251','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '712' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '712','REI Super', 'Accumulation', '321','321','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1497' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1497','REI Super - MySuper', 'MySuper', '321','321','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '948' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '948','REI Super Pension', 'Pension', '321','321','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '787' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '787','REST Allocated Pension', 'Pension', '222','222','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1481' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1481','REST Corporate', 'Accumulation', '222','222','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1653' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1653','REST Corporate - MySuper', 'MySuper', '222','222','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '657' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '657','REST Super', 'Accumulation', '222','222','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1477' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1477','REST Super - MySuper', 'MySuper', '222','222','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '773' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '773','Retirement Directions Allocated Pension', 'Pension', '437','437','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1551' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1551','RetireSelect Pension', 'Pension', '314','314','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1550' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1550','RetireSelect Super', 'Accumulation', '314','314','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1976' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1976','Russell Investments Super Series - Income Stream', 'Pension', '369','369','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1975' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1975','Russell Investments Super Series - Personal', 'Accumulation', '369','369','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1977' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1977','Russell Investments Super Series - Transition to Retirement Income Stream', 'Pension', '369','369','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '986' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '986','Russell iQ Retirement', 'Pension', '310','310','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '714' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '714','Russell iQ Super - Employer', 'Accumulation', '310','310','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1565' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1565','Russell iQ Super - General', 'Accumulation', '310','310','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1563' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1563','Russell iQ Super - MySuper', 'MySuper', '310','310','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '877' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '877','Russell iQ Super - Personal', 'Accumulation', '310','310','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '878' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '878','Russell iQ Super - Saver', 'Accumulation', '310','310','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1918' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1918','Shell Australian Super Plan', 'Accumulation', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1919' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1919','Shell Australian Super Plan - MySuper', 'MySuper', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1183' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1183','Simple Super', 'Accumulation', '437','437','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1197' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1197','smartMonday DIRECT', 'Accumulation', '226','226','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '747' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '747','smartMonday DIRECT (Legacy)', 'Accumulation', '226','226','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1526' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1526','smartMonday MySuper', 'MySuper', '226','226','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1289' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1289','smartMonday PENSION', 'Pension', '226','226','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '745' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '745','smartMonday PENSION (Legacy)', 'Pension', '226','226','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1285' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1285','smartMonday PRIME', 'Accumulation', '226','226','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '601' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '601','smartMonday PRIME (Legacy)', 'Accumulation', '226','226','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1035' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1035','Smartsave - 1st Super', 'Accumulation', '384','384','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1032' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1032','Smartsave - Employer', 'Accumulation', '384','384','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1033' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1033','Smartsave - Personal', 'Accumulation', '384','384','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1034' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1034','Smartsave - Smart Pension', 'Pension', '384','384','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1538' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1538','Smartsave MySuper', 'MySuper', '384','384','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1854' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1854','SmartWrap Pension Account', 'Pension', '601','601','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1853' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1853','SmartWrap Superannuation Account', 'Accumulation', '601','601','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1944' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1944','Spaceship Super', 'Accumulation', '639','639','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '715' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '715','State Super Pooled Fund - State Authorities Superannuation Scheme - Accumulation division (SASS)', 'Accumulation', '322','322','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '989' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '989','StatePlus - Allocated Pension Fund', 'Pension', '372','372','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1566' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1566','StatePlus - Flexible Income Plan', 'Pension', '372','372','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '988' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '988','StatePlus - Personal Retirement Plan', 'Accumulation', '372','372','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1567' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1567','StatePlus - Tailored Super Plan', 'Accumulation', '372','372','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '662' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '662','StatewideSuper Employer Sponsored', 'Accumulation', '306','306','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1460' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1460','StatewideSuper MySuper', 'MySuper', '306','306','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '888' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '888','StatewideSuper Pension Plan', 'Pension', '306','306','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1140' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1140','StatewideSuper Personal', 'Accumulation', '306','306','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1007' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1007','Strategy Employer Superannuation Plan', 'Accumulation', '407','407','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1088' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1088','Strategy Personal Superannuation Plan', 'Accumulation', '407','407','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1009' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1009','Strategy Retirement Fund - Allocated Pension', 'Pension', '407','407','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1008' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1008','Strategy Retirement Fund - Superannuation and Rollover', 'Accumulation', '407','407','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '771' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '771','Summit Personal Pension', 'Pension', '344','344','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '770' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '770','Summit Personal Super', 'Accumulation', '344','344','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1528' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1528','Suncorp - Suncorp Lifestage Funds', 'MySuper', '355','355','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1895' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1895','Suncorp Brighter Super - Business', 'Accumulation', '355','355','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1897' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1897','Suncorp Brighter Super - Pension', 'Pension', '355','355','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1896' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1896','Suncorp Brighter Super - Personal', 'Accumulation', '355','355','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1322' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1322','Suncorp Everyday Super - Business', 'Accumulation', '355','355','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1371' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1371','Suncorp Everyday Super - Pension', 'Pension', '355','355','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1321' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1321','Suncorp Everyday Super - Personal', 'Accumulation', '355','355','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '727' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '727','Sunsuper - Corporate', 'Accumulation', '276','276','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1958' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1958','Sunsuper for Life - BlueScope Super', 'Accumulation', '276','276','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1959' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1959','Sunsuper for Life - BlueScope Super MySuper', 'MySuper', '276','276','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '804' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '804','Sunsuper for Life - Income Account', 'Pension', '276','276','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1505' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1505','Sunsuper for Life - MySuper', 'MySuper', '276','276','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '665' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '665','Sunsuper for Life - Super-savings Account', 'Accumulation', '276','276','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1749' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1749','Sunsuper for Life Business - savings account', 'Accumulation', '276','276','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '608' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '608','Super Directions for Business', 'Accumulation', '437','437','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1179' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1179','Super Directions for Business - Rollover Division', 'Accumulation', '437','437','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '772' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '772','Super Directions Personal Super Plan', 'Accumulation', '437','437','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '769' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '769','Super SA - Flexible Rollover Product', 'Accumulation', '329','329','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '768' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '768','Super SA - Income Stream', 'Pension', '329','329','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1372' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1372','Super SA - Select', 'Accumulation', '329','329','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '717' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '717','Super SA - Triple S Scheme', 'Accumulation', '329','329','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1184' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1184','Tailored Super', 'Accumulation', '437','437','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '979' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '979','Tasplan Pension', 'Pension', '289','289','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '666' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '666','Tasplan Protect 1', 'Accumulation', '289','289','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1484' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1484','Tasplan Protect 1 MySuper', 'MySuper', '289','289','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1941' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1941','Tasplan Protect 2', 'Accumulation', '289','289','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1942' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1942','Tasplan Protect 2 MySuper', 'MySuper', '289','289','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1535' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1535','TelstraSuper - MySuper', 'MySuper', '282','282','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '667' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '667','TelstraSuper Corporate Plus', 'Accumulation', '282','282','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '954' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '954','TelstraSuper Personal Plus', 'Accumulation', '282','282','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1564' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1564','TelstraSuper Personal Plus MySuper', 'MySuper', '282','282','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '893' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '893','TelstraSuper RetireAccess', 'Pension', '282','282','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1373' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1373','The Executive Super - Allocated Pension', 'Pension', '496','496','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1893' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1893','The Executive Super - Employer Sponsored', 'Accumulation', '496','496','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1620' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1620','The Executive Super - MySuper MyLife', 'MySuper', '496','496','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1378' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1378','The Executive Super - Personal Division', 'Accumulation', '496','496','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1178' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1178','The Grosvenor Pirie Master Super Fund - Series 2 - Account Based Pension', 'Pension', '430','430','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1122' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1122','The Grosvenor Pirie Master Superannuation Fund - Series 2', 'Accumulation', '430','430','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1448' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1448','TWUSUPER - Balanced (MySuper)', 'MySuper', '288','288','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '668' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '668','TWUSUPER - Employer Sponsored', 'Accumulation', '288','288','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '764' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '764','TWUSUPER - TransPension', 'Pension', '288','288','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '763' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '763','TWUSUPER - TransPersonal', 'Accumulation', '288','288','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '914' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '914','TWUSUPER - Transuper (Corporate Division)', 'Accumulation', '288','288','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '765' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '765','UniSuper - Flexi Pension', 'Pension', '279','279','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1529' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1529','UniSuper Accumulation - MySuper', 'MySuper', '279','279','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '669' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '669','UniSuper Accumulation Super (1)', 'Accumulation', '279','279','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '743' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '743','UniSuper Accumulation Super (2)', 'Accumulation', '279','279','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1973' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1973','UniSuper Personal Account', 'Accumulation', '279','279','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '900' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '900','VicSuper Flexible Income', 'Pension', '286','286','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '670' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '670','VicSuper FutureSaver - EmployeeSaver', 'Accumulation', '286','286','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '899' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '899','VicSuper FutureSaver - PersonalSaver', 'Accumulation', '286','286','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1453' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1453','VicSuper Growth (MySuper)', 'MySuper', '286','286','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '671' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '671','Victorian Independent Schools Superannuation Fund - Accumulation', 'Accumulation', '285','285','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '901' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '901','Victorian Independent Schools Superannuation Fund - Allocated Pension', 'Pension', '285','285','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1557' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1557','Victorian Independent Schools Superannuation Fund - MySuper', 'MySuper', '285','285','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1910' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1910','Virgin Money Super', 'Accumulation', '638','638','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1909' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1909','Virgin Money Super - LifeStage Tracker', 'MySuper', '638','638','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '953' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '953','Vision Personal', 'Accumulation', '281','281','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '956' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '956','Vision Super - Allocated Pension (Public Offer)', 'Pension', '281','281','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1539' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1539','Vision Super - MySuper', 'MySuper', '281','281','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '672' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '672','Vision Super Saver', 'Accumulation', '281','281','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1985' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1985','Visy Industries Super Plan', 'Accumulation', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1986' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1986','Visy Industries Super Plan - MySuper', 'MySuper', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1299' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1299','Voyage Superannuation Master Trust - Allocated Pension', 'Pension', '407','407','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1298' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1298','Voyage Superannuation Master Trust - Superannuation & Rollover', 'Accumulation', '407','407','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '904' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '904','WA Super - Retirement Solutions - Income Stream', 'Pension', '258','258','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '639' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '639','WA Super - Super Solutions - Employer', 'Accumulation', '258','258','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1515' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1515','WA Super - Super Solutions - My WA Super', 'MySuper', '258','258','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '903' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '903','WA Super - Super Solutions - Personal', 'Accumulation', '258','258','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1928' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1928','Wealth Manager SuperWrap Pension Plan', 'Pension', '361','361','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1926' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1926','Wealth Manager SuperWrap Personal Super', 'Accumulation', '361','361','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1108' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1108','Wealthtrac Employer Superannuation Plan', 'Accumulation', '407','407','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1114' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1114','Wealthtrac Personal Superannuation Plan', 'Accumulation', '407','407','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1116' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1116','Wealthtrac Superannuation Master Trust - Allocated Pension', 'Pension', '407','407','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1115' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1115','Wealthtrac Superannuation Master Trust - Superannuation and Rollovers', 'Accumulation', '407','407','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1062' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1062','WealthView eWRAP Pension Account', 'Pension', '378','378','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1000' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1000','WealthView eWRAP Super Account', 'Accumulation', '378','378','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1139' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1139','Westpac Flexible Income Plan', 'Pension', '397','397','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1057' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1057','Westpac Lifetime Superannuation Service', 'Accumulation', '397','397','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1894' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1894','Whole Pension', 'Pension', '314','314','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1892' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1892','Whole Super', 'Accumulation', '314','314','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1174' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1174','Worsley Alumina Superannuation Fund', 'Accumulation', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1548' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1548','Worsley Alumina Superannuation Fund - MySuper', 'MySuper', '634','634','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1414' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1414','YellowBrickRoad Pension', 'Pension', '314','314','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1413' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1413','YellowBrickRoad Super', 'Accumulation', '314','314','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1984' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1984','YourChoice Pension', 'Pension', '314','314','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '1981' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '1981','YourChoice Super', 'Accumulation', '314','314','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '807' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '807','Zurich Account Based Pension', 'Pension', '353','353','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='SR' AND product_id = '806' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'SR', '806','Zurich Superannuation Plan', 'Accumulation', '353','353','','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-21509' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-21509','Advance Australian Fixed Interest Multi-Blend Fund', '', 'FM-15784','FM-15784','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-28556' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-28556','Advance Cash Multi-Blend Fund', '', 'FM-15784','FM-15784','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-21557' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-21557','Advance International Fixed Interest Multi-Blend Fund', '', 'FM-15784','FM-15784','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4081' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4081','Advance International Shares Multi-Blend Fund', '', 'FM-15784','FM-15784','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-8266' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-8266','Advance Wholesale Balanced Multi-Blend Fund', '', 'FM-15784','FM-15784','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-8686' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-8686','Advance Wholesale Defensive Multi-Blend Fund', '', 'FM-15784','FM-15784','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-19256' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-19256','Advance Wholesale Growth Multi-Blend Fund', '', 'FM-15784','FM-15784','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-19255' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-19255','Advance Wholesale High Growth Multi-Blend Fund', '', 'FM-15784','FM-15784','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-19254' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-19254','Advance Wholesale Moderate Multi-Blend Fund', '', 'FM-15784','FM-15784','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-12558' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-12558','Aberdeen Active Index Income Fund', '', 'FM-36179','FM-36179','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4168' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4168','Aberdeen Actively Hedged International Equities Fund', '', 'FM-36179','FM-36179','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-13528' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-13528','Aberdeen Asian Opportunities Fund', '', 'FM-36179','FM-36179','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2DZ2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-7625' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-7625','Aberdeen Australian Fixed Income Fund', '', 'FM-36179','FM-36179','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-13805' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-13805','Aberdeen Australian Floating Rate Income Fund', '', 'FM-36179','FM-36179','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-23813' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-23813','Aberdeen Diversified Fixed Income Fund', '', 'FM-36179','FM-36179','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-18907' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-18907','Aberdeen Emerging Opportunities Fund', '', 'FM-36179','FM-36179','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2DZ2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-7628' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-7628','Aberdeen EX-20 Australian Equities Fund', '', 'FM-36179','FM-36179','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-11421' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-11421','Aberdeen Fully Hedged International Equities Fund', '', 'FM-36179','FM-36179','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4172' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4172','Aberdeen Multi Asset Real Return Fund', '', 'FM-36179','FM-36179','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-7231' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-7231','Aberdeen Multi-Asset Income Fund', '', 'FM-36179','FM-36179','Jude McDonnell','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-11391' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-11391','Aberdeen Wholesale Australian Small Companies Fund', '', 'FM-36179','FM-36179','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-7263' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-7263','Aberdeen Wholesale International Equity Fund', '', 'FM-36179','FM-36179','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30785' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30785','AMP Capital Australian Equity Concentrated Fund', '', 'FM-36186','FM-36186','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30879' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30879','AMP Capital Australian Equity Income Generator - Platform (Class A)', '', 'FM-36186','FM-36186','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-28371' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-28371','AMP Capital Australian Equity Opportunities Fund', '', 'FM-36186','FM-36186','Adrian  Hoe','https://ap1.salesforce.com/a0L9000001Fo9tY?srPos=0&srKp=a0N')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-18988' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-18988','AMP Capital Core Infrastructure Fund', '', 'FM-36186','FM-36186','Sam Morris','https://ap1.salesforce.com/a0L9000001E0y4g')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-22798' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-22798','AMP Capital Corporate Bond Fund  Class A', '', 'FM-36186','FM-36186','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30892' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30892','AMP Capital Dynamic Markets Fund', '', 'FM-36186','FM-36186','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32055' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32055','AMP Capital Dynamic Markets Fund (Hedge Fund)', '', 'FM-36186','FM-36186','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4087' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4087','AMP Capital Equity Fund Class A', '', 'FM-36186','FM-36186','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-26738' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-26738','AMP Capital Global Infrastructure Securities Fund (Hedged)  Class A', '', 'FM-36186','FM-36186','Sam Morris','https://ap1.salesforce.com/a0L9000001E0y4g')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-26741' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-26741','AMP Capital Global Infrastructure Securities Fund (Unhedged)  Class A', '', 'FM-36186','FM-36186','Sam Morris','https://ap1.salesforce.com/a0L9000001E0y4g')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32053' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32053','AMP Capital Global Infrastructure Securities Fund (Unhedged) (Managed Fund)', '', 'FM-36186','FM-36186','Sam Morris','https://ap1.salesforce.com/a0L9000001E0y4g')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14499' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14499','AMP Capital Global Property Securities Fund  Class A', '', 'FM-36186','FM-36186','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lc3')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32054' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32054','AMP Capital Global Property Securities Fund (Unhedged)', '', 'FM-36186','FM-36186','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lc3')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-26927' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-26927','AMP Capital Multi-Asset Fund', '', 'FM-36186','FM-36186','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-23728' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-23728','AMP Capital Responsible Investment Leaders Australian Share Fund Class A', '', 'FM-36186','FM-36186','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2GKH')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4093' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4093','AMP Capital Responsible Investment Leaders International Share Fund Class A', '', 'FM-36186','FM-36186','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2GKH')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14576' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14576','AMP Capital Wholesale Core Property Fund', '', 'FM-36186','FM-36186','Kevin Posser','https://ap1.salesforce.com/a0L9000001E0XIo')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32197' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32197','AMP Dynamic Balanced Fund', '', 'FM-36186','FM-36186','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-26108' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-26108','ipac Income Generator', '', 'FM-36186','FM-36186','Jude McDonnell','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-28427' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-28427','ipac Life Choices Premium Growth', '', 'FM-36186','FM-36186','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-6422' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-6422','North Balanced Index', '', 'FM-36186','FM-36186','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-6127' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-6127','North Defensive Index', '', 'FM-36186','FM-36186','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-6423' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-6423','North Growth Index', '', 'FM-36186','FM-36186','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31300' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31300','North Guardian Balanced Fund', '', 'FM-36186','FM-36186','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31301' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31301','North Guardian Growth Fund', '', 'FM-36186','FM-36186','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31299' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31299','North Guardian Moderately Defensive Fund', '', 'FM-36186','FM-36186','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-6120' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-6120','North High Growth Index', '', 'FM-36186','FM-36186','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-6128' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-6128','North Moderately Defensive Index', '', 'FM-36186','FM-36186','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-20994' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-20994','North Professional Alternative Balanced', '', 'FM-36186','FM-36186','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-26725' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-26725','North Professional Balanced', '', 'FM-36186','FM-36186','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31533' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31533','North Professional Conservative', '', 'FM-36186','FM-36186','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-26726' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-26726','North Professional Growth', '', 'FM-36186','FM-36186','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-26727' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-26727','North Professional High Growth', '', 'FM-36186','FM-36186','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-26728' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-26728','North Professional Moderately Conservative', '', 'FM-36186','FM-36186','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4904' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4904','Responsible Investment Leaders Balanced Fund  Class A ', '', 'FM-36186','FM-36186','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-26923' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-26923','Ausbil 130/30 Focus Fund', '', 'FM-36202','FM-36202','Adrian  Hoe','https://ap1.salesforce.com/a0L9000001Fo9tY?srPos=0&srKp=a0N')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-6103' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-6103','Ausbil Australian Active Equity Fund', '', 'FM-36202','FM-36202','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14325' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14325','Ausbil Australian Emerging Leaders Fund', '', 'FM-36202','FM-36202','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-19246' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-19246','Ausbil Australian Geared Equity Fund', '', 'FM-36202','FM-36202','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-26259' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-26259','Ausbil MicroCap Fund', '', 'FM-36202','FM-36202','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-13270' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-13270','Candriam Sustainable Global Equity Fund', '', 'FM-36202','FM-36202','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2GKH')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32110' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32110','MacKay Shields Unconstrained Bond Fund', '', 'FM-36202','FM-36202','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-6513' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-6513','Australian Ethical Australian Shares Fund', '', 'FM-39168','FM-39168','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2GKH')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4095' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4095','Australian Ethical Diversified Shares Fund', '', 'FM-39168','FM-39168','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2GKH')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31850' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31850','Australian Ethical Emerging Companies Wholesale', '', 'FM-39168','FM-39168','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-21021' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-21021','APN A-REIT Fund', '', 'FM-47916','FM-47916','Kevin Posser','https://ap1.salesforce.com/a0L9000001E0XIo')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30096' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30096','APN Asian REIT Fund', '', 'FM-47916','FM-47916','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lc3')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4094' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4094','APN Property for Income Fund', '', 'FM-47916','FM-47916','Kevin Posser','https://ap1.salesforce.com/a0L9000001E0XIo')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14527' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14527','APN Property for Income Fund No. 2', '', 'FM-47916','FM-47916','Kevin Posser','https://ap1.salesforce.com/a0L9000001E0XIo')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-21321' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-21321','Bennelong Australian Equities Fund', '', 'FM-49184','FM-49184','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-27016' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-27016','Bennelong Avoca Emerging Leaders Fund', '', 'FM-49184','FM-49184','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-22716' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-22716','Bennelong ex-20 Australian Equities Fund', '', 'FM-49184','FM-49184','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-28372' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-28372','Bennelong Kardinia Absolute Return Fund', '', 'FM-49184','FM-49184','Adrian  Hoe','https://ap1.salesforce.com/a0L9000001Fo9tY?srPos=0&srKp=a0N')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-31945' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-31945','Bennelong Twenty20 Australian Equities Fund', '', 'FM-49184','FM-49184','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-31960' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-31960','Quay Global Real Estate Fund', '', 'FM-49184','FM-49184','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lc3')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'EF-2-31355' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'EF-2-31355','BetaShares Australian Dividend Harvester Fund', '', 'FM-49185','FM-49185','Adrian Hoe','https://ap1.salesforce.com/a0L9000001Fo9tY')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'EF-2-30531' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'EF-2-30531','BetaShares Australian High Interest Cash ETF', '', 'FM-49185','FM-49185','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32533' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32533','BetaShares Australian Small Companies Select Fund', '', 'FM-49185','FM-49185','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'EF-2-30511' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'EF-2-30511','BetaShares Australian Top 20 Equity Yield Maximiser Fund', '', 'FM-49185','FM-49185','Adrian Hoe','https://ap1.salesforce.com/a0L9000001Fo9tY')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'EF-2-31334' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'EF-2-31334','BetaShares S&P 500 Yield Maximiser Fund', '', 'FM-49185','FM-49185','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-28345' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-28345','BlackRock Australian Equity Absolute Return Fund', '', 'FM-49186','FM-49186','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lQV')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-27349' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-27349','BlackRock Australian Equity Opportunities Fund', '', 'FM-49186','FM-49186','Adrian  Hoe','https://ap1.salesforce.com/a0L9000001Fo9tY?srPos=0&srKp=a0N')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32165' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32165','BlackRock Concentrated Industrial Share Fund', '', 'FM-49186','FM-49186','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31345' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31345','BlackRock Fixed Income Global Opportunities Fund (Aust) Class D', '', 'FM-49186','FM-49186','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14633' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14633','BlackRock Global Allocation Fund (Aust) (Class D)', '', 'FM-49186','FM-49186','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-31950' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-31950','BlackRock Global Multi Asset Income Fund (Aust) (Class D Units)', '', 'FM-49186','FM-49186','Jude McDonnell','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14206' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14206','BlackRock Monthly Income Fund', '', 'FM-49186','FM-49186','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30578' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30578','BlackRock Multi Opportunity Absolute Return Fund', '', 'FM-49186','FM-49186','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lQV')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-6504' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-6504','BlackRock Scientific Australian Equity Fund', '', 'FM-49186','FM-49186','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-7229' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-7229','BlackRock Scientific Diversified Growth Fund', '', 'FM-49186','FM-49186','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-7230' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-7230','BlackRock Scientific Diversified Stable Fund', '', 'FM-49186','FM-49186','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-13020' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-13020','BlackRock Scientific Hedged International Equity Fund', '', 'FM-49186','FM-49186','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-6506' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-6506','BlackRock Scientific International Equity Fund', '', 'FM-49186','FM-49186','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32525' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32525','BlackRock Style Advantage Fund (Aust) Class D', '', 'FM-49186','FM-49186','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lQV')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4246' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4246','BlackRock Tactical Growth Fund', '', 'FM-49186','FM-49186','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lQV')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4252' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4252','BlackRock Wholesale Australian Share Fund', '', 'FM-49186','FM-49186','Adrian  Hoe','https://ap1.salesforce.com/a0L9000001Fo9tY?srPos=0&srKp=a0N')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-6728' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-6728','BlackRock Wholesale International Bond Fund', '', 'FM-49186','FM-49186','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32541' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32541','iShares Core Cash ETF', '', 'FM-49186','FM-49186','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32542' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32542','iShares Enhanced Cash ETF', '', 'FM-49186','FM-49186','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32241' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32241','iShares Enhanced Strategic Aggressive', '', 'FM-49186','FM-49186','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32239' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32239','iShares Enhanced Strategic Balanced', '', 'FM-49186','FM-49186','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32237' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32237','iShares Enhanced Strategic Conservative', '', 'FM-49186','FM-49186','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32240' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32240','iShares Enhanced Strategic Growth', '', 'FM-49186','FM-49186','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32238' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32238','iShares Enhanced Strategic Moderate', '', 'FM-49186','FM-49186','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31136' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31136','1940s Lifestage Fund  A', '', 'FM-49190','FM-49190','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31137' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31137','1950s Lifestage Fund  A', '', 'FM-49190','FM-49190','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31138' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31138','1960s Lifestage Fund  A', '', 'FM-49190','FM-49190','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31139' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31139','1970s Lifestage Fund  A', '', 'FM-49190','FM-49190','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31140' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31140','1980s Lifestage Fund  A', '', 'FM-49190','FM-49190','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31141' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31141','1990s Lifestage Fund  A', '', 'FM-49190','FM-49190','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31142' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31142','2000s Lifestage Fund  A', '', 'FM-49190','FM-49190','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4328' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4328','BT Active Balanced Wholesale Trust', '', 'FM-49190','FM-49190','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30230' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30230','BT Balanced Equity Income', '', 'FM-49190','FM-49190','Adrian Hoe','https://ap1.salesforce.com/a0L9000001Fo9tY')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-28837' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-28837','BT Defensive Equity Income', '', 'FM-49190','FM-49190','Adrian Hoe','https://ap1.salesforce.com/a0L9000001Fo9tY')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4389' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4389','BT Fixed Interest Wholesale Trust', '', 'FM-49190','FM-49190','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14906' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14906','BT Global Property Securities Fund', '', 'FM-49190','FM-49190','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lc3')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31405' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31405','BT Pure Alpha Fixed Income', '', 'FM-49190','FM-49190','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4326' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4326','BT Smaller Companies Wholesale Trust', '', 'FM-49190','FM-49190','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4119' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4119','BT Wholesale Asian Share Fund', '', 'FM-49190','FM-49190','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2DZ2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14327' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14327','BT Wholesale Australian Share Fund', '', 'FM-49190','FM-49190','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4105' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4105','BT Wholesale Balanced Returns Fund', '', 'FM-49190','FM-49190','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4129' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4129','BT Wholesale Conservative Outlook Fund', '', 'FM-49190','FM-49190','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-6603' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-6603','BT Wholesale Core Australian Share Fund', '', 'FM-49190','FM-49190','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4322' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4322','BT Wholesale Core Global Share Fund', '', 'FM-49190','FM-49190','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-11594' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-11594','BT Wholesale Core Hedged Global Share Fund', '', 'FM-49190','FM-49190','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-21538' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-21538','BT Wholesale Enhanced Cash Fund', '', 'FM-49190','FM-49190','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-5314' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-5314','BT Wholesale Ethical Share Fund', '', 'FM-49190','FM-49190','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2GKH')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-18949' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-18949','BT Wholesale Focus Australian Share Fund', '', 'FM-49190','FM-49190','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4111' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4111','BT Wholesale Future Goals Fund', '', 'FM-49190','FM-49190','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-12736' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-12736','BT Wholesale Geared Imputation Fund', '', 'FM-49190','FM-49190','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-28835' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-28835','BT Wholesale Global Emerging Markets Opportunities Fund', '', 'FM-49190','FM-49190','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2DZ2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32213' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32213','BT Wholesale High Growth Fund', '', 'FM-49190','FM-49190','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-6415' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-6415','BT Wholesale Imputation Fund', '', 'FM-49190','FM-49190','Adrian Hoe','https://ap1.salesforce.com/a0L9000001Fo9tY')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4115' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4115','BT Wholesale International Share Fund', '', 'FM-49190','FM-49190','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-23089' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-23089','BT Wholesale MidCap Fund', '', 'FM-49190','FM-49190','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32212' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32212','BT Wholesale Moderate Fund', '', 'FM-49190','FM-49190','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-23515' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-23515','BT Wholesale Monthly Income Plus Fund', '', 'FM-49190','FM-49190','Jude McDonnell','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-11311' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-11311','BT Wholesale Multi-manager Balanced Fund', '', 'FM-49190','FM-49190','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-11306' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-11306','BT Wholesale Multi-manager Conservative Fund', '', 'FM-49190','FM-49190','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-11315' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-11315','BT Wholesale Multi-manager Growth Fund', '', 'FM-49190','FM-49190','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-11319' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-11319','BT Wholesale Multi-manager High Growth Fund', '', 'FM-49190','FM-49190','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-20377' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-20377','BT Wholesale Multi-manager International Share Fund', '', 'FM-49190','FM-49190','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4125' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4125','BT Wholesale Property Securities Fund', '', 'FM-49190','FM-49190','Kevin Posser','https://ap1.salesforce.com/a0L9000001E0XIo')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30040' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30040','Capital Group Emerging Markets Total Opportunities Fund (AU)', '', 'FM-49192','FM-49192','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2DZ2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30039' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30039','Capital Group Global Equity Fund (AU)', '', 'FM-49192','FM-49192','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30038' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30038','Capital Group Global Equity Fund Hedged (AU)', '', 'FM-49192','FM-49192','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-31957' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-31957','Capital Group New Perspective Fund (AU)', '', 'FM-49192','FM-49192','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-31958' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-31958','Capital Group New Perspective Fund Hedged (AU)', '', 'FM-49192','FM-49192','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31344' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31344','Capital Group World Dividend Growers (AU)', '', 'FM-49192','FM-49192','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31696' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31696','Capital Group World Dividend Growers Hedged (AU)', '', 'FM-49192','FM-49192','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31230' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31230','CareSuper  Alternative Growth', '', 'FM-49193','FM-49193','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31233' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31233','CareSuper  Balanced', '', 'FM-49193','FM-49193','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31235' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31235','CareSuper  Capital Stable', '', 'FM-49193','FM-49193','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31234' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31234','CareSuper  Conservative Balanced', '', 'FM-49193','FM-49193','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31231' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31231','CareSuper  Growth', '', 'FM-49193','FM-49193','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31232' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31232','CareSuper  Sustainable Balanced', '', 'FM-49193','FM-49193','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14881' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14881','CBG Australian Equities Fund', '', 'FM-49194','FM-49194','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30896' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30896','Cbus Industry  Cash Savings', '', 'FM-49195','FM-49195','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30897' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30897','Cbus Industry  Conservative', '', 'FM-49195','FM-49195','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30898' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30898','Cbus Industry  Growth', '', 'FM-49195','FM-49195','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30899' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30899','Cbus Industry  High Growth', '', 'FM-49195','FM-49195','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30946' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30946','Cbus Super Income Stream  Conservative Growth', '', 'FM-49195','FM-49195','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-5737' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-5737','Celeste Australian Small Companies Fund', '', 'FM-49196','FM-49196','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-25159' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-25159','Centuria Life Limited - Australian Shares Bond', '', 'FM-49197','FM-49197','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-25157' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-25157','Centuria Life Limited  Balanced Bond', '', 'FM-49197','FM-49197','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-25158' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-25158','Centuria Life Limited  High Growth Bond', '', 'FM-49197','FM-49197','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-13780' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-13780','Alphinity Wholesale Australian Equity Fund', '', 'FM-49199','FM-49199','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-6352' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-6352','Alphinity Wholesale Australian Share Fund', '', 'FM-49199','FM-49199','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14368' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14368','Alphinity Wholesale Concentrated Australian Share Fund', '', 'FM-49199','FM-49199','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-11192' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-11192','Alphinity Wholesale Socially Responsible Share Fund', '', 'FM-49199','FM-49199','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2GKH')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-13806' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-13806','Bentham Wholesale Global Income Fund', '', 'FM-49199','FM-49199','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-7594' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-7594','Bentham Wholesale High Yield Fund', '', 'FM-49199','FM-49199','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-15132' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-15132','Bentham Wholesale Syndicated Loan Fund', '', 'FM-49199','FM-49199','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32539' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32539','Challenger Absolute Return Global Bond Strategies Fund', '', 'FM-49199','FM-49199','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-18893' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-18893','Greencape Wholesale Broadcap Fund', '', 'FM-49199','FM-49199','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-21602' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-21602','Greencape Wholesale High Conviction Fund', '', 'FM-49199','FM-49199','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-21365' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-21365','Kapstream Wholesale Absolute Return Income Fund', '', 'FM-49199','FM-49199','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-18541' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-18541','Kinetic Wholesale Emerging Companies Fund', '', 'FM-49199','FM-49199','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4192' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4192','Merlon Wholesale Australian Share Income Fund', '', 'FM-49199','FM-49199','Adrian Hoe','https://ap1.salesforce.com/a0L9000001Fo9tY')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-18642' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-18642','NovaPort Microcap Fund', '', 'FM-49199','FM-49199','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-12436' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-12436','NovaPort Wholesale Smaller Companies Fund', '', 'FM-49199','FM-49199','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-21451' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-21451','WaveStone Dynamic Equity Fund', '', 'FM-49199','FM-49199','Adrian  Hoe','https://ap1.salesforce.com/a0L9000001Fo9tY?srPos=0&srKp=a0N')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-13781' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-13781','WaveStone Wholesale Australian Share Fund', '', 'FM-49199','FM-49199','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32176' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32176','CC JCB Active Bond Fund', '', 'FM-49200','FM-49200','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-21298' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-21298','Acadian Defensive Income  Class A', '', 'FM-49204','FM-49204','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-28591' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-28591','Acadian Global Managed Volatility Equity Fund  Class A', '', 'FM-49204','FM-49204','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-15014' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-15014','Acadian Wholesale Australian Equity Long/Short', '', 'FM-49204','FM-49204','Adrian  Hoe','https://ap1.salesforce.com/a0L9000001Fo9tY?srPos=0&srKp=a0N')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14774' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14774','Acadian Wholesale Global Equity Fund', '', 'FM-49204','FM-49204','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-23094' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-23094','Aspect Diversified Futures Fund  Class A', '', 'FM-49204','FM-49204','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lQV')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31001' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31001','CFS FirstChoice Multi-Index Balanced Fund  Class A', '', 'FM-49204','FM-49204','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31000' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31000','CFS FirstChoice Multi-Index Conservative Fund  Class A', '', 'FM-49204','FM-49204','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31354' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31354','CFS FirstChoice Multi-Index Diversified Fund  Class A', '', 'FM-49204','FM-49204','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31289' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31289','CFS FirstChoice Multi-Index High Growth Fund  Class A', '', 'FM-49204','FM-49204','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32173' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32173','CFS FirstChoice Multi-Index Moderate Fund  Class A', '', 'FM-49204','FM-49204','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-19602' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-19602','CFS FirstChoice Wholesale Asian Share', '', 'FM-49204','FM-49204','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2DZ2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14540' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14540','CFS FirstChoice Wholesale Australian Small Companies', '', 'FM-49204','FM-49204','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-21523' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-21523','CFS FirstChoice Wholesale Balanced Fund', '', 'FM-49204','FM-49204','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14344' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14344','CFS FirstChoice Wholesale Conservative Fund', '', 'FM-49204','FM-49204','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14343' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14343','CFS FirstChoice Wholesale Defensive Fund', '', 'FM-49204','FM-49204','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31905' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31905','CFS FirstChoice Wholesale Diversified Fund', '', 'FM-49204','FM-49204','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-23911' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-23911','CFS FirstChoice Wholesale Emerging Markets', '', 'FM-49204','FM-49204','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2DZ2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-20471' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-20471','CFS FirstChoice Wholesale Geared Growth Plus Fund', '', 'FM-49204','FM-49204','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-19509' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-19509','CFS FirstChoice Wholesale Global Property Securities Fund', '', 'FM-49204','FM-49204','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lc3')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-20885' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-20885','CFS FirstChoice Wholesale Global Share  Hedged', '', 'FM-49204','FM-49204','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14349' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14349','CFS FirstChoice Wholesale Global Share Fund', '', 'FM-49204','FM-49204','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14346' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14346','CFS FirstChoice Wholesale Growth Fund', '', 'FM-49204','FM-49204','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14347' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14347','CFS FirstChoice Wholesale High Growth Fund', '', 'FM-49204','FM-49204','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14345' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14345','CFS FirstChoice Wholesale Moderate Fund', '', 'FM-49204','FM-49204','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-28638' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-28638','CFS Global Listed Infrastructure Securities  Class A', '', 'FM-49204','FM-49204','Sam Morris','https://ap1.salesforce.com/a0L9000001E0y4g')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4156' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4156','CFS Wholesale Global Resources Fund', '', 'FM-49204','FM-49204','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31404' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31404','CFS Wholesale Worldwide Sustainability Fund  Class A', '', 'FM-49204','FM-49204','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-31994' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-31994','Colonial First State Asian Growth Fund', '', 'FM-49204','FM-49204','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2DZ2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32557' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32557','Colonial First State FirstChoice Multi-Index Growth Fund  Class A', '', 'FM-49204','FM-49204','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14348' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14348','Colonial First State FirstChoice Wholesale Australian Share Fund', '', 'FM-49204','FM-49204','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-22721' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-22721','Colonial First State FirstChoice Wholesale Global Infrastructure Securities Fund', '', 'FM-49204','FM-49204','Sam Morris','https://ap1.salesforce.com/a0L9000001E0y4g')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-13913' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-13913','Colonial First State Global Credit Income Fund', '', 'FM-49204','FM-49204','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30913' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30913','Colonial First State Multi-Asset Real Return Fund  Class A', '', 'FM-49204','FM-49204','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4371' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4371','Colonial First State Wholesale Australian Bond Fund', '', 'FM-49204','FM-49204','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4140' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4140','Colonial First State Wholesale Australian Share Fund', '', 'FM-49204','FM-49204','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-7293' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-7293','Colonial First State Wholesale Balanced Fund', '', 'FM-49204','FM-49204','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-7291' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-7291','Colonial First State Wholesale Cash Fund', '', 'FM-49204','FM-49204','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4148' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4148','Colonial First State Wholesale Conservative Fund', '', 'FM-49204','FM-49204','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-7296' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-7296','Colonial First State Wholesale Diversified Fixed Interest Fund', '', 'FM-49204','FM-49204','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4150' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4150','Colonial First State Wholesale Diversified Fund', '', 'FM-49204','FM-49204','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-21333' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-21333','Colonial First State Wholesale Equity Income Fund', '', 'FM-49204','FM-49204','Adrian Hoe','https://ap1.salesforce.com/a0L9000001Fo9tY')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4369' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4369','Colonial First State Wholesale Geared Share Fund', '', 'FM-49204','FM-49204','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14387' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14387','Colonial First State Wholesale Global Property Securities Fund', '', 'FM-49204','FM-49204','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lc3')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4159' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4159','Colonial First State Wholesale High Growth Fund', '', 'FM-49204','FM-49204','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4146' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4146','Colonial First State Wholesale Imputation Fund', '', 'FM-49204','FM-49204','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4163' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4163','Colonial First State Wholesale Property Securities Fund', '', 'FM-49204','FM-49204','Kevin Posser','https://ap1.salesforce.com/a0L9000001E0XIo')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-5081' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-5081','Colonial First State Wholesale Small Companies  Core', '', 'FM-49204','FM-49204','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-7294' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-7294','Colonial First State Wholesale Worldwide Leaders Fund', '', 'FM-49204','FM-49204','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-23116' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-23116','Realindex Aust Small Companies  Class A', '', 'FM-49204','FM-49204','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32232' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32232','Realindex Australian Dividend Plus Fund  Class A', '', 'FM-49204','FM-49204','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-22975' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-22975','Realindex Australian Share - Class A', '', 'FM-49204','FM-49204','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-22974' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-22974','Realindex Global Share Fund  Class A', '', 'FM-49204','FM-49204','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-22973' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-22973','Realindex Global Share Hedged Fund  Class A', '', 'FM-49204','FM-49204','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14975' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14975','FirstChoice Wholesale Fixed Interest Fund', '', 'FM-49204','FM-49204','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31243' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31243','FirstChoice WS Inv - FirstChoice Alternatives', '', 'FM-49204','FM-49204','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lQV')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14519' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14519','Colonial First State FirstChoice Wholesale Property Securities Fund', '', 'FM-49204','FM-49204','Kevin Posser','https://ap1.salesforce.com/a0L9000001E0XIo')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-19268' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-19268','Generation Wholesale Global Share Fund', '', 'FM-49204','FM-49204','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31798' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31798','Sanlam Managed Risk Multi-Index High Growth Fund  Class A', '', 'FM-49204','FM-49204','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30236' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30236','CommInsure Investment Growth Bond NC - Cash', '', 'FM-49205','FM-49205','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30237' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30237','CommInsure Investment Growth Bond NC - Global Fixed Interest', '', 'FM-49206','FM-49206','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-21171' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-21171','Concise Mid Cap Fund', '', 'FM-49206','FM-49206','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30238' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30238','CommInsure Investment Growth Bond NC - Global Property', '', 'FM-49207','FM-49207','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lc3')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'EF-2-16325' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'EF-2-16325','Contango Income Generator Limited', '', 'FM-49207','FM-49207','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30239' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30239','CommInsure Investment Growth Bond NC - Australian Shares', '', 'FM-49208','FM-49208','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32543' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32543','Cooper Investors Global Equities Fund (Hedged)', '', 'FM-49208','FM-49208','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32544' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32544','Cooper Investors Global Equities Fund (Unhedged)', '', 'FM-49208','FM-49208','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30240' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30240','CommInsure Investment Growth Bond NC - International Shares', '', 'FM-49209','FM-49209','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30241' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30241','CommInsure Investment Growth Bond NC - Conservative', '', 'FM-49210','FM-49210','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31601' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31601','Cromwell Phoenix Core Listed Property Fund', '', 'FM-49210','FM-49210','Kevin Posser','https://ap1.salesforce.com/a0L9000001E0XIo')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-19756' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-19756','Cromwell Phoenix Property Securities Fund', '', 'FM-49210','FM-49210','Kevin Posser','https://ap1.salesforce.com/a0L9000001E0XIo')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30242' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30242','CommInsure Investment Growth Bond NC - Diversified', '', 'FM-49211','FM-49211','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30243' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30243','CommInsure Investment Growth Bond NC - Balanced', '', 'FM-49212','FM-49212','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31698' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31698','DNR Capital Australian Equities High Conviction Fund', '', 'FM-49212','FM-49212','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-28628' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-28628','DNR Capital Australian Equities High Conviction Portfolio', '', 'FM-49212','FM-49212','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31635' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31635','DNR Capital Australian Equities Income Portfolio', '', 'FM-49212','FM-49212','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30244' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30244','CommInsure Investment Growth Bond NC - Growth', '', 'FM-49213','FM-49213','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-23819' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-23819','DDH Cash Fund  IDPS', '', 'FM-49213','FM-49213','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-23821' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-23821','Dimensional Australian Core Equity Trust', '', 'FM-49215','FM-49215','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31607' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31607','Dimensional Australian Core Imputation Trust', '', 'FM-49215','FM-49215','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-5757' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-5757','Dimensional Australian Large Company Trust', '', 'FM-49215','FM-49215','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-5297' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-5297','Dimensional Australian Small Company Trust', '', 'FM-49215','FM-49215','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-6216' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-6216','Dimensional Australian Value Trust', '', 'FM-49215','FM-49215','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-5760' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-5760','Dimensional Emerging Markets Trust', '', 'FM-49215','FM-49215','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2DZ2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-11834' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-11834','Dimensional Five-Year Diversified Fixed Interest Trust', '', 'FM-49215','FM-49215','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-27271' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-27271','Dimensional Global Bond Trust', '', 'FM-49215','FM-49215','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-23822' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-23822','Dimensional Global Core Equity Trust', '', 'FM-49215','FM-49215','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-5758' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-5758','Dimensional Global Large Company Trust', '', 'FM-49215','FM-49215','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-23823' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-23823','Dimensional Global Real Estate Trust Inc AUD', '', 'FM-49215','FM-49215','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lc3')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-5759' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-5759','Dimensional Global Small Company Trust', '', 'FM-49215','FM-49215','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-31982' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-31982','Dimensional Global Sustainability Trust Hedged AUD', '', 'FM-49215','FM-49215','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2GKH')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-31983' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-31983','Dimensional Global Sustainability Trust Unhedged AUD', '', 'FM-49215','FM-49215','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2GKH')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-6217' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-6217','Dimensional Global Value Trust', '', 'FM-49215','FM-49215','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-6215' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-6215','Dimensional Short Term Fixed Interest Trust', '', 'FM-49215','FM-49215','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-23820' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-23820','Dimensional Two-Year Diversified Fixed Interest', '', 'FM-49215','FM-49215','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30159' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30159','Dimensional World Allocation 50/50 Trust', '', 'FM-49215','FM-49215','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-27272' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-27272','Dimensional World Allocation 70/30 Trust', '', 'FM-49215','FM-49215','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30160' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30160','Dimensional World Equity Trust', '', 'FM-49215','FM-49215','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32234' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32234','Eley Griffiths Group Emerging Companies Fund', '', 'FM-49217','FM-49217','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-11353' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-11353','Eley Griffiths Group Small Companies Fund', '', 'FM-49217','FM-49217','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31149' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31149','Ellerston Australian Market Neutral Fund', '', 'FM-49218','FM-49218','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lQV')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32545' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32545','Elston Australian Equities  SMA Portfolio', '', 'FM-49219','FM-49219','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-31959' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-31959','AXA IM ACWI SmartBeta Equity Fund', '', 'FM-49220','FM-49220','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32164' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32164','Barrow Hanley Global Equity Trust', '', 'FM-49220','FM-49220','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31066' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31066','BNY Mellon Standish Global Bond Fund', '', 'FM-49220','FM-49220','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-7416' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-7416','C WorldWide Global Equity Trust', '', 'FM-49220','FM-49220','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31608' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31608','Colchester Global Government Bond Fund Class A', '', 'FM-49220','FM-49220','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-22743' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-22743','Premium Asia Fund', '', 'FM-49220','FM-49220','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2DZ2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-27161' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-27161','Premium Asia Income Fund', '', 'FM-49220','FM-49220','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14704' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14704','Premium China Fund', '', 'FM-49220','FM-49220','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2DZ2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-7630' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-7630','SG Hiscock Wholesale Property Fund', '', 'FM-49220','FM-49220','Kevin Posser','https://ap1.salesforce.com/a0L9000001E0XIo')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4189' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4189','SG Hiscock Wholesale Property Securities Fund', '', 'FM-49220','FM-49220','Kevin Posser','https://ap1.salesforce.com/a0L9000001E0XIo')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-11037' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-11037','SGH Emerging Companies Fund', '', 'FM-49220','FM-49220','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-22917' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-22917','SGH ICE', '', 'FM-49220','FM-49220','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14869' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14869','SGH LaSalle Global Listed Property Securities Fund', '', 'FM-49220','FM-49220','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lc3')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31292' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31292','SGH LaSalle Global Property-Rich Fund', '', 'FM-49220','FM-49220','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lc3')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-21192' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-21192','SGH Property Income Fund', '', 'FM-49220','FM-49220','Kevin Posser','https://ap1.salesforce.com/a0L9000001E0XIo')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32527' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32527','ETFS Morningstar Global Technology ETF', '', 'FM-49221','FM-49221','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-19018' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-19018','Fiducian India Fund', '', 'FM-49225','FM-49225','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2DZ2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-21348' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-21348','Fidelity Asia Fund', '', 'FM-49226','FM-49226','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2DZ2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14673' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14673','Fidelity Australian Equities Fund', '', 'FM-49226','FM-49226','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-28885' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-28885','Fidelity Australian Opportunities Fund', '', 'FM-49226','FM-49226','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14748' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14748','Fidelity China Fund', '', 'FM-49226','FM-49226','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2DZ2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30567' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30567','Fidelity Future Leaders Fund', '', 'FM-49226','FM-49226','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-28359' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-28359','Fidelity Global Demographics Fund', '', 'FM-49226','FM-49226','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31928' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31928','Fidelity Global Emerging Markets Fund', '', 'FM-49226','FM-49226','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2DZ2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-9003' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-9003','Fidelity Global Equities Fund', '', 'FM-49226','FM-49226','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-18556' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-18556','Fidelity Global Equities Fund (Hedged)', '', 'FM-49226','FM-49226','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14749' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14749','Fidelity India Fund', '', 'FM-49226','FM-49226','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2DZ2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-19791' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-19791','Folkestone Maxim Property Securities Fund', '', 'FM-49227','FM-49227','Kevin Posser','https://ap1.salesforce.com/a0L9000001E0XIo')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32300' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32300','Forager Australian Shares Fund', '', 'FM-49228','FM-49228','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30249' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30249','Forager International Shares Fund', '', 'FM-49228','FM-49228','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31503' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31503','Franklin Australian Absolute Return Bond Fund  W Class', '', 'FM-49230','FM-49230','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-21353' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-21353','Franklin Global Growth Fund', '', 'FM-49230','FM-49230','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-27295' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-27295','Franklin Templeton Australian Equity Fund  W Class', '', 'FM-49230','FM-49230','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-28592' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-28592','Franklin Templeton Global Aggregate Bond Fund', '', 'FM-49230','FM-49230','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-23851' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-23851','Franklin Templeton Multisector Bond  W Class', '', 'FM-49230','FM-49230','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-28555' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-28555','Templeton Global Bond Plus Fund  W Class', '', 'FM-49230','FM-49230','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14299' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14299','Templeton Global Equity Fund', '', 'FM-49230','FM-49230','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30738' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30738','Freehold A-REITs & Listed Infrastructure Fund', '', 'FM-49231','FM-49231','Kevin Posser','https://ap1.salesforce.com/a0L9000001E0XIo')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-7860' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-7860','Yarra Australian Equities Fund', '', 'FM-49234','FM-49234','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-18870' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-18870','Yarra Australian Real Assets Securities Fund', '', 'FM-49234','FM-49234','Kevin Posser','https://ap1.salesforce.com/a0L9000001E0XIo')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4221' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4221','Yarra Emerging Leaders Fund', '', 'FM-49234','FM-49234','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-13093' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-13093','Yarra Enhanced Income Fund', '', 'FM-49234','FM-49234','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-7861' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-7861','Yarra Income Plus Fund ', '', 'FM-49234','FM-49234','Jude McDonnell','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-25134' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-25134','Yarra Premier Australian Equities Fund', '', 'FM-49234','FM-49234','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-21067' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-21067','Grant Samuel Epoch Global Equity Shareholder Yield (Hedged) Fund', '', 'FM-49236','FM-49236','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-21066' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-21066','Grant Samuel Epoch Global Equity Shareholder Yield (Unhedged) Fund', '', 'FM-49236','FM-49236','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-25187' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-25187','Grant Samuel Tribeca Alpha Plus Fund', '', 'FM-49236','FM-49236','Adrian  Hoe','https://ap1.salesforce.com/a0L9000001Fo9tY?srPos=0&srKp=a0N')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-23233' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-23233','Grant Samuel Tribeca Australian Smaller Companies Fund', '', 'FM-49236','FM-49236','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-28627' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-28627','Payden Global Income Opportunities Fund A', '', 'FM-49236','FM-49236','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-6656' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-6656','Janus Henderson Australian Equity Fund', '', 'FM-49237','FM-49237','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-6654' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-6654','Janus Henderson Australian Fixed Interest Fund', '', 'FM-49237','FM-49237','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-6653' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-6653','Janus Henderson Cash Enhanced Fund', '', 'FM-49237','FM-49237','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31625' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31625','Janus Henderson Global Fixed Interest Total Return Fund', '', 'FM-49237','FM-49237','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-28219' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-28219','Janus Henderson Global Natural Resources Fund', '', 'FM-49237','FM-49237','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-28626' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-28626','Janus Henderson Income Focused Fund', '', 'FM-49237','FM-49237','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-21393' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-21393','Janus Henderson Tactical Income Fund', '', 'FM-49237','FM-49237','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32120' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32120','Hostplus Balanced Option', '', 'FM-49238','FM-49238','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32121' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32121','Hostplus Indexed Balanced Option', '', 'FM-49238','FM-49238','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32275' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32275','India Avenue Equity Fund  Wholesale Class', '', 'FM-49241','FM-49241','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2DZ2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31158' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31158','ING DIRECT Living Super Balanced Option', '', 'FM-49243','FM-49243','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31159' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31159','ING DIRECT Living Super Growth Option', '', 'FM-49243','FM-49243','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31160' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31160','ING DIRECT Living Super High Growth Option', '', 'FM-49243','FM-49243','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4214' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4214','Invesco Wholesale Global Opportunities Fund  Hedged  Class A', '', 'FM-49247','FM-49247','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4216' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4216','Invesco Wholesale Global Opportunities Fund  Unhedged', '', 'FM-49247','FM-49247','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31589' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31589','INVESCO Wholesale Global Targeted Returns Fund  Class A', '', 'FM-49247','FM-49247','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lQV')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-9280' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-9280','Invesco Wholesale Senior Secured Income Fund', '', 'FM-49247','FM-49247','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-11014' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-11014','Investors Mutual All Industrials Share Fund', '', 'FM-49248','FM-49248','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-8002' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-8002','Investors Mutual Australian Share Fund', '', 'FM-49248','FM-49248','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-8757' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-8757','Investors Mutual Australian Smaller Companies Fund', '', 'FM-49248','FM-49248','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-26368' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-26368','Investors Mutual Concentrated Australian Share Fund', '', 'FM-49248','FM-49248','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-23926' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-23926','Investors Mutual Equity Income Fund', '', 'FM-49248','FM-49248','Adrian Hoe','https://ap1.salesforce.com/a0L9000001Fo9tY')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-11407' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-11407','Investors Mutual Wholesale Future Leaders Fund', '', 'FM-49248','FM-49248','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31310' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31310','IOOF Balanced Investor Trust', '', 'FM-49249','FM-49249','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-13788' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-13788','IOOF Cash Management Trust', '', 'FM-49249','FM-49249','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-20945' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-20945','IOOF MultiMix Australian Shares Trust', '', 'FM-49249','FM-49249','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-20946' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-20946','IOOF MultiMix Balanced Growth', '', 'FM-49249','FM-49249','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-20947' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-20947','IOOF MultiMix Capital Stable', '', 'FM-49249','FM-49249','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-20776' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-20776','IOOF MultiMix Cash Enhanced Trust', '', 'FM-49249','FM-49249','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-19618' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-19618','IOOF MultiMix Conservative', '', 'FM-49249','FM-49249','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-20439' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-20439','IOOF MultiMix Diversified Fixed Interest Trust', '', 'FM-49249','FM-49249','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-20948' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-20948','IOOF MultiMix Growth', '', 'FM-49249','FM-49249','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-20949' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-20949','IOOF MultiMix International Shares Trust', '', 'FM-49249','FM-49249','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-13790' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-13790','IOOF MultiMix Moderate', '', 'FM-49249','FM-49249','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32178' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32178','IOOF MultiSeries 30', '', 'FM-49249','FM-49249','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32179' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32179','IOOF MultiSeries 50', '', 'FM-49249','FM-49249','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-20944' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-20944','IOOF MultiSeries 70', '', 'FM-49249','FM-49249','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32180' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32180','IOOF MultiSeries 90', '', 'FM-49249','FM-49249','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-23826' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-23826','Strategic Australian Equity Fund', '', 'FM-49249','FM-49249','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-27772' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-27772','Strategic Fixed Interest Fund', '', 'FM-49249','FM-49249','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-23824' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-23824','Strategic Global Property Fund', '', 'FM-49249','FM-49249','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lc3')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-23825' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-23825','Strategic International Equity Fund', '', 'FM-49249','FM-49249','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-19528' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-19528','Ironbark Copper Rock Emerging Markets Opportunities Fund ', '', 'FM-49250','FM-49250','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2DZ2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-19527' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-19527','Ironbark Copper Rock Global All Cap Share Fund', '', 'FM-49250','FM-49250','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-26171' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-26171','Ironbark Gavekal Asian Opportunities Fund', '', 'FM-49250','FM-49250','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2DZ2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14279' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14279','Ironbark Global (ex-Australia) Property Securities Fund', '', 'FM-49250','FM-49250','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lc3')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4176' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4176','Ironbark Global Diversified Alternatives Fund', '', 'FM-49250','FM-49250','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lQV')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-19784' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-19784','Ironbark Global Property Securities Fund', '', 'FM-49250','FM-49250','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lc3')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-15133' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-15133','Ironbark Karara Australian Share Fund', '', 'FM-49250','FM-49250','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-25195' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-25195','Ironbark Karara Australian Small Companies Fund', '', 'FM-49250','FM-49250','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4183' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4183','Ironbark LHP Diversified Investments Fund', '', 'FM-49250','FM-49250','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lQV')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4185' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4185','Ironbark LHP Global Long/Short Fund (Wholesale Class)', '', 'FM-49250','FM-49250','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lQV')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-15221' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-15221','Ironbark Royal London Concentrated Global Share Fund', '', 'FM-49250','FM-49250','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31390' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31390','JBWere Growth Model Portfolio ', '', 'FM-49251','FM-49251','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31391' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31391','JBWere Income Model Portfolio', '', 'FM-49251','FM-49251','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31393' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31393','JBWere Industrials Model Portfolio', '', 'FM-49251','FM-49251','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31392' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31392','JBWere Leaders Model Portfolio', '', 'FM-49251','FM-49251','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30735' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30735','JBWere Listed Fixed Income Portfolio', '', 'FM-49251','FM-49251','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31395' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31395','JBWere Listed Multi Strategy Model Portfolio', '', 'FM-49251','FM-49251','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30949' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30949','JPMorgan Emerging Markets Opportunities Fund', '', 'FM-49252','FM-49252','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2DZ2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31805' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31805','JPMorgan Global Bond Fund', '', 'FM-49252','FM-49252','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30948' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30948','JPMorgan Global Bond Opportunities Fund', '', 'FM-49252','FM-49252','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32050' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32050','JPMorgan Global Macro Opportunities Fund', '', 'FM-49252','FM-49252','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lQV')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31801' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31801','JPMorgan Global Research Enhanced Index Equity Fund', '', 'FM-49252','FM-49252','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31802' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31802','JPMorgan Global Research Enhanced Index Equity Fund (Hedged)', '', 'FM-49252','FM-49252','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30947' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30947','JPMorgan Global Strategic Bond Fund', '', 'FM-49252','FM-49252','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31918' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31918','JPMorgan Systematic Alpha Fund', '', 'FM-49252','FM-49252','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lQV')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-13873' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-13873','K2 Asian Absolute Return Fund', '', 'FM-49253','FM-49253','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-13874' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-13874','K2 Australian Absolute Return Fund', '', 'FM-49253','FM-49253','Adrian  Hoe','https://ap1.salesforce.com/a0L9000001Fo9tY?srPos=0&srKp=a0N')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-21500' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-21500','K2 Select International Absolute Return Fund', '', 'FM-49253','FM-49253','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32215' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32215','L1 Capital Long Short Fund Retail Class', '', 'FM-49254','FM-49254','Adrian  Hoe','https://ap1.salesforce.com/a0L9000001Fo9tY?srPos=0&srKp=a0N')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-24034' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-24034','La Trobe Australian Credit Fund 12 Month Term Account', '', 'FM-49255','FM-49255','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30191' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30191','Lazard Australian Diversified Income Fund', '', 'FM-49256','FM-49256','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-13770' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-13770','Lazard Australian Equity Fund (W Class)', '', 'FM-49256','FM-49256','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-9147' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-9147','Lazard Emerging Markets Equity Fund', '', 'FM-49256','FM-49256','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2DZ2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30147' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30147','Lazard Emerging Markets Total Return Debt Fund', '', 'FM-49256','FM-49256','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32191' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32191','Lazard Global Equity Advantage Plus Fund  W Class', '', 'FM-49256','FM-49256','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31764' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31764','Lazard Global Equity Franchise Fund', '', 'FM-49256','FM-49256','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-22099' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-22099','Lazard Global Listed Infrastructure Fund', '', 'FM-49256','FM-49256','Sam Morris','https://ap1.salesforce.com/a0L9000001E0y4g')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-13771' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-13771','Lazard Global Small Cap Fund (W Class)', '', 'FM-49256','FM-49256','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-13772' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-13772','Lazard Select Australian Equity Fund (W Class)', '', 'FM-49256','FM-49256','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-24861' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-24861','Legg Mason Brandywine Global Opportunistic Fixed Income Trust (Class A)', '', 'FM-49257','FM-49257','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-7488' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-7488','Legg Mason Martin Currie Core Equity Trust', '', 'FM-49257','FM-49257','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-7654' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-7654','Legg Mason Martin Currie Diversified Growth Trust', '', 'FM-49257','FM-49257','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31327' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31327','Legg Mason Martin Currie Diversified Income Trust ', '', 'FM-49257','FM-49257','Jude McDonnell','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-27154' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-27154','Legg Mason Martin Currie Equity Income Trust (Class A)', '', 'FM-49257','FM-49257','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32576' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32576','Legg Mason Martin Currie Ethical Income Fund', '', 'FM-49257','FM-49257','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2GKH')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32170' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32170','Legg Mason Martin Currie Ethical Values with Income Fund', '', 'FM-49257','FM-49257','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2GKH')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-6601' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-6601','Legg Mason Martin Currie Property Securities Trust', '', 'FM-49257','FM-49257','Kevin Posser','https://ap1.salesforce.com/a0L9000001E0XIo')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-26696' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-26696','Legg Mason Martin Currie Real Income Fund Class A Units', '', 'FM-49257','FM-49257','Kevin Posser','https://ap1.salesforce.com/a0L9000001E0XIo')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-21553' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-21553','Legg Mason Martin Currie Select Opportunities Fund - Class A', '', 'FM-49257','FM-49257','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-7657' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-7657','Legg Mason Western Asset Australian Bond Trust  Class A', '', 'FM-49257','FM-49257','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-28353' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-28353','Analytic Global Managed Volatility Fund', '', 'FM-49262','FM-49262','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-18956' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-18956','Arrowstreet Global Equity Fund', '', 'FM-49262','FM-49262','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-7062' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-7062','Arrowstreet Global Equity Fund (Hedged)', '', 'FM-49262','FM-49262','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-21250' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-21250','IFP Global Franchise Fund', '', 'FM-49262','FM-49262','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-26255' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-26255','IFP Global Franchise Fund (Hedged)', '', 'FM-49262','FM-49262','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32528' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32528','IPM Global Macro Fund', '', 'FM-49262','FM-49262','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lQV')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-26147' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-26147','Macquarie Asia New Stars No.1 Fund', '', 'FM-49262','FM-49262','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2DZ2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-24105' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-24105','Macquarie Australia Plus Fund', '', 'FM-49262','FM-49262','Adrian  Hoe','https://ap1.salesforce.com/a0L9000001Fo9tY?srPos=0&srKp=a0N')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4384' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4384','Macquarie Australian Fixed Interest Fund', '', 'FM-49262','FM-49262','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-15196' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-15196','Macquarie Australian Small Companies Fund', '', 'FM-49262','FM-49262','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-13005' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-13005','Macquarie Diversified Fixed Interest Fund', '', 'FM-49262','FM-49262','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30516' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30516','Macquarie Dividend Run-Up Fund', '', 'FM-49262','FM-49262','Adrian Hoe','https://ap1.salesforce.com/a0L9000001Fo9tY')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-19383' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-19383','Macquarie High Conviction Fund', '', 'FM-49262','FM-49262','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-13779' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-13779','Macquarie Income Opportunities Fund', '', 'FM-49262','FM-49262','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-18845' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-18845','Macquarie International Infrastructure Securities Fund (Hedged)', '', 'FM-49262','FM-49262','Sam Morris','https://ap1.salesforce.com/a0L9000001E0y4g')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30943' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30943','Macquarie International Infrastructure Securities Fund (Unhedged)', '', 'FM-49262','FM-49262','Sam Morris','https://ap1.salesforce.com/a0L9000001E0y4g')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32526' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32526','Macquarie Pure Alpha Fund', '', 'FM-49262','FM-49262','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lQV')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32529' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32529','P/E Global FX Alpha Fund', '', 'FM-49262','FM-49262','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lQV')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31513' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31513','Polaris Global Equity Fund', '', 'FM-49262','FM-49262','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-24116' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-24116','Premium Asia Property Fund', '', 'FM-49262','FM-49262','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lc3')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-26690' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-26690','Walter Scott Emerging Markets Fund', '', 'FM-49262','FM-49262','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2DZ2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14765' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14765','Walter Scott Global Equity Fund', '', 'FM-49262','FM-49262','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-19396' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-19396','Walter Scott Global Equity Fund (Hedged)', '', 'FM-49262','FM-49262','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-18872' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-18872','Winton Global Alpha Fund', '', 'FM-49262','FM-49262','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lQV')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30760' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30760','MPPM Core Australian Equity', '', 'FM-49263','FM-49263','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30761' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30761','MPPM Growth Australian Equity', '', 'FM-49263','FM-49263','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31116' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31116','MPPM Growth ex 20 Portfolio', '', 'FM-49263','FM-49263','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30762' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30762','MPPM Income Australian Equity', '', 'FM-49263','FM-49263','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'EF-2-31600' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'EF-2-31600','Magellan Global Equities Fund', '', 'FM-49264','FM-49264','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32193' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32193','Magellan Global Equities Fund (Currency Hedged) (Managed Fund)', '', 'FM-49264','FM-49264','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-19370' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-19370','Magellan Global Fund', '', 'FM-49264','FM-49264','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30778' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30778','Magellan Global Fund (Hedged)', '', 'FM-49264','FM-49264','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32614' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32614','Magellan Global Trust', '', 'FM-49264','FM-49264','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30732' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30732','Magellan High Conviction Fund', '', 'FM-49264','FM-49264','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-18942' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-18942','Magellan Infrastructure Fund', '', 'FM-49264','FM-49264','Sam Morris','https://ap1.salesforce.com/a0L9000001E0y4g')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32192' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32192','Magellan Infrastructure Fund (Currency Hedged) (Managed Fund)', '', 'FM-49264','FM-49264','Sam Morris','https://ap1.salesforce.com/a0L9000001E0y4g')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30895' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30895','Magellan Infrastructure Fund (Unhedged)', '', 'FM-49264','FM-49264','Sam Morris','https://ap1.salesforce.com/a0L9000001E0y4g')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-21462' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-21462','Man AHL Alpha', '', 'FM-49265','FM-49265','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lQV')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30165' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30165','Man Diversified Alternatives', '', 'FM-49265','FM-49265','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lQV')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4079' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4079','Maple-Brown Abbott Australian Share Fund  Wholesale', '', 'FM-49266','FM-49266','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-8877' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-8877','Maple-Brown Abbott Diversified Investment Trust', '', 'FM-49266','FM-49266','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31563' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31563','Maple-Brown Abbott Global Listed Infrastructure Fund', '', 'FM-49266','FM-49266','Sam Morris','https://ap1.salesforce.com/a0L9000001E0y4g')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-31954' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-31954','Maple-Brown Abbott Global Listed Infrastructure Fund - Hedged', '', 'FM-49266','FM-49266','Sam Morris','https://ap1.salesforce.com/a0L9000001E0y4g')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'EF-2-31761' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'EF-2-31761','VanEck Vectors Morningstar Wide Moat ETF', '', 'FM-49267','FM-49267','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-27396' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-27396','Martin Currie Global Emerging Markets Fund', '', 'FM-49268','FM-49268','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2DZ2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32283' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32283','Mason Stevens Credit Fund', '', 'FM-49269','FM-49269','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31800' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31800','Mercer Australian Shares for Tax Exempt Investors', '', 'FM-49271','FM-49271','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-25194' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-25194','Mercer Australian Small Companies Fund', '', 'FM-49271','FM-49271','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-27866' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-27866','Mercer Conservative Growth Fund', '', 'FM-49271','FM-49271','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-27867' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-27867','Mercer Defensive Fund', '', 'FM-49271','FM-49271','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-27870' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-27870','Mercer Global Small Companies Shares Fund', '', 'FM-49271','FM-49271','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-20781' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-20781','Mercer Growth Fund', '', 'FM-49271','FM-49271','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-20763' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-20763','Mercer High Growth Fund', '', 'FM-49271','FM-49271','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-18741' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-18741','Mercer Income Plus Fund', '', 'FM-49271','FM-49271','Jude McDonnell','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-27879' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-27879','Mercer Listed Infrastructure Fund', '', 'FM-49271','FM-49271','Sam Morris','https://ap1.salesforce.com/a0L9000001E0y4g')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-20764' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-20764','Mercer Moderate Growth Fund', '', 'FM-49271','FM-49271','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14785' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14785','Mercer Select Growth Fund', '', 'FM-49271','FM-49271','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-28561' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-28561','MFS Concentrated Global Equity Trust (Wholesale)', '', 'FM-49272','FM-49272','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14827' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14827','MFS Fully Hedged Global Equity Trust', '', 'FM-49272','FM-49272','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-7731' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-7731','MFS Global Equity Trust', '', 'FM-49272','FM-49272','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32185' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32185','Montgomery Global Fund', '', 'FM-49278','FM-49278','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30248' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30248','The Montgomery Fund', '', 'FM-49278','FM-49278','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-23743' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-23743','Morningstar  High Growth Fund', '', 'FM-49279','FM-49279','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-13692' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-13692','Morningstar Australian Shares Fund', '', 'FM-49279','FM-49279','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-23929' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-23929','Morningstar Balanced Fund', '', 'FM-49279','FM-49279','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-13693' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-13693','Morningstar Balanced Real Return Fund', '', 'FM-49279','FM-49279','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-27152' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-27152','Morningstar Conservative Fund', '', 'FM-49279','FM-49279','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-13690' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-13690','Morningstar Conservative Real Return Fund', '', 'FM-49279','FM-49279','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-23939' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-23939','Morningstar Diversified Alternatives Fund', '', 'FM-49279','FM-49279','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lQV')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-23932' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-23932','Morningstar Growth Fund', '', 'FM-49279','FM-49279','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-13691' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-13691','Morningstar Growth Real Return Fund', '', 'FM-49279','FM-49279','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14464' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14464','Morningstar High Growth Real Return Fund', '', 'FM-49279','FM-49279','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-23937' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-23937','Morningstar International Bonds (Hedged) Fund', '', 'FM-49279','FM-49279','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-28949' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-28949','Morningstar International Shares (Hedged) Fund', '', 'FM-49279','FM-49279','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-23934' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-23934','Morningstar International Shares (Unhedged) Fund', '', 'FM-49279','FM-49279','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-23931' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-23931','Morningstar Moderate Fund', '', 'FM-49279','FM-49279','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14463' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14463','Morningstar Multi Asset Real Return Fund', '', 'FM-49279','FM-49279','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-28296' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-28296','Morphic Global Opportunities Fund', '', 'FM-49280','FM-49280','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32188' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32188','Munro Global Growth Fund', '', 'FM-49282','FM-49282','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-26245' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-26245','MLC Index Plus Balanced Portfolio', '', 'FM-49284','FM-49284','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-26246' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-26246','MLC Index Plus Conservative Growth Portfolio', '', 'FM-49284','FM-49284','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-26247' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-26247','MLC Index Plus Growth Portfolio', '', 'FM-49284','FM-49284','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-8776' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-8776','MLC Wholesale Australian Share Fund', '', 'FM-49284','FM-49284','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-19513' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-19513','MLC Wholesale Diversified Debt Fund Class A', '', 'FM-49284','FM-49284','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-18652' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-18652','MLC Wholesale Global Property Fund', '', 'FM-49284','FM-49284','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lc3')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14958' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14958','MLC Wholesale Global Share Fund', '', 'FM-49284','FM-49284','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-18757' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-18757','MLC Wholesale Hedged Global Share Fund  Class A', '', 'FM-49284','FM-49284','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-18626' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-18626','MLC Wholesale Horizon 1 Bond Portfolio', '', 'FM-49284','FM-49284','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-18623' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-18623','MLC Wholesale Horizon 2 Income Portfolio', '', 'FM-49284','FM-49284','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-11262' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-11262','MLC Wholesale Horizon 3 Conserv Growth Portfolio', '', 'FM-49284','FM-49284','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4280' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4280','MLC Wholesale Horizon 4 Balanced Portfolio', '', 'FM-49284','FM-49284','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4284' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4284','MLC Wholesale Horizon 5 Growth Portfolio', '', 'FM-49284','FM-49284','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14224' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14224','MLC Wholesale Horizon 6 Share Fund', '', 'FM-49284','FM-49284','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14480' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14480','MLC Wholesale Horizon 7 Accelerated Growth Portfolio', '', 'FM-49284','FM-49284','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4288' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4288','MLC Wholesale IncomeBuilder', '', 'FM-49284','FM-49284','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32591' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32591','MLC Wholesale Index Plus Balanced Portfolio', '', 'FM-49284','FM-49284','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32590' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32590','MLC Wholesale Index Plus Conservative Growth Portfolio', '', 'FM-49284','FM-49284','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32589' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32589','MLC Wholesale Index Plus Growth Portfolio', '', 'FM-49284','FM-49284','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-15185' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-15185','MLC Wholesale Inflation Plus  Assertive Portfolio A', '', 'FM-49284','FM-49284','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30590' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30590','MLC Wholesale Inflation Plus  Conservative Portfolio', '', 'FM-49284','FM-49284','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30591' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30591','MLC Wholesale Inflation Plus  Moderate Portfolio', '', 'FM-49284','FM-49284','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4269' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4269','MLC Wholesale Property Securities Fund', '', 'FM-49284','FM-49284','Kevin Posser','https://ap1.salesforce.com/a0L9000001E0XIo')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-28130' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-28130','Altrinsic Global Equities Trust', '', 'FM-49284','FM-49284','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-10793' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-10793','Antares Australian Equities Fund', '', 'FM-49284','FM-49284','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-26258' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-26258','Antares Core Opportunities Model Portfolio', '', 'FM-49284','FM-49284','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-22751' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-22751','Antares Dividend Builder', '', 'FM-49284','FM-49284','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-26257' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-26257','Antares Dividend Builder Model Portfolio', '', 'FM-49284','FM-49284','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-12584' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-12584','Antares Elite Opportunities Fund', '', 'FM-49284','FM-49284','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31769' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31769','Antares ex 20 Model Portfolio', '', 'FM-49284','FM-49284','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-6714' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-6714','Antares High Growth Shares Fund', '', 'FM-49284','FM-49284','Adrian  Hoe','https://ap1.salesforce.com/a0L9000001Fo9tY?srPos=0&srKp=a0N')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30763' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30763','Antares Income Fund', '', 'FM-49284','FM-49284','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-5114' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-5114','Antares Listed Property Fund', '', 'FM-49284','FM-49284','Kevin Posser','https://ap1.salesforce.com/a0L9000001E0XIo')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31575' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31575','Antares Listed Property Model Portfolio', '', 'FM-49284','FM-49284','Kevin Posser','https://ap1.salesforce.com/a0L9000001E0XIo')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-24135' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-24135','PIC Wholesale 0/100 Portfolio', '', 'FM-49284','FM-49284','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-24140' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-24140','PIC Wholesale 100/0 Portfolio', '', 'FM-49284','FM-49284','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-27352' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-27352','PIC Wholesale 130/0 Portfolio', '', 'FM-49284','FM-49284','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-24136' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-24136','PIC Wholesale 30/70 Portfolio', '', 'FM-49284','FM-49284','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-24137' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-24137','PIC Wholesale 50/50 Portfolio', '', 'FM-49284','FM-49284','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-24138' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-24138','PIC Wholesale 70/30 Portfolio', '', 'FM-49284','FM-49284','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-24139' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-24139','PIC Wholesale 85/15 Portfolio', '', 'FM-49284','FM-49284','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32588' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32588','PIC Wholesale Index Plus Balanced Portfolio', '', 'FM-49284','FM-49284','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32587' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32587','PIC Wholesale Index Plus Conservative Growth Portfolio', '', 'FM-49284','FM-49284','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32586' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32586','PIC Wholesale Index Plus Growth Portfolio', '', 'FM-49284','FM-49284','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31808' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31808','PIC Wholesale Inflation Plus  Assertive Portfolio', '', 'FM-49284','FM-49284','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-24142' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-24142','PIC Wholesale Inflation Plus  Conservative Portfolio', '', 'FM-49284','FM-49284','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31807' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31807','PIC Wholesale Inflation Plus  Moderate Portfolio', '', 'FM-49284','FM-49284','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14900' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14900','Pre-Select Australian Equity Fund', '', 'FM-49284','FM-49284','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14901' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14901','Pre-Select Balanced Fund', '', 'FM-49284','FM-49284','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14902' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14902','Pre-Select Conservative Fund', '', 'FM-49284','FM-49284','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14903' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14903','Pre-Select Growth Fund', '', 'FM-49284','FM-49284','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14905' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14905','Pre-Select High Growth Fund', '', 'FM-49284','FM-49284','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14904' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14904','Pre-Select International Equity Fund', '', 'FM-49284','FM-49284','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30560' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30560','Presima Global Property Securities Concentrated Fund', '', 'FM-49284','FM-49284','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lc3')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31189' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31189','Neuberger Berman Absolute Return Multi Strategy Trust', '', 'FM-49286','FM-49286','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lQV')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-13899' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-13899','Nikko AM Australian Bond Fund', '', 'FM-49288','FM-49288','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-5621' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-5621','Nikko AM Global Share Fund', '', 'FM-49288','FM-49288','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-18455' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-18455','Nikko AM New Asia Fund', '', 'FM-49288','FM-49288','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2DZ2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30023' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30023','Nikko AM-Tyndall Australian Share Concentrated Fund', '', 'FM-49288','FM-49288','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-20876' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-20876','Nikko AM-Tyndall Australian Share Income Fund', '', 'FM-49288','FM-49288','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-9034' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-9034','Nikko AM-Tyndall Australian Share Wholesale Fund', '', 'FM-49288','FM-49288','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-13018' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-13018','OC Dynamic Equity Fund', '', 'FM-49290','FM-49290','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-23540' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-23540','OC Micro-Cap Fund', '', 'FM-49290','FM-49290','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-13017' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-13017','OC Premium Small Companies Fund', '', 'FM-49290','FM-49290','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-26414' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-26414','OA Frontier IP  OnePath Conservative Trust', '', 'FM-49291','FM-49291','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-26420' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-26420','OA Frontier IP-OnePath Global Shares Trust', '', 'FM-49291','FM-49291','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-5019' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-5019','OnePath Blue Chip Imputation Trust', '', 'FM-49291','FM-49291','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-26419' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-26419','OnePath Global Property Securities Trust', '', 'FM-49291','FM-49291','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lc3')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-26435' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-26435','OnePath OptiMix Global Emerging Markets Share Trust', '', 'FM-49291','FM-49291','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2DZ2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14559' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14559','OnePath Tax Effective Income Trust Wholesale Units', '', 'FM-49291','FM-49291','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4380' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4380','OnePath Wholesale Australian Share Trust', '', 'FM-49291','FM-49291','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4201' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4201','OnePath Wholesale Balanced Trust', '', 'FM-49291','FM-49291','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4208' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4208','OnePath Wholesale Capital Stable Trust', '', 'FM-49291','FM-49291','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4719' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4719','OnePath Wholesale Diversified Fixed Interest Trust', '', 'FM-49291','FM-49291','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-11564' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-11564','OnePath Wholesale Emerging Companies Trust', '', 'FM-49291','FM-49291','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-20817' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-20817','OnePath Wholesale Geared Australian Shares Index Trust  Class B Units', '', 'FM-49291','FM-49291','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-5343' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-5343','OnePath Wholesale Global Emerging Markets Share Trust', '', 'FM-49291','FM-49291','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2DZ2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-5005' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-5005','OnePath Wholesale High Growth Trust', '', 'FM-49291','FM-49291','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4197' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4197','OnePath Wholesale Managed Growth Trust', '', 'FM-49291','FM-49291','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-9141' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-9141','OnePath Wholesale Property Securities Trust', '', 'FM-49291','FM-49291','Kevin Posser','https://ap1.salesforce.com/a0L9000001E0XIo')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4715' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4715','OnePath Wholesale Select Leaders Trust', '', 'FM-49291','FM-49291','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4655' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4655','OnePath Wholesale Sustainable Investments Australian Share Trust', '', 'FM-49291','FM-49291','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2GKH')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14039' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14039','OptiMix Wholesale Australian Share Trust  Class A', '', 'FM-49291','FM-49291','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14040' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14040','OptiMix Wholesale Balanced Trust  Class A', '', 'FM-49291','FM-49291','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14041' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14041','OptiMix Wholesale Conservative Trust  Class A', '', 'FM-49291','FM-49291','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14043' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14043','OptiMix Wholesale Global Shares Trust  Class A', '', 'FM-49291','FM-49291','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14044' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14044','OptiMix Wholesale Global Smaller Companies Share Trust  Class A', '', 'FM-49291','FM-49291','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14045' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14045','OptiMix Wholesale Growth Trust  Class A', '', 'FM-49291','FM-49291','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14046' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14046','OptiMix Wholesale High Growth Trust  Class A', '', 'FM-49291','FM-49291','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14047' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14047','OptiMix Wholesale Moderate Trust  Class A', '', 'FM-49291','FM-49291','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-31947' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-31947','Orbis Global Equity Fund  Australia Registered Retail', '', 'FM-49292','FM-49292','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31514' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31514','Pan Tribal Global Equity Fund', '', 'FM-49295','FM-49295','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-28558' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-28558','Paradice Global Small Mid Cap Fund', '', 'FM-49296','FM-49296','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32226' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32226','Paradice Mid Cap Equities Fund', '', 'FM-49296','FM-49296','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31693' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31693','Partners Group Global Multi-Asset Fund', '', 'FM-49298','FM-49298','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lQV')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32463' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32463','Partners Group Global Real Estate Fund (AUD)', '', 'FM-49298','FM-49298','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lQV')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-28877' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-28877','Partners Group Global Value Fund (AUD)  Wholesale', '', 'FM-49298','FM-49298','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lQV')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-26608' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-26608','Pengana Absolute Return Asia Pacific Fund', '', 'FM-49299','FM-49299','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lQV')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-26620' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-26620','Pengana Australian Equities Fund', '', 'FM-49299','FM-49299','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14333' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14333','Pengana Emerging Companies Fund', '', 'FM-49299','FM-49299','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31705' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31705','Pengana Global Small Companies Fund', '', 'FM-49299','FM-49299','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31927' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31927','Pengana PanAgora Absolute Return Global Equities Fund', '', 'FM-49299','FM-49299','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lQV')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32596' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32596','Daintree Core Income Trust', '', 'FM-49300','FM-49300','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32531' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32531','Perennial Value Microcap Opportunities Trust', '', 'FM-49300','FM-49300','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-15078' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-15078','Perennial Value Shares For Income Trust', '', 'FM-49300','FM-49300','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4769' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4769','Perennial Value Shares Wholesale Trust', '', 'FM-49300','FM-49300','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-20967' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-20967','Perennial Value Smaller Companies Trust', '', 'FM-49300','FM-49300','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31135' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31135','Perennial Value Wealth Defender Australian Shares Trust', '', 'FM-49300','FM-49300','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'EF-2-31501' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'EF-2-31501','Wealth Defender Equities Limited', '', 'FM-49300','FM-49300','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31591' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31591','BMO Pyrford Global Absolute Return', '', 'FM-49301','FM-49301','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31109' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31109','Perpetual Direct Equity Alpha SMA', '', 'FM-49301','FM-49301','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-28284' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-28284','Perpetual Diversified Real Return Fund', '', 'FM-49301','FM-49301','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-19682' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-19682','Perpetual Exact Market Cash Fund', '', 'FM-49301','FM-49301','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32284' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32284','Perpetual Wholesale Active Fixed Interest Fund', '', 'FM-49301','FM-49301','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-7010' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-7010','Perpetual Wholesale Australian Share Fund', '', 'FM-49301','FM-49301','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4315' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4315','Perpetual Wholesale Balanced Growth Fund', '', 'FM-49301','FM-49301','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-5980' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-5980','Perpetual Wholesale Concentrated Equity Fund', '', 'FM-49301','FM-49301','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-11257' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-11257','Perpetual Wholesale Conservative Growth Fund', '', 'FM-49301','FM-49301','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-11252' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-11252','Perpetual Wholesale Diversified Growth Fund', '', 'FM-49301','FM-49301','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-15087' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-15087','Perpetual Wholesale Diversified Income Fund', '', 'FM-49301','FM-49301','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-27283' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-27283','Perpetual Wholesale Dynamic Fixed Income Fund', '', 'FM-49301','FM-49301','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-11193' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-11193','Perpetual Wholesale Ethical SRI Fund', '', 'FM-49301','FM-49301','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2GKH')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-13001' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-13001','Perpetual Wholesale Geared Australian Share Fund', '', 'FM-49301','FM-49301','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31507' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31507','Perpetual Wholesale Global Share Fund', '', 'FM-49301','FM-49301','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32175' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32175','Perpetual Wholesale Global Share Fund Hedged', '', 'FM-49301','FM-49301','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4303' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4303','Perpetual Wholesale Industrial Share Fund', '', 'FM-49301','FM-49301','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4292' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4292','Perpetual Wholesale International Share Fund', '', 'FM-49301','FM-49301','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14119' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14119','Perpetual Wholesale SHARE-PLUS Long-Short Fund', '', 'FM-49301','FM-49301','Adrian  Hoe','https://ap1.salesforce.com/a0L9000001Fo9tY?srPos=0&srKp=a0N')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4299' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4299','Perpetual Wholesale Smaller Companies Fund', '', 'FM-49301','FM-49301','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4295' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4295','Perpetual Wholesale Split Growth Fund', '', 'FM-49301','FM-49301','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-13921' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-13921','PIMCO Australian Bond Fund  Wholesale Class', '', 'FM-49303','FM-49303','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-23238' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-23238','PIMCO Australian Focus Fund  Wholesale Class', '', 'FM-49303','FM-49303','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31858' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31858','PIMCO Capital Securities Fund  Wholesale Class', '', 'FM-49303','FM-49303','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-13922' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-13922','PIMCO Diversified Fixed Interest Fund  Wholesale Class', '', 'FM-49303','FM-49303','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-13925' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-13925','PIMCO Emerging Markets Bond Fund  Wholesale Class', '', 'FM-49303','FM-49303','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-11439' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-11439','PIMCO Global Bond Fund  Wholesale Class', '', 'FM-49303','FM-49303','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-13924' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-13924','PIMCO Global Credit Fund  Wholesale Class', '', 'FM-49303','FM-49303','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-31944' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-31944','PIMCO Income Fund  Wholesale Class', '', 'FM-49303','FM-49303','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31280' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31280','PIMCO Unconstrained Bond Fund  Wholesale Class', '', 'FM-49303','FM-49303','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31599' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31599','PineBridge Global Dynamic Asset Allocation Fund', '', 'FM-49304','FM-49304','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4099' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4099','Hyperion Australian Growth Companies Fund', '', 'FM-49305','FM-49305','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-6487' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-6487','Hyperion Small Growth Companies Fund', '', 'FM-49305','FM-49305','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-13031' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-13031','Platinum Asia Fund', '', 'FM-49307','FM-49307','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32584' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32584','Platinum Asia Fund (Quoted Managed Fund)', '', 'FM-49307','FM-49307','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-6554' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-6554','Platinum European Fund', '', 'FM-49307','FM-49307','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-5361' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-5361','Platinum International Brands Fund', '', 'FM-49307','FM-49307','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-6553' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-6553','Platinum International Fund', '', 'FM-49307','FM-49307','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32583' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32583','Platinum International Fund (Quoted Managed Fund)', '', 'FM-49307','FM-49307','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14878' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14878','Platinum International Healthcare Fund', '', 'FM-49307','FM-49307','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-5362' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-5362','Platinum International Technology Fund', '', 'FM-49307','FM-49307','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-6555' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-6555','Platinum Japan Fund', '', 'FM-49307','FM-49307','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-27043' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-27043','Plato Australian Shares Income Fund', '', 'FM-49308','FM-49308','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31151' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31151','Plato Australian Shares Income Fund (Managed Risk)', '', 'FM-49308','FM-49308','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-22948' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-22948','PM CAPITAL Asian Companies Fund', '', 'FM-49309','FM-49309','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2DZ2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-5222' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-5222','PM CAPITAL Australian Companies Fund', '', 'FM-49309','FM-49309','Adrian  Hoe','https://ap1.salesforce.com/a0L9000001Fo9tY?srPos=0&srKp=a0N')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-11064' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-11064','PM CAPITAL Enhanced Yield Fund', '', 'FM-49309','FM-49309','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-5218' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-5218','PM Capital Global Companies Fund', '', 'FM-49309','FM-49309','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-15093' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-15093','Prime Value Growth Fund Class B', '', 'FM-49311','FM-49311','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-15097' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-15097','Prime Value Imputation Fund Class B', '', 'FM-49311','FM-49311','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30730' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30730','Prime Value Opportunities A', '', 'FM-49311','FM-49311','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-15005' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-15005','Principal Global Credit Opportunities Fund', '', 'FM-49312','FM-49312','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-20756' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-20756','Principal Global Property Securities Fund', '', 'FM-49312','FM-49312','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lc3')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-27359' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-27359','RARE Emerging Markets Fund', '', 'FM-49315','FM-49315','Sam Morris','https://ap1.salesforce.com/a0L9000001E0y4g')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-20422' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-20422','RARE Infrastructure Income Fund', '', 'FM-49315','FM-49315','Sam Morris','https://ap1.salesforce.com/a0L9000001E0y4g')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-18814' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-18814','RARE Infrastructure Value Fund  Hedged', '', 'FM-49315','FM-49315','Sam Morris','https://ap1.salesforce.com/a0L9000001E0y4g')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-26982' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-26982','RARE Infrastructure Value Fund  Unhedged', '', 'FM-49315','FM-49315','Sam Morris','https://ap1.salesforce.com/a0L9000001E0y4g')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-26648' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-26648','Regal Long Short Australian Equity Fund', '', 'FM-49317','FM-49317','Adrian  Hoe','https://ap1.salesforce.com/a0L9000001Fo9tY?srPos=0&srKp=a0N')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-25196' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-25196','Resolution Capital Global Property Securities Fund', '', 'FM-49317','FM-49317','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lc3')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-15158' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-15158','Resolution Capital Global Property Securities Fund (Hedged)  Series II', '', 'FM-49317','FM-49317','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lc3')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-27223' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-27223','Resolution Capital Global Property Securities Fund (Unhedged)  Series II', '', 'FM-49317','FM-49317','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lc3')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31314' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31314','Robeco BP Global Premium Equities Fund (AUD)', '', 'FM-49318','FM-49318','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30904' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30904','Robeco Emerging Conservative Equity Fund', '', 'FM-49318','FM-49318','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2DZ2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-27984' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-27984','Russell After-Tax Australian Shares Fund (Super Investors)  Class A', '', 'FM-49319','FM-49319','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-21264' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-21264','Russell Balanced Opportunities Portfolio', '', 'FM-49319','FM-49319','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14268' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14268','Russell Investments Australian Opportunities Fund  Class A', '', 'FM-49319','FM-49319','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14267' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14267','Russell Investments Australian Shares Fund  Class A', '', 'FM-49319','FM-49319','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14274' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14274','Russell Investments Balanced Fund  Class A', '', 'FM-49319','FM-49319','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14272' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14272','Russell Investments Conservative Fund  Class A', '', 'FM-49319','FM-49319','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14273' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14273','Russell Investments Diversified 50 Fund  Class A', '', 'FM-49319','FM-49319','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-19373' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-19373','Russell Investments Emerging Markets Fund  Class A', '', 'FM-49319','FM-49319','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2DZ2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-26814' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-26814','Russell Investments Global Listed Infrastructure Fund  Hedged', '', 'FM-49319','FM-49319','Sam Morris','https://ap1.salesforce.com/a0L9000001E0y4g')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-21033' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-21033','Russell Investments Global Opportunities Fund  $A Hedged (Class A)', '', 'FM-49319','FM-49319','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14271' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14271','Russell Investments Global Opportunities Fund Class A', '', 'FM-49319','FM-49319','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14275' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14275','Russell Investments Growth Fund  Class A', '', 'FM-49319','FM-49319','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-19064' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-19064','Russell Investments High Growth Fund  Class A', '', 'FM-49319','FM-49319','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-24508' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-24508','Russell Investments International Bond $A Hedged Fund Class A', '', 'FM-49319','FM-49319','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14754' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14754','Russell Investments International Property Securities Fund  Hedged', '', 'FM-49319','FM-49319','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lc3')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14276' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14276','Russell Investments International Shares Fund  $A Hedged (Class A)', '', 'FM-49319','FM-49319','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14270' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14270','Russell Investments International Shares Fund  Class A', '', 'FM-49319','FM-49319','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32194' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32194','Russell Investments Multi-Asset Growth Strategy Fund - Class A', '', 'FM-49319','FM-49319','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31417' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31417','Russell Investments Multi-Asset Growth Strategy Fund (Retail)  Class A', '', 'FM-49319','FM-49319','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31418' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31418','Russell Investments Multi-Asset Growth Strategy Plus Fund  Class A', '', 'FM-49319','FM-49319','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31420' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31420','Russell Investments Multi-Asset Income Strategy Fund  Class A', '', 'FM-49319','FM-49319','Jude McDonnell','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-12023' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-12023','Russell Investments Portfolio Series  Balanced', '', 'FM-49319','FM-49319','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-12022' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-12022','Russell Investments Portfolio Series  Conservative', '', 'FM-49319','FM-49319','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-12024' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-12024','Russell Investments Portfolio Series  Growth', '', 'FM-49319','FM-49319','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-29972' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-29972','Sandhurst Strategic Income Fund B', '', 'FM-49320','FM-49320','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-12225' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-12225','Schroder Australian Equity Fund W Class', '', 'FM-49322','FM-49322','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-12290' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-12290','Schroder Balanced Fund  W Class', '', 'FM-49322','FM-49322','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-12291' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-12291','Schroder Credit Securities Fund  W Class', '', 'FM-49322','FM-49322','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-13903' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-13903','Schroder Fixed Income Fund', '', 'FM-49322','FM-49322','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-24852' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-24852','Schroder Global Blend Fund', '', 'FM-49322','FM-49322','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-19091' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-19091','Schroder Global Emerging Markets Fund', '', 'FM-49322','FM-49322','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2DZ2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-24853' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-24853','Schroder Global Quality Fund', '', 'FM-49322','FM-49322','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-19511' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-19511','Schroder Global Value Fund', '', 'FM-49322','FM-49322','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-19512' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-19512','Schroder Global Value Fund (Hedged)', '', 'FM-49322','FM-49322','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31896' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31896','Schroder Real Return CPI Plus 3.5% Fund  Wholesale Class', '', 'FM-49322','FM-49322','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-25244' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-25244','Schroder Real Return CPI Plus 5% Fund  Wholesale Class', '', 'FM-49322','FM-49322','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32177' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32177','Schroder Real Return Fund (Managed Fund)', '', 'FM-49322','FM-49322','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-28443' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-28443','Smallco Broadcap Fund', '', 'FM-49328','FM-49328','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-13260' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-13260','Smallco Investment Fund', '', 'FM-49328','FM-49328','Adrian  Hoe','https://ap1.salesforce.com/a0L9000001Fo9tY?srPos=0&srKp=a0N')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-21017' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-21017','Solaris Core Australian Equity Fund', '', 'FM-49329','FM-49329','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-28402' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-28402','Solaris Core Australian Equity Fund (Performance Alignment)', '', 'FM-49330','FM-49330','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32148' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32148','Spheria Australian Microcap Fund', '', 'FM-49331','FM-49331','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-21173' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-21173','Spheria Australian Smaller Companies Fund', '', 'FM-49331','FM-49331','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31331' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31331','Spire Copper Rock Capital Global Smaller Companies Fund', '', 'FM-49333','FM-49333','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31213' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31213','Standard Life Investments Absolute Return Global Bond Strategies Trust', '', 'FM-49333','FM-49333','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30164' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30164','Standard Life Investments Global Absolute Return Strategies Trust', '', 'FM-49333','FM-49333','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lQV')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32219' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32219','Standard Life Investments Global Equity Unconstrained Trust', '', 'FM-49333','FM-49333','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-31961' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-31961','Standard Life Investments Global Focused Strategies Trust', '', 'FM-49333','FM-49333','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lQV')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-28632' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-28632','State Street Australian Equity Fund', '', 'FM-49334','FM-49334','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31043' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31043','State Street Builder Fund', '', 'FM-49334','FM-49334','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30082' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30082','State Street Global Equity Fund', '', 'FM-49334','FM-49334','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31042' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31042','State Street Provider Fund', '', 'FM-49334','FM-49334','Jude McDonnell','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31044' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31044','State Street Sustainer Fund', '', 'FM-49334','FM-49334','Jude McDonnell','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31216' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31216','Sunsuper for Life  Balanced', '', 'FM-49335','FM-49335','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31219' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31219','Sunsuper for Life  Balanced Index', '', 'FM-49335','FM-49335','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31214' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31214','Sunsuper for Life  Capital Guaranteed', '', 'FM-49335','FM-49335','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31215' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31215','Sunsuper for Life  Conservative', '', 'FM-49335','FM-49335','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31217' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31217','Sunsuper for Life  Growth', '', 'FM-49335','FM-49335','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31218' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31218','Sunsuper for Life  Retirement', '', 'FM-49335','FM-49335','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-28032' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-28032','Supervised Global Income Fund', '', 'FM-49336','FM-49336','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-20901' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-20901','T. Rowe Price Asia Ex-Japan Equity Fund', '', 'FM-49337','FM-49337','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2DZ2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-28880' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-28880','T. Rowe Price Australian Equity Fund', '', 'FM-49337','FM-49337','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31614' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31614','T. Rowe Price Dynamic Global Bond', '', 'FM-49337','FM-49337','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-27397' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-27397','T. Rowe Price Global Equity (Hedged) Fund', '', 'FM-49337','FM-49337','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-19294' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-19294','T. Rowe Price Global Equity Fund', '', 'FM-49337','FM-49337','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-31948' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-31948','CFM Institutional Systematic Diversified Trust A', '', 'FM-49339','FM-49339','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lQV')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32575' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32575','CFM IS Trends Trust  Class A', '', 'FM-49339','FM-49339','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lQV')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4390' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4390','UBS Australian Bond Fund', '', 'FM-49346','FM-49346','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4337' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4337','UBS Australian Share Fund', '', 'FM-49346','FM-49346','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-14460' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-14460','UBS Australian Small Companies Fund', '', 'FM-49346','FM-49346','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-7824' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-7824','UBS Balanced Investment Fund', '', 'FM-49346','FM-49346','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32227' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32227','UBS Clarion Global Infrastructure Securities Fund', '', 'FM-49346','FM-49346','Sam Morris','https://ap1.salesforce.com/a0L9000001E0y4g')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-15151' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-15151','UBS Clarion Global Property Securities Fund', '', 'FM-49346','FM-49346','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lc3')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-7825' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-7825','UBS Defensive Investment Fund', '', 'FM-49346','FM-49346','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-7830' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-7830','UBS Diversified Fixed Income Fund', '', 'FM-49346','FM-49346','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-11095' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-11095','UBS Income Solution Fund', '', 'FM-49346','FM-49346','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32574' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32574','UBS IQ Cash ETF', '', 'FM-49346','FM-49346','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'EF-2-30901' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'EF-2-30901','UBS IQ Morningstar Australia Dividend Yield ETF', '', 'FM-49346','FM-49346','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'EF-2-30534' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'EF-2-30534','UBS IQ Morningstar Australia Quality ETF', '', 'FM-49346','FM-49346','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-7833' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-7833','UBS Property Securities Fund', '', 'FM-49346','FM-49346','Kevin Posser','https://ap1.salesforce.com/a0L9000001E0XIo')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30031' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30031','UBS Tactical Beta Balanced', '', 'FM-49346','FM-49346','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30029' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30029','UBS Tactical Beta Conservative', '', 'FM-49346','FM-49346','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30030' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30030','UBS Tactical Beta Growth', '', 'FM-49346','FM-49346','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-23016' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-23016','UBS-HALO Australian Share Fund', '', 'FM-49346','FM-49346','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32126' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32126','Arnhem Australia+ Strategy', '', 'FM-49348','FM-49348','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4835' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4835','Arnhem Australian Equity Fund', '', 'FM-49348','FM-49348','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32125' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32125','Arnhem Global Growth Strategy', '', 'FM-49348','FM-49348','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-12438' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-12438','Vanguard Balanced Index Fund', '', 'FM-49348','FM-49348','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-5750' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-5750','Vanguard Cash Plus Fund', '', 'FM-49348','FM-49348','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-20447' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-20447','Vanguard Cash Reserve Fund', '', 'FM-49348','FM-49348','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32535' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32535','Vanguard Global Minimum Volatility Fund', '', 'FM-49348','FM-49348','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32534' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32534','Vanguard Global Value Equity Fund', '', 'FM-49348','FM-49348','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-12437' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-12437','Vanguard Wholesale Conservative Index Fund', '', 'FM-49348','FM-49348','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-12439' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-12439','Vanguard Wholesale Growth Index Fund', '', 'FM-49348','FM-49348','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-12440' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-12440','Vanguard Wholesale High Growth Index Fund', '', 'FM-49348','FM-49348','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32171' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32171','Watermark Market Neutral Trust', '', 'FM-49351','FM-49351','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lQV')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31597' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31597','William Blair Emerging Markets Leaders Fund', '', 'FM-49353','FM-49353','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2DZ2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31348' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31348','William Blair Global Leaders Fund', '', 'FM-49353','FM-49353','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4359' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4359','Zurich Investments Australian Property Securities Fund', '', 'FM-49355','FM-49355','Kevin Posser','https://ap1.salesforce.com/a0L9000001E0XIo')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32150' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32150','Zurich Investments Concentrated Global Growth Fund', '', 'FM-49355','FM-49355','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31598' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31598','Zurich Investments Emerging Markets Equity Fund', '', 'FM-49355','FM-49355','Steven Sweeney','https://ap1.salesforce.com/a0L9000001E2DZ2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-15183' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-15183','Zurich Investments Equity Income Fund', '', 'FM-49355','FM-49355','Adrian Hoe','https://ap1.salesforce.com/a0L9000001Fo9tY')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-27124' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-27124','Zurich Investments Global Equity Income Fund', '', 'FM-49355','FM-49355','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-22701' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-22701','Zurich Investments Global Growth Fund', '', 'FM-49355','FM-49355','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4352' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4352','Zurich Investments Global Thematic Share Fund', '', 'FM-49355','FM-49355','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-18781' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-18781','Zurich Investments Hedged Global Thematic Share Fund', '', 'FM-49355','FM-49355','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4355' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4355','Zurich Investments Managed Growth Fund', '', 'FM-49355','FM-49355','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-26626' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-26626','Zurich Investments Small Companies Fund', '', 'FM-49355','FM-49355','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-23495' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-23495','Zurich Investments Unhedged Global Growth Fund', '', 'FM-49355','FM-49355','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-25106' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-25106','Zurich Investments Unhedged Global Thematic Share Fund', '', 'FM-49355','FM-49355','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-12048' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-12048','Zurich Superannuation Plan  Balanced Fund', '', 'FM-49355','FM-49355','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-12049' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-12049','Zurich Superannuation Plan  Capital Stable Fund', '', 'FM-49355','FM-49355','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-12056' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-12056','Zurich Superannuation Plan  Managed Share Fund', '', 'FM-49355','FM-49355','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-10726' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-10726','Zurich Superannuation Plan  Priority Growth Fund', '', 'FM-49355','FM-49355','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-28821' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-28821','Bell Global Equities Fund  Platform', '', 'FM-49357','FM-49357','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-27778' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-27778','Alpha Australian Blue Chip Fund', '', 'FM-49516','FM-49516','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-27779' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-27779','Alpha Australian Small Companies Fund', '', 'FM-49516','FM-49516','Shailesh Jain','')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-23832' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-23832','Allan Gray Australia Equity Fund', '', 'FM-49619','FM-49619','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-28412' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-28412','Allan Gray Australia Stable Fund', '', 'FM-49619','FM-49619','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31609' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31609','AustralianSuper Balanced Option (MySuper Option)', '', 'FM-55841','FM-55841','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31612' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31612','AustralianSuper Conservative Balanced Option', '', 'FM-55841','FM-55841','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31610' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31610','AustralianSuper High Growth Option', '', 'FM-55841','FM-55841','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32223' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32223','AustralianSuper Indexed Diversified ', '', 'FM-55841','FM-55841','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31613' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31613','AustralianSuper Socially Aware Option', '', 'FM-55841','FM-55841','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31611' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31611','AustralianSuper Stable Option', '', 'FM-55841','FM-55841','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'EF-2-31661' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'EF-2-31661','Argo Global Listed Infrastructure Limited', '', 'FM-56107','FM-56107','Sam Morris','https://ap1.salesforce.com/a0L9000001E0y4g')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'EF-2-316' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'EF-2-316','Argo Investments Limited', '', 'FM-56107','FM-56107','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-4767' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-4767','Antipodes Asia Fund', '', 'FM-56597','FM-56597','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-6655' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-6655','Antipodes Global Fund', '', 'FM-56597','FM-56597','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31758' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31758','Antipodes Global Fund  Long Only', '', 'FM-56597','FM-56597','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32052' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32052','AB Concentrated Global Growth Equities Portfolio', '', 'FM-58242','FM-58242','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32051' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32051','AB Concentrated US Growth Equities Portfolio', '', 'FM-58242','FM-58242','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-30821' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-30821','AB Dynamic Global Fixed Income Fund', '', 'FM-58242','FM-58242','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31803' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31803','AB Global Equities Fund', '', 'FM-58242','FM-58242','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-27284' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-27284','AB Global High Income Fund', '', 'FM-58242','FM-58242','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31320' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31320','AB Managed Volatility Equities Fund', '', 'FM-58242','FM-58242','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32302' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32302','AustSafe Super  Balanced (My Super) Option', '', 'FM-58293','FM-58293','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32304' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32304','AustSafe Super  Capital Stable', '', 'FM-58293','FM-58293','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32305' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32305','AustSafe Super  CRF Capital Stable', '', 'FM-58293','FM-58293','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32303' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32303','AustSafe Super  Super Growth', '', 'FM-58293','FM-58293','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-23091' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-23091','AQR Wholesale DELTA Fund  Class 1F', '', 'FM-58463','FM-58463','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lQV')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-27355' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-27355','AQR Wholesale Managed Futures Fund  Class 1P', '', 'FM-58463','FM-58463','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lQV')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-27306' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-27306','Altius Bond Fund', '', 'FM-58506','FM-58506','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31505' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31505','Altius Sustainable Bond Fund', '', 'FM-58506','FM-58506','Jude McDonnell','https://ap1.salesforce.com/a0L9000001Fo44X')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-9137' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-9137','Australian Unity Property Income Fund', '', 'FM-58506','FM-58506','Kevin Posser','https://ap1.salesforce.com/a0L9000001E0XIo')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-19022' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-19022','Platypus Australian Equities Fund - Wholesale', '', 'FM-58506','FM-58506','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-26702' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-26702','Platypus Systematic Growth Fund', '', 'FM-58506','FM-58506','Shailesh Jain','https://ap1.salesforce.com/a0L9000001Fod8x')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-31290' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-31290','Wingate Global Equity Fund  Hedged', '', 'FM-58506','FM-58506','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-23751' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-23751','Wingate Global Equity Fund  Wholesale Units', '', 'FM-58506','FM-58506','Rui Fernandes','https://ap1.salesforce.com/a0L9000001HwGP2')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-23841' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-23841','Armytage Australian Equity Income Fund', '', 'FM-58513','FM-58513','Adrian Hoe','https://ap1.salesforce.com/a0L9000001Fo9tY')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-23839' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-23839','Armytage Strategic Opportunities Fund', '', 'FM-58513','FM-58513','Adrian Hoe','https://ap1.salesforce.com/a0L9000001Fo9tY')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-27765' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-27765','Atrium Evolution Series  Diversified Fund AEF 5', '', 'FM-60323','FM-60323','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-27766' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-27766','Atrium Evolution Series  Diversified Fund AEF 7', '', 'FM-60323','FM-60323','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'MF-1-27767' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'MF-1-27767','Atrium Evolution Series  Diversified Fund AEF 9', '', 'FM-60323','FM-60323','Deanne Baker','https://ap1.salesforce.com/a0L9000001JaPWv')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32273' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32273','Aviva Investors Multi-Strategy Target Income Fund', '', 'FM-60711','FM-60711','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lQV')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-31981' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-31981','Aviva Investors Multi-Strategy Target Return Fund', '', 'FM-60711','FM-60711','Sam Morris','https://ap1.salesforce.com/a0L9000001E3lQV')
END;

IF NOT EXISTS ( SELECT 1 FROM PRODUCT  WHERE SEGMENT_CD ='LR' AND product_id = 'FD-32410' )
BEGIN
    insert into product (ID, INSERT_DATE, LAST_MODIFIED, ACTIVE,  SEGMENT_CD,  PRODUCT_ID,  PRODUCT_NAME, PRODUCT_TYPE, EXT_UNIQUE_KEY, SEGMENT_ID, SECTOR_LEAD, RESEARCH_PLAN)
    values ( NEWID(), getdate(),  getdate(), 1, 'LR', 'FD-32410','Auscap Long Short Australian Equities Fund', '', 'FM-60737','FM-60737','Adrian  Hoe','https://ap1.salesforce.com/a0L9000001Fo9tY?srPos=0&srKp=a0N')
END;


