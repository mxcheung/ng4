---------------------------------------------------------------------------------------
-- Add lookup parent code
---------------------------------------------------------------------------------------
IF NOT EXISTS ( SELECT * FROM syscolumns WHERE id = OBJECT_ID('lookup') AND name = 'parent_code' )
BEGIN
	ALTER TABLE lookup ADD parent_code VARCHAR(255);
END

