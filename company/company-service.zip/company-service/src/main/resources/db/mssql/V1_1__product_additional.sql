---------------------------------------------------------------------------------------
-- Setup Product Classification
---------------------------------------------------------------------------------------

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODUCT_CLASSIFICATION]') AND type in (N'U'))
BEGIN
CREATE TABLE  PRODUCT_CLASSIFICATION( 
    id UNIQUEIDENTIFIER  NOT NULL, 
    insert_date datetime, 
    last_modified datetime, 
    APIR_CD VARCHAR(255), 
    ASSET_CLASS_NAME VARCHAR(255), 
    ASX_CD VARCHAR(255), 
    PRODUCT_CLASS VARCHAR(255), 
    PRODUCT_ID VARCHAR(255) NOT NULL, 
    PRODUCT_NAME VARCHAR(255), 
    SECTOR_NAME VARCHAR(255), 
    SUB_SECTOR_NAME VARCHAR(255),     
    SEGMENT_CD VARCHAR(255) NOT NULL, 
    PRIMARY KEY (id) 
)
END



IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[segment_cd_product_id_product_class_constraint]') AND type = 'K')
BEGIN
	ALTER TABLE PRODUCT_CLASSIFICATION ADD CONSTRAINT segment_cd_product_id_product_class_constraint UNIQUE (segment_cd, product_id);
END



---------------------------------------------------------------------------------------
-- Add product additional fields
---------------------------------------------------------------------------------------
IF NOT EXISTS ( SELECT * FROM syscolumns WHERE id = OBJECT_ID('product') AND name = 'RESEARCH_PLAN' )
BEGIN
	ALTER TABLE product ADD RESEARCH_PLAN VARCHAR(255);
END

IF NOT EXISTS ( SELECT * FROM syscolumns WHERE id = OBJECT_ID('product') AND name = 'SECTOR_LEAD' )
BEGIN
	ALTER TABLE product ADD SECTOR_LEAD VARCHAR(255);
END



