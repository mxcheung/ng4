---------------------------------------------------------------------------------------
-- Update segment ACTIVE flag
---------------------------------------------------------------------------------------


IF NOT EXISTS ( SELECT 1 FROM SEGMENT  WHERE SEGMENT_CD ='LR' AND EXT_UNIQUE_KEY = 'FM-50001' AND ACTIVE = 0 )
BEGIN
       UPDATE SEGMENT SET ACTIVE = 1  WHERE SEGMENT_CD ='LR' AND EXT_UNIQUE_KEY = 'FM-50001' ;
END;


IF NOT EXISTS ( SELECT 1 FROM SEGMENT  WHERE SEGMENT_CD ='SR' AND EXT_UNIQUE_KEY = '284' AND ACTIVE = 0 )
BEGIN
       UPDATE SEGMENT SET ACTIVE = 1  WHERE SEGMENT_CD ='SR' AND EXT_UNIQUE_KEY = '284' ;
END;
