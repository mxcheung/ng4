---------------------------------------------------------------------------------------
-- Add segment active flag
---------------------------------------------------------------------------------------
IF NOT EXISTS ( SELECT * FROM syscolumns WHERE id = OBJECT_ID('segment') AND name = 'active' )
BEGIN
	ALTER TABLE segment ADD active BIT DEFAULT 0;
END


---------------------------------------------------------------------------------------
-- Add product active flag
---------------------------------------------------------------------------------------
IF NOT EXISTS ( SELECT * FROM syscolumns WHERE id = OBJECT_ID('product') AND name = 'active' )
BEGIN
	ALTER TABLE product ADD active BIT DEFAULT 0;
END



