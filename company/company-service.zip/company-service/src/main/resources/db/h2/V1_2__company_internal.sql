---------------------------------------------------------------------------------------
-- INSERT INITIAL INTERNAL COMPANY
---------------------------------------------------------------------------------------

---------------------------------------------------------------------------------------
--INSERT INTO PUBLIC.COMPANY(ID, INSERT_DATE, LAST_MODIFIED, ABN, ADDRESS, COMPANY_NAME, PARENT_ID) VALUES
---------------------------------------------------------------------------------------
MERGE INTO PUBLIC.COMPANY KEY (ABN) VALUES
(RANDOM_UUID(), CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, '94151658534', '7/90 Collins St, Melbourne VIC 3000', 'Lonsec', NULL);


MERGE INTO PUBLIC.COMPANY KEY (ABN) VALUES
(RANDOM_UUID(), CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, '95100192283', 'Level 21, 200 George Street, Sydney NSW 2000', 'SuperRatings', NULL);

---------------------------------------------------------------------------------------
-- INSERT INTO PUBLIC.SEGMENT(ID, INSERT_DATE, LAST_MODIFIED, ABN, ANALYST, COMPANY_ID, COMPANY_NAME, EXT_UNIQUE_KEY, SEGMENT_CD) VALUES 
---------------------------------------------------------------------------------------
INSERT INTO PUBLIC.SEGMENT 
SELECT RANDOM_UUID(), CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, '94151658534', NULL, 'FM-50001', 'Lonsec Research', 'FM-50001', 'LR' WHERE NOT EXISTS (SELECT 1 FROM SEGMENT  WHERE SEGMENT_CD ='LR' AND EXT_UNIQUE_KEY = 'FM-50001');

INSERT INTO PUBLIC.SEGMENT 
SELECT RANDOM_UUID(), CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, '95100192283', NULL, '284', 'SuperRatings', '284', 'SR' WHERE NOT EXISTS (SELECT 1 FROM SEGMENT  WHERE SEGMENT_CD ='SR' AND EXT_UNIQUE_KEY = '284');


