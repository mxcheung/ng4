---------------------------------------------------------------------------------------
-- Update contact
---------------------------------------------------------------------------------------


UPDATE segment
SET analyst = replace(analyst, ' ', '.')
WHERE SEGMENT_CD ='SR'
AND analyst IN ( 'Hilde Endresen','Paul Touhill','Kristina Zamora','Janet Yang','Yoel Suhardja' );



