---------------------------------------------------------------------------------------
-- Add product additional classification fields
---------------------------------------------------------------------------------------

ALTER TABLE product ADD asx_cd VARCHAR(255);
ALTER TABLE product ADD asset_class_cd VARCHAR(255);
ALTER TABLE product ADD sector_cd VARCHAR(255);
ALTER TABLE product ADD sub_sector_cd VARCHAR(255);
ALTER TABLE product ADD product_class_cd VARCHAR(255);

---------------------------------------------------------------------------------------
-- Add segment notes fields
---------------------------------------------------------------------------------------

ALTER TABLE segment ADD notes VARCHAR(255);

