---------------------------------------------------------------------------------------
-- Update segment ACTIVE flag
---------------------------------------------------------------------------------------

UPDATE SEGMENT SET ACTIVE = 1  WHERE SEGMENT_CD ='LR' AND EXT_UNIQUE_KEY = 'FM-50001' ;

UPDATE SEGMENT SET ACTIVE = 1  WHERE SEGMENT_CD ='SR' AND EXT_UNIQUE_KEY = '284' ;



