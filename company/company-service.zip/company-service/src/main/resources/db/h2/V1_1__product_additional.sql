---------------------------------------------------------------------------------------
-- Setup Product Classification Table

CREATE TABLE IF NOT EXISTS PRODUCT_CLASSIFICATION( 
    ID BINARY NOT NULL, 
    INSERT_DATE TIMESTAMP, 
    LAST_MODIFIED TIMESTAMP, 
    APIR_CD VARCHAR(255), 
    ASSET_CLASS_NAME VARCHAR(255), 
    ASX_CD VARCHAR(255), 
    PRODUCT_CLASS VARCHAR(255), 
    PRODUCT_ID VARCHAR(255), 
    PRODUCT_NAME VARCHAR(255), 
    SECTOR_NAME VARCHAR(255), 
    SUB_SECTOR_NAME VARCHAR(255),     
    SEGMENT_CD VARCHAR(255) NOT NULL, 
    PRIMARY KEY (id) 
);

ALTER TABLE PRODUCT_CLASSIFICATION
ADD CONSTRAINT segment_cd_product_id_product_class_constraint
UNIQUE (segment_cd, product_id);
---------------------------------------------------------------------------------------

---------------------------------------------------------------------------------------
-- Add product additional fields
---------------------------------------------------------------------------------------

ALTER TABLE product ADD RESEARCH_PLAN VARCHAR(255);
ALTER TABLE product ADD SECTOR_LEAD VARCHAR(255);

