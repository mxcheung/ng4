package au.com.lonsec.service.company.product;

public class ProductNotFoundException extends Exception {

    private static final long serialVersionUID = -6022065019378181801L;

    public ProductNotFoundException(String message) {
        super(message);
    }

}
