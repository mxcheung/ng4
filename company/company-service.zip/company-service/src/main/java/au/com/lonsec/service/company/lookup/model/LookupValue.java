package au.com.lonsec.service.company.lookup.model;

/**
 * Lookup DTO for company maintenance.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

public class LookupValue {

    private String key;

    private String value;

    private String parentCode;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getParentCode() {
        return parentCode;
    }

    public void setParentCode(String parentCode) {
        this.parentCode = parentCode;
    }

}
