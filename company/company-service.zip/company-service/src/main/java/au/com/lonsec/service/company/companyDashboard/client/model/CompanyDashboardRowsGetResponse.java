package au.com.lonsec.service.company.companyDashboard.client.model;

import java.util.List;

import au.com.lonsec.service.company.company.client.model.Trackable;
import au.com.lonsec.service.company.companyDashboard.model.CompanyDashboardRow;

/**
 * Company Dashboard DTO for company dashboard.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

public class CompanyDashboardRowsGetResponse extends Trackable {

    private List<CompanyDashboardRow> companyDashboardRows;

    public List<CompanyDashboardRow> getCompanyDashboardRows() {
        return companyDashboardRows;
    }

    public void setCompanyDashboardRows(List<CompanyDashboardRow> companyDashboardRows) {
        this.companyDashboardRows = companyDashboardRows;
    }

}
