package au.com.lonsec.service.company.lookup;

import java.util.List;

/**
 * ProductAddRequest for product maintenance.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

public class LookupGetRequest {
    private String lookupType;
    private List<String> shoppingList;

    public String getLookupType() {
        return lookupType;
    }

    public void setLookupType(String lookupType) {
        this.lookupType = lookupType;
    }

    public List<String> getShoppingList() {
        return shoppingList;
    }

    public void setShoppingList(List<String> shoppingList) {
        this.shoppingList = shoppingList;
    }

}
