package au.com.lonsec.service.company.company.client.model;

import java.util.List;

/**
 * Company CompanyAddRequest for company maintenance.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

public class CompanyGetByIdsRequest {

    private List<String> abns;

    public List<String> getAbns() {
        return abns;
    }

    public void setAbns(List<String> abns) {
        this.abns = abns;
    }

}
