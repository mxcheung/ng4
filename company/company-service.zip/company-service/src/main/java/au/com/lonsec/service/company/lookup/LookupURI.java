package au.com.lonsec.service.company.lookup;

public final class LookupURI {

    public static final String LOOKUP_BASE_CONTEXT = "/lookup";

    /* Load the list of Lookups */
    public static final String LOOKUP_FETCH_MAPPING = "/lookupFetch";

    /* ReLoad the list of Lookups */
    public static final String LOOKUP_REFRESH = "/lookupLoadALL";

    /* ReLoad the custom company list of Lookups */
    public static final String COMPANY_LOOKUP = "/companyLookup";

    /* ReLoad the custom product list of Lookups */
    public static final String PRODUCT_LOOKUP = "/productLookup";

    /* ReLoad the custom product list of Lookups */
    public static final String CONTACT_LOOKUP = "/contactLookup";

    private LookupURI() {
    }

}
