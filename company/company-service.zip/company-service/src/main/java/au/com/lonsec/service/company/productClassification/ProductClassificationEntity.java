package au.com.lonsec.service.company.productClassification;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

import au.com.lonsec.service.company.base.AbstractEntity;

/**
 * ProductClassification Model representation for ProductClassification data.
 * 
 * @author MCheung
 */
@Entity
@Table(name = "productClassification")
public class ProductClassificationEntity extends AbstractEntity {

    @NotEmpty
    private String segmentCd;
    
    @NotEmpty
    @Column(name = "product_id", unique = true)
    private String productId;
    
    private String apirCd;
    private String asxCd;
    private String productName;
    private String assetClassName;
    private String sectorName;
    private String subSectorName;
    private String productClass;

    public String getSegmentCd() {
        return segmentCd;
    }

    public void setSegmentCd(String segmentCd) {
        this.segmentCd = segmentCd;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getApirCd() {
        return apirCd;
    }

    public void setApirCd(String apirCd) {
        this.apirCd = apirCd;
    }

    public String getAsxCd() {
        return asxCd;
    }

    public void setAsxCd(String asxCd) {
        this.asxCd = asxCd;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getAssetClassName() {
        return assetClassName;
    }

    public void setAssetClassName(String assetClassName) {
        this.assetClassName = assetClassName;
    }

    public String getSectorName() {
        return sectorName;
    }

    public void setSectorName(String sectorName) {
        this.sectorName = sectorName;
    }

    public String getSubSectorName() {
        return subSectorName;
    }

    public void setSubSectorName(String subSectorName) {
        this.subSectorName = subSectorName;
    }

    public String getProductClass() {
        return productClass;
    }

    public void setProductClass(String productClass) {
        this.productClass = productClass;
    }

}
