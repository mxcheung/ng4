package au.com.lonsec.service.company.company.client.model;

import au.com.lonsec.service.company.company.model.Company;

public class CompanyResponse extends Trackable {
    private static final long serialVersionUID = 1L;

    private Company company;

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }

}
