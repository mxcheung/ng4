package au.com.lonsec.service.company;

import static java.lang.String.format;
import static org.springframework.core.Ordered.HIGHEST_PRECEDENCE;

import java.util.Objects;

import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import au.com.lonsec.service.company.web.DpProfile;
import au.com.lonsec.service.company.company.CompanyNotFoundException;
import au.com.lonsec.service.company.configproperty.ConfigPropertyEntityNotFoundException;
import au.com.lonsec.service.company.product.ProductNotFoundException;
import au.com.lonsec.service.company.segment.SegmentNotFoundException;
import au.com.lonsec.starter.oauth2.model.User;

@RestControllerAdvice
@Order(HIGHEST_PRECEDENCE)
public class CompanyControllerAdvice {
    public static final String MODEL_ATTR_PROFILE = "dpProfile";

    private static final String HEADER_DP_PROFILE_TOKEN = "profileToken";

    @ExceptionHandler(Throwable.class)
    @ResponseBody
    ResponseEntity<String> handleException(Throwable exception) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(exception.getMessage());
    }

    @ExceptionHandler({ IllegalArgumentException.class, MethodArgumentNotValidException.class })
    @ResponseBody
    ResponseEntity<String> handleBadRequest(Exception exception) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(exception.getMessage());
    }

    @ExceptionHandler({ CompanyNotFoundException.class, SegmentNotFoundException.class, ProductNotFoundException.class,
            ConfigPropertyEntityNotFoundException.class })
    @ResponseBody
    ResponseEntity<String> handleUnableToLocateResource(Exception exception) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(exception.getMessage());
    }

    @ModelAttribute(MODEL_ATTR_PROFILE)
    DpProfile dataPortalProfile(@RequestHeader(value = HEADER_DP_PROFILE_TOKEN, required = false) final String token,
            @ModelAttribute("user") final User user) throws Exception {
        return Objects.isNull(token) ? null : DpProfile.fromToken(token, generateDisplayName(user));
    }

    private String generateDisplayName(User user) {
        return Objects.isNull(user.getFirstname()) && Objects.isNull(user.getSurname()) ? user.getUsername()
                : format("%s %s", Objects.toString(user.getFirstname(), ""), Objects.toString(user.getSurname(), "")).toUpperCase();
    }

}
