package au.com.lonsec.service.company.segment.client.model;

/**
 * Segment Response DTO for segment maintenance, returns the segement entity.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

public class SegmentsGetResponse extends SegmentsResponse {

    private static final long serialVersionUID = 1L;

}
