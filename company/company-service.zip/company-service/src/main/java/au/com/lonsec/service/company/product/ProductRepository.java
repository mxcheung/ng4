package au.com.lonsec.service.company.product;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<ProductEntity, Long> {

    List<ProductEntity> findBySegmentCd(String segmentCd);

    List<ProductEntity> findBySegmentCdAndExtUniqueKey(String segmentCd, String extUniqueKey);

    List<ProductEntity> findBySegmentId(String segmentId);

    ProductEntity findBySegmentCdAndProductId(String segmentCd, String productId);

    ProductEntity findByApirCd(String apirCd);

    ProductEntity findById(UUID id);
}