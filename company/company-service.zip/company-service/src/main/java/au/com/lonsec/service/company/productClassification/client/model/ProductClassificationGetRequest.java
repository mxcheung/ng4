package au.com.lonsec.service.company.productClassification.client.model;

/**
 * ProductClassificationAddRequest for ProductClassification maintenance.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

public class ProductClassificationGetRequest extends ProductClassificationRequest {
}
