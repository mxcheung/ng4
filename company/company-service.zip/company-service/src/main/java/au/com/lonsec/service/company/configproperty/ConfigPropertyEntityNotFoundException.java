package au.com.lonsec.service.company.configproperty;

public class ConfigPropertyEntityNotFoundException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public ConfigPropertyEntityNotFoundException(String message) {
        super(message);
    }

}
