package au.com.lonsec.service.company.product;

import java.util.ArrayList;
import java.util.List;

import org.dozer.DozerBeanMapper;
import org.dozer.loader.api.BeanMappingBuilder;
import org.dozer.loader.api.TypeMappingBuilder;
import org.springframework.stereotype.Service;

import au.com.lonsec.service.company.product.model.Product;

/**
 * ProductMapper supports mapping. 
 *     1. entity to model 
 *     2. model to entity
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

@Service
class ProductMapper {

    private DozerBeanMapper mapper;

    ProductMapper() {
        mapper = new DozerBeanMapper();
        mapper.addMapping(customProductToEntityMapper());
    }


    public Product map(ProductEntity source, Product dest) {
        mapper.map(source, dest);
        dest.setActive(source.getActive());
        mapClassification(source, dest);
        return dest;
    }


    private void mapClassification(ProductEntity source, Product dest) {
        dest.setApirCd(source.getApirCd());
        dest.setAsxCd(source.getAsxCd());
        dest.setAssetClassCd(source.getAssetClassCd());
        dest.setSectorCd(source.getSectorCd());
        dest.setSubSectorCd(source.getSubSectorCd());
        dest.setProductClassCd(source.getProductClassCd());
    }
    
    public ProductEntity mapClassification(Product source, ProductEntity dest) {
        dest.setApirCd(source.getApirCd());
        dest.setAsxCd(source.getAsxCd());
        dest.setAssetClassCd(source.getAssetClassCd());
        dest.setSectorCd(source.getSectorCd());
        dest.setSubSectorCd(source.getSubSectorCd());
        dest.setProductClassCd(source.getProductClassCd());
        return dest;
    }

    
    public ProductEntity map(Product source, ProductEntity dest) {
        mapper.map(source, dest);
        return dest;
    }
    
    
    private BeanMappingBuilder customProductToEntityMapper() {
        List<String> excludeList = getExcludeList();
        BeanMappingBuilder builder = new BeanMappingBuilder() {
            protected void configure() {
                TypeMappingBuilder typeMappingBuilder =
                       mapping(Product.class, ProductEntity.class);
                excludeList.forEach(typeMappingBuilder::exclude);
            }
        };
        return builder;
    }


    private List<String> getExcludeList() {
        List<String> excludeList = new ArrayList<>();
        excludeList.add("id");
        excludeList.add("active");
        excludeList.add("apirCd");
        excludeList.add("asxCd");
        excludeList.add("assetClassCd");
        excludeList.add("sectorCd");
        excludeList.add("subSectorCd");
        excludeList.add("productClassCd");
        return excludeList;
    }

}
