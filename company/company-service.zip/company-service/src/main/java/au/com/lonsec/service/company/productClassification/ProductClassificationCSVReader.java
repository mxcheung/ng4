package au.com.lonsec.service.company.productClassification;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.databind.ObjectReader;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;

import au.com.lonsec.service.company.AppProperties;

/**
 * ProductClassificationCSVReader to load ProductClassifications.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

@Service
public class ProductClassificationCSVReader {

    private final CsvMapper mapper = new CsvMapper();
    private final CsvSchema schema = mapper.schemaFor(ProductClassificationRow.class);
    private final String productClassificationFolder;

    @Autowired
    ProductClassificationCSVReader(AppProperties appProperties) {
        productClassificationFolder = appProperties.getLookupFolder();
    }

    public ArrayList<ProductClassificationRow> readProductClassification(String filename) throws FileNotFoundException, IOException {
        InputStream inputStream = new FileInputStream(getFile(filename));
        return readProductClassification(inputStream);
    }   

    public ArrayList<ProductClassificationRow> readProductClassification(InputStream inputStream) throws FileNotFoundException, IOException {
        ArrayList<ProductClassificationRow> rows = new ArrayList<ProductClassificationRow>();
        Reader reader = getReader(inputStream);
        ObjectReader oReader = mapper.readerFor(ProductClassificationRow.class).with(schema);
        MappingIterator<?> mi = oReader.readValues(reader);
        while (mi.hasNext()) {
            rows.add((ProductClassificationRow) mi.next());
        }
        return rows;
    }

    public Reader getReader(InputStream inputStream) throws FileNotFoundException {
        Reader reader = new InputStreamReader(inputStream);
        return reader;
    }

    public File getFile(String fileName) {
        return new File(productClassificationFolder + fileName);
    }

}
