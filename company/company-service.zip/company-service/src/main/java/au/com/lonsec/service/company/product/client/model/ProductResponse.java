package au.com.lonsec.service.company.product.client.model;

import au.com.lonsec.service.company.company.client.model.Trackable;
import au.com.lonsec.service.company.product.model.Product;

public class ProductResponse extends Trackable {

    private static final long serialVersionUID = 1L;

    private Product product;

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

}
