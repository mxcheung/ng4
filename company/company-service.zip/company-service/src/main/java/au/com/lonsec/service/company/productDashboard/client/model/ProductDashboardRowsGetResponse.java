package au.com.lonsec.service.company.productDashboard.client.model;

import java.util.List;

import au.com.lonsec.service.company.company.client.model.Trackable;
import au.com.lonsec.service.company.productDashboard.model.ProductDashboardRow;

/**
 * Product Dashboard DTO for product dashboard.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

public class ProductDashboardRowsGetResponse extends Trackable {

    private List<ProductDashboardRow> productDashboardRows;

    public List<ProductDashboardRow> getProductDashboardRows() {
        return productDashboardRows;
    }

    public void setProductDashboardRows(List<ProductDashboardRow> productDashboardRows) {
        this.productDashboardRows = productDashboardRows;
    }


}
