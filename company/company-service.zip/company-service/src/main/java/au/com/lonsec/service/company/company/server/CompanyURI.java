package au.com.lonsec.service.company.company.server;

/**
 * @author MAX see https://studio.restlet.com/apis/local/sections/Companies
 *         https://hello-angularjs.appspot.com/searchtable
 */
public final class CompanyURI {

    public static final String COMPANY_BASE_CONTEXT = "/companies";

    /* Load the list of Companies */
    public static final String GET_COMPANIES_MAPPING = "/companies";
    /* Load an individual Company */
    public static final String GET_COMPANY_MAPPING = "/company/{abn}";
    /* Create a new Company */
    public static final String POST_COMPANIES_MAPPING = "/company";
    /* Update a Company */
    public static final String PUT_COMPANIES_MAPPING = "/company/{abn}";

    public static final String COMPANY_ABNS_MAPPING = "/companyIds";

    private CompanyURI() {
    }

}