package au.com.lonsec.service.company.segment.client.model;

import au.com.lonsec.service.company.company.client.model.Trackable;
import au.com.lonsec.service.company.segment.model.Segment;

public class SegmentResponse extends Trackable {

    private static final long serialVersionUID = 1L;

    private Segment segment;

    public Segment getSegment() {
        return segment;
    }

    public void setSegment(Segment segment) {
        this.segment = segment;
    }

}
