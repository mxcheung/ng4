package au.com.lonsec.service.company.product.client.model;

/**
 * SegmentAddRequest DTO for segement maintenance.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

public class ProductUpdateResponse extends ProductResponse {

    private static final long serialVersionUID = 1L;

}
