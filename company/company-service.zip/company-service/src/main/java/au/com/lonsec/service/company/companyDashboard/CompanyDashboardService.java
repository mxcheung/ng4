package au.com.lonsec.service.company.companyDashboard;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import au.com.lonsec.service.company.companyDashboard.model.CompanyDashboardRow;
import au.com.lonsec.service.company.configproperty.ConfigProperty;
import au.com.lonsec.service.company.configproperty.ConfigPropertyService;
import au.com.lonsec.service.company.configproperty.ConfigPropertyType;
import au.com.lonsec.service.company.segment.SegmentService;
import au.com.lonsec.service.company.segment.model.Segment;

/**
 * CompanyDashboardService - supports Company Dashboard UI.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

@Service
class CompanyDashboardService {

    private static final Logger LOGGER = LoggerFactory.getLogger(CompanyDashboardService.class);

    private final SegmentService segmentService;

    private final ConfigPropertyService configPropertyService;

    private final CompanyDashboardMapper companyDashboardMapper;

    @Autowired
    CompanyDashboardService(SegmentService segmentService, ConfigPropertyService configPropertyService,
            CompanyDashboardMapper companyDashboardMapper) {
        this.segmentService = segmentService;
        this.configPropertyService = configPropertyService;
        this.companyDashboardMapper = companyDashboardMapper;
    }

    /**
     * Find all segments for a segmentCd.
     * 
     * @param segmentCd business segment.
     * @return data rows to support the product dashboard.
     */
    public List<CompanyDashboardRow> findCompanies(String segmentCd) {

        LOGGER.debug("findCompanies segmentCd: ", segmentCd);
        List<Segment> segments = segmentService.findSegment(segmentCd);

        List<CompanyDashboardDTO> dashboardDTOs = fetchAssociations(segmentCd, segments);
        return convertUp(dashboardDTOs);
    }

    private List<CompanyDashboardDTO> fetchAssociations(final String segmentCd, final List<Segment> segments) {
        return segments.stream().map(entity -> fetchAssociation(segmentCd, entity)).collect(Collectors.toList());
    }

    /**
     * Find associated entities [config properties] for a segment.
     * 
     * @param segmentCd business segment.
     * @param segment segment details.
     * @return companydashboard DTO that contains the composite entities.
     */
    public CompanyDashboardDTO fetchAssociation(final String segmentCd, final Segment segment) {
        CompanyDashboardDTO companyDashboardDTO = new CompanyDashboardDTO();
        String extUniqueKey = segment.getExtUniqueKey();
        List<ConfigProperty> propertyList = configPropertyService.getEntityProperties(extUniqueKey, ConfigPropertyType.SEGMENT);
        companyDashboardDTO.setSegment(segment);
        companyDashboardDTO.setPropertyList(propertyList);
        return companyDashboardDTO;
    }

    /**
     * Map Composite DTOs to Dashboard Rows.
     *
     * @param companyList - list of companies to convert.
     * @return Company Dashboard Rows.
     */
    public List<CompanyDashboardRow> convertUp(List<CompanyDashboardDTO> companyList) {
        return companyList.stream().map(entity -> convertUp(entity)).collect(Collectors.toList());
    }

    /**
     * Map Composite DTO to Dashboard Row.
     * 
     * @param companyDashboardDTO composite entities [segment, config properties].
     * @return Dashboard Row.
     */
    public CompanyDashboardRow convertUp(CompanyDashboardDTO companyDashboardDTO) {
        return companyDashboardMapper.map(companyDashboardDTO, new CompanyDashboardRow());
    }

}