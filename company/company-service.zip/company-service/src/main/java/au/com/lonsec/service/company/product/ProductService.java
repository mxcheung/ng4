package au.com.lonsec.service.company.product;

import static java.util.stream.Collectors.toList;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import au.com.lonsec.service.company.product.client.model.ProductAddRequest;
import au.com.lonsec.service.company.product.client.model.ProductRequest;
import au.com.lonsec.service.company.product.client.model.ProductUpdateRequest;
import au.com.lonsec.service.company.product.model.Product;
import au.com.lonsec.service.company.web.DpProfile;

/**
 * ProductService - supports crud method for product repository. Unique identifier (per segment): productId
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

@Service
public class ProductService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ProductService.class);

    private final ProductRepository productRepository;

    private final ProductMapper productMapper;

    @Autowired
    ProductService(ProductRepository productRepository, ProductMapper productMapper) {
        this.productRepository = productRepository;
        this.productMapper = productMapper;
    }

    /**
     * Create Product will attempt to match existing on segmentid, product_id. If no matching product then
     * proceed with product creation
     * 
     * @param productAddRequest Product Add request
     * @return ProductEntity
     */
    public Product createProduct(ProductAddRequest productAddRequest) {
        return convertUp(save(productAddRequest, findOrCreate(productAddRequest)));
    }

    /**
     * Update Product validate entity exists using primary key. If no matching product then throw
     * ProductNotFoundException
     * 
     * @param productId Product id unique key
     * @param segmentCd Segment Code.
     * @param productUpdateRequest Product Update Request incl Primary Key
     * @return ProductEntity
     * @throws ProductNotFoundException unable to locate product via Primary key
     */
    public Product updateProduct(String segmentCd, String productId, ProductUpdateRequest productUpdateRequest) throws ProductNotFoundException {
        return convertUp(save(productUpdateRequest, matchProduct(segmentCd, productId)));
    }

    /**
     * Update Product Classification validate entity exists using primary key. If no matching product then
     * throw ProductNotFoundException
     * 
     * @param  productId Product id unique key
     * @param  segmentCd Segment Code.
     * @param  product   contains the classification fields to update.
     * @return ProductEntity
     * @throws ProductNotFoundException unable to locate product via Primary key
     */
    public Product updateProductClassification(String segmentCd, String productId, Product product) throws ProductNotFoundException {
        ProductEntity productEntity = matchProduct(segmentCd, productId);
        productMapper.mapClassification(product, productEntity);
        productRepository.save(productEntity);
        return convertUp(productEntity);
    }

    private ProductEntity findOrCreate(ProductRequest productRequestDTO) {
        ProductEntity product = productRepository.findBySegmentCdAndProductId(productRequestDTO.getSegmentCd(), productRequestDTO.getProductId());
        if (product == null) {
            product = new ProductEntity();
            product.setProductId(productRequestDTO.getProductId());
            productMapper.mapClassification(productRequestDTO, product);
        }
        return product;
    }

    private ProductEntity save(Product product, ProductEntity productEntity) {
        convertDown(product, productEntity);
        productRepository.save(productEntity);
        LOGGER.info("Product created :", product);
        return productEntity;
    }

    /**
     * Find Product by composite key.
     * 
     * @param segmentCd - business segment.
     * @param productId - unique identifier per segment.
     * @return - Product
     * @throws ProductNotFoundException product does not existing in the system.
     */
    public Product findProduct(String segmentCd, String productId) throws ProductNotFoundException {
        return convertUp(matchProduct(segmentCd, productId));
    }

    /**
     * Find all Products for a business segment and company external by company.
     * 
     * @param segmentCd - business segment.
     * @param extUniqueKey company unique key.
     * @return all products for a given company.
     */
    public List<Product> findBySegmentCdAndExtUniqueKey(String segmentCd, String extUniqueKey) {
        return convertUp(productRepository.findBySegmentCdAndExtUniqueKey(segmentCd, extUniqueKey));
    }

    /**
     * Find all Products for a business segment.
     * 
     * @param segmentCd - business segment.
     * @param profile - user profile token.
     * @return - Product for a segments.
     */
    public List<Product> findProducts(String segmentCd, DpProfile profile) {
        List<Product> products = convertUp(productRepository.findBySegmentCd(segmentCd));
        if (!profile.hasPermission(DpProfile.MASK_EMPLOYEES)) {
            return products.stream().filter(product -> product.getExtUniqueKey().equalsIgnoreCase(profile.getExternalIdentifier()))
                    .collect(toList());
        }
        return products;
    }

    /**
     * Use the following to locate product 1. segmentId + productId.
     * 
     * @param segmentCd - business segment.
     * @param productId - match on product id.
     * @return product having productId.
     * @throws ProductNotFoundException product having productId does not existing in the system.
     */
    private ProductEntity matchProduct(String segmentCd, String productId) throws ProductNotFoundException {
        ProductEntity product = findBySegmentCdAndProductId(segmentCd, productId);
        if (product == null) {
            throw new ProductNotFoundException(String.format("Unable to locate segmentCd: %s product: %s", segmentCd, productId));
        }
        return product;
    }

    private ProductEntity findBySegmentCdAndProductId(String segmentCd, String productId) {
        return productRepository.findBySegmentCdAndProductId(segmentCd, productId);
    }

    private ProductEntity convertDown(Product product, ProductEntity productEntity) {
        return productMapper.map(product, productEntity);
    }

    /**
     * Convert product entities to product model.
     * 
     * @param entityList list of product entities.
     * @return list of proucts,
     */
    public List<Product> convertUp(List<ProductEntity> entityList) {
        return entityList.stream().map(entity -> convertUp(entity)).collect(Collectors.toList());
    }

    private Product convertUp(ProductEntity productEntity) {
        Product product = new Product();
        productMapper.map(productEntity, product);
        return product;
    }

}