package au.com.lonsec.service.company.segment.client.model;

import java.util.List;

import au.com.lonsec.service.company.company.client.model.Trackable;
import au.com.lonsec.service.company.segment.model.Segment;

/**
 * Segment Response DTO for segment maintenance, returns the segement entity.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

public class SegmentsResponse extends Trackable {

    private static final long serialVersionUID = 1L;

    private List<Segment> segments;

    public List<Segment> getSegments() {
        return segments;
    }

    public void setSegments(List<Segment> segments) {
        this.segments = segments;
    }

}
