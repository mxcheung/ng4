package au.com.lonsec.service.company.configproperty;

import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.HttpStatus.OK;
import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Validated
@RequestMapping(value = ConfigController.CONFIG_BASE_CONTEXT)
class ConfigController {

    static final String CONFIG_BASE_CONTEXT = "/config";
    static final String CONFIG_SAVE_MAPPING = "/save";
    static final String CONFIG_GET_MAPPING = "/get/{entityId}";

    @Autowired
    private ConfigPropertyService configPropertyService;

    @RequestMapping(value = CONFIG_SAVE_MAPPING, method = POST)
    @ResponseStatus(CREATED)
    @ResponseBody
    public ResponseEntity<ConfigurationServiceResponseDTO> configSave(
            @RequestHeader(value = "Authorization", required = false) final String authToken,
            @RequestHeader(value = "segmentCd", required = false) final String xRequestSegmentCd,
            @Valid @RequestBody final ConfigDTO configDTO) {
        ConfigurationServiceResponseDTO configurationServiceResponseDTO = new ConfigurationServiceResponseDTO();
        List<ConfigProperty> propertyList = configPropertyService.updateEntityProperties(configDTO.getEntityId(),
                ConfigPropertyType.valueOf(configDTO.getType()), configDTO.getPropertyList());
        configurationServiceResponseDTO.setPropertyList(propertyList);
        configurationServiceResponseDTO.setEntityId(configDTO.getEntityId());
        configurationServiceResponseDTO.setType(configDTO.getType());
        return new ResponseEntity<>(configurationServiceResponseDTO, CREATED);
    }

    @RequestMapping(value = CONFIG_GET_MAPPING, method = GET)
    @ResponseStatus(OK)
    @ResponseBody
    public ResponseEntity<ConfigurationServiceResponseDTO> coonfigGet(@PathVariable("entityId") String entityId,
            @RequestParam(value = "type") final String type,
            @RequestHeader(value = "Authorization", required = false) final String authToken,
            @RequestHeader(value = "segmentCd", required = true) final String xRequestSegmentCd) {
        ConfigurationServiceResponseDTO configurationServiceResponseDTO = new ConfigurationServiceResponseDTO();
        List<ConfigProperty> propertyList = configPropertyService.getEntityProperties(entityId, ConfigPropertyType.valueOf(type));
        configurationServiceResponseDTO.setPropertyList(propertyList);
        configurationServiceResponseDTO.setEntityId(entityId);
        configurationServiceResponseDTO.setType(type);
        return new ResponseEntity<>(configurationServiceResponseDTO, OK);
    }

}
