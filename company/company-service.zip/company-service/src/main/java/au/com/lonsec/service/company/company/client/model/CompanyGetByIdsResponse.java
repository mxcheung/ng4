package au.com.lonsec.service.company.company.client.model;

import java.util.Map;

import au.com.lonsec.service.company.company.model.Company;

/**
 * Company Response DTO for company maintenance.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

public class CompanyGetByIdsResponse extends Trackable {

    private Map<String, Company> companyMap;

    public Map<String, Company> getCompanyEntityMap() {
        return companyMap;
    }

    public void setCompanyEntityMap(Map<String, Company> map) {
        this.companyMap = map;
    }

}
