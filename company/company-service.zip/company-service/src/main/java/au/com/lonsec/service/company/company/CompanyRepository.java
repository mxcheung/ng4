package au.com.lonsec.service.company.company;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CompanyRepository extends JpaRepository<CompanyEntity, Long> {
    CompanyEntity findByCompanyName(String companyName);

    CompanyEntity findByAbn(String abn);

    CompanyEntity findById(UUID id);

}