package au.com.lonsec.service.company.company.client.model;

import java.util.List;

import au.com.lonsec.service.company.company.model.Company;

public class CompaniesResponse {

    private static final long serialVersionUID = 1L;

    private List<Company> companies;

    public List<Company> getCompanies() {
        return companies;
    }

    public void setCompanies(List<Company> companies) {
        this.companies = companies;
    }

}
