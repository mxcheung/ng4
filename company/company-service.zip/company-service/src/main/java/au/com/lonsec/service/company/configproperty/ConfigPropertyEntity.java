package au.com.lonsec.service.company.configproperty;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import au.com.lonsec.service.company.base.AbstractEntity;

/**
 * Config Property Model representation for config property.
 * 
 * @author MCheung
 */
@Entity
@Table(name = "entityproperty")
public class ConfigPropertyEntity extends AbstractEntity {

    @Basic
    @Column(name = "entity_id", nullable = false)
    private String entityId;

    @Enumerated(EnumType.STRING)
    @Column(name = "property_type")
    private ConfigPropertyType propertyType;

    @Basic
    @Column(name = "property_key", nullable = false)
    private String propertyKey;

    @Basic
    @Column(name = "property_value", nullable = false)
    private String propertyValue;

    public String getEntityId() {
        return entityId;
    }

    public void setEntityId(String entityId) {
        this.entityId = entityId;
    }

    public ConfigPropertyType getPropertyType() {
        return propertyType;
    }

    public void setPropertyType(ConfigPropertyType type) {
        this.propertyType = type;
    }

    public String getPropertyKey() {
        return propertyKey;
    }

    public void setPropertyKey(String key) {
        this.propertyKey = key;
    }

    public String getPropertyValue() {
        return propertyValue;
    }

    public void setPropertyValue(String value) {
        this.propertyValue = value;
    }

}
