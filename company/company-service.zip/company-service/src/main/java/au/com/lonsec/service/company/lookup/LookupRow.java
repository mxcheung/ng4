package au.com.lonsec.service.company.lookup;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Lookup DTO for company maintenance.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "entityId", "looktype", "looktypeName", "code", "value", "parentCode" })
public class LookupRow {

    @NotNull(message = "entityId must be input")
    private String entityId;
    private String looktype;
    private String looktypeName;

    @JsonProperty(value = "code", required = true)
    private String code;

    private String value;

    private String parentCode;

    @JsonCreator
    public LookupRow(@JsonProperty(value = "entityId", required = true) String entityId,
            @JsonProperty(value = "looktype", required = true) String looktype,
            @JsonProperty(value = "looktypeName", required = true) String looktypeName, @JsonProperty(value = "code", required = true) String code,
            @JsonProperty(value = "value", required = true) String value,
            @JsonProperty(value = "parentCode", required = true) String parentCode) {
        this.entityId = entityId;
        this.looktype = looktype;
        this.looktypeName = looktypeName;
        this.code = code;
        this.value = value;
        this.parentCode = parentCode;
    }

    public String getEntityId() {
        return entityId;
    }

    public void setEntityId(String entityId) {
        this.entityId = entityId;
    }

    public String getLooktype() {
        return looktype;
    }

    public void setLooktype(String looktype) {
        this.looktype = looktype;
    }

    public String getLooktypeName() {
        return looktypeName;
    }

    public void setLooktypeName(String looktypeName) {
        this.looktypeName = looktypeName;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getParentCode() {
        return parentCode;
    }

    public void setParentCode(String parentCode) {
        this.parentCode = parentCode;
    }
    
}
