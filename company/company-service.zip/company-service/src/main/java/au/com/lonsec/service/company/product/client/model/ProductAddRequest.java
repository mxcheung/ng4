package au.com.lonsec.service.company.product.client.model;

/**
 * ProductAddRequest for product maintenance.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

public class ProductAddRequest extends ProductRequest {
}
