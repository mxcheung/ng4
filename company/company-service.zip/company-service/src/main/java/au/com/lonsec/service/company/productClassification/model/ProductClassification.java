package au.com.lonsec.service.company.productClassification.model;

/**
 * ProductClassification DTO for company maintenance.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

public class ProductClassification {
    
    private String productId;
    private String apirCd;
    private String asxCd;
    private String productName;
    private String assetClassName;
    private String sectorName;
    private String subSectorName;
    private String productClassName;

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getApirCd() {
        return apirCd;
    }

    public void setApirCd(String apirCd) {
        this.apirCd = apirCd;
    }

    public String getAsxCd() {
        return asxCd;
    }

    public void setAsxCd(String asxCd) {
        this.asxCd = asxCd;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getAssetClassName() {
        return assetClassName;
    }

    public void setAssetClassName(String assetClassName) {
        this.assetClassName = assetClassName;
    }

    public String getSectorName() {
        return sectorName;
    }

    public void setSectorName(String sectorName) {
        this.sectorName = sectorName;
    }

    public String getSubSectorName() {
        return subSectorName;
    }

    public void setSubSectorName(String subSectorName) {
        this.subSectorName = subSectorName;
    }

    public String getProductClassName() {
        return productClassName;
    }

    public void setProductClassName(String productClassName) {
        this.productClassName = productClassName;
    }

}
