package au.com.lonsec.service.company.segment;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

public interface SegmentRepository extends JpaRepository<SegmentEntity, Long> {

    List<SegmentEntity> findBySegmentCd(String segmentCd);

    SegmentEntity findBySegmentCdAndExtUniqueKey(String segmentCd, String extUniqueKey);

    SegmentEntity findById(UUID id);

    List<SegmentEntity> findBySegmentCdAndCompanyNameContainingIgnoreCase(String segmentCd, String companyName);

}