package au.com.lonsec.service.company.productClassification;

public final class ProductClassificationURI {

    public static final String PRODUCT_CLASSIFICATION_BASE_CONTEXT = "/productClassification";

    /* ReLoad the list of ProductClassifications */
    public static final String PRODUCT_CLASSIFICATION_REFRESH = "/productClassificationLoadALL";

    /* Load an individual Product Classification */
    public static final String GET_PRODUCT_CLASSIFICATION_MAPPING = "/productClassification/{productId}";

    private ProductClassificationURI() {
    }

}
