package au.com.lonsec.service.company.configproperty;

public enum ConfigPropertyType {
    COMPANY, SEGMENT, PRODUCT;

    ConfigPropertyType() {
    }

}