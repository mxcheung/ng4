package au.com.lonsec.service.company.company.server;

import static org.springframework.http.HttpStatus.ACCEPTED;
import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.HttpStatus.OK;
import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;
import static org.springframework.web.bind.annotation.RequestMethod.PUT;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import au.com.lonsec.service.company.company.CompanyNotFoundException;
import au.com.lonsec.service.company.company.CompanyService;
import au.com.lonsec.service.company.company.client.model.CompanyAddRequest;
import au.com.lonsec.service.company.company.client.model.CompanyAddResponse;
import au.com.lonsec.service.company.company.client.model.CompanyGetByIdsRequest;
import au.com.lonsec.service.company.company.client.model.CompanyGetByIdsResponse;
import au.com.lonsec.service.company.company.client.model.CompanyGetResponse;
import au.com.lonsec.service.company.company.client.model.CompanyUpdateRequest;
import au.com.lonsec.service.company.company.client.model.CompanyUpdateResponse;

/**
 * CompanyController - supports crud method for company repository.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

@RestController
@Validated
@RequestMapping(value = CompanyURI.COMPANY_BASE_CONTEXT)
public class CompanyController {

    @Autowired
    private CompanyService companyService;

    @RequestMapping(value = CompanyURI.GET_COMPANY_MAPPING, method = GET)
    @ResponseStatus(OK)
    @ResponseBody
    ResponseEntity<CompanyGetResponse> companyGet(@PathVariable("abn") String abn,
            @RequestHeader(value = "correlation-id", required = false) final String xRequestCorrelationID,
            @RequestHeader(value = "Authorization", required = false) final String authToken,
            @RequestHeader(value = "segmentCd", required = true) final String xRequestSegmentCd) throws CompanyNotFoundException {
        CompanyGetResponse result = new CompanyGetResponse();
        result.setCorrelationId(xRequestCorrelationID);
        result.setCompany(companyService.findCompany(abn));
        return new ResponseEntity<>(result, OK);
    }

    @RequestMapping(value = CompanyURI.COMPANY_ABNS_MAPPING, method = POST)
    @ResponseStatus(OK)
    @ResponseBody
    ResponseEntity<CompanyGetByIdsResponse> fetchByABNs(@Valid @RequestBody final CompanyGetByIdsRequest companyFetchByAbnsRequest,
            @RequestHeader(value = "correlation-id", required = false) final String xRequestCorrelationID,
            @RequestHeader(value = "Authorization", required = false) final String authToken,
            @RequestHeader(value = "segmentCd", required = false) final String xRequestSegmentCd) {
        CompanyGetByIdsResponse result = new CompanyGetByIdsResponse();
        result.setCorrelationId(xRequestCorrelationID);
        result.setCompanyEntityMap(companyService.fetchByABNs(companyFetchByAbnsRequest));
        return new ResponseEntity<>(result, OK);
    }

    @RequestMapping(value = CompanyURI.POST_COMPANIES_MAPPING, method = POST)
    @ResponseStatus(CREATED)
    @ResponseBody
    ResponseEntity<CompanyAddResponse> companyAdd(@Valid @RequestBody final CompanyAddRequest companyAddRequest,
            @RequestHeader(value = "correlation-id", required = false) final String xRequestCorrelationID,
            @RequestHeader(value = "Authorization", required = false) final String authToken,
            @RequestHeader(value = "segmentCd", required = false) final String xRequestSegmentCd) {
        CompanyAddResponse result = new CompanyAddResponse();
        result.setCorrelationId(xRequestCorrelationID);
        result.setCompany(companyService.createCompany(companyAddRequest));
        return new ResponseEntity<>(result, CREATED);

    }

    @RequestMapping(value = CompanyURI.PUT_COMPANIES_MAPPING, method = PUT)
    @ResponseStatus(ACCEPTED)
    @ResponseBody
    ResponseEntity<CompanyUpdateResponse> updateCompany(@PathVariable("abn") String abn,
            @RequestHeader(value = "correlation-id", required = false) final String xRequestCorrelationID,
            @RequestHeader(value = "Authorization", required = false) final String authToken,
            @RequestHeader(value = "segmentCd", required = false) final String xRequestSegmentCd,
            @Valid @RequestBody final CompanyUpdateRequest companyUpdateRequest) throws CompanyNotFoundException {
        CompanyUpdateResponse result = new CompanyUpdateResponse();
        result.setCorrelationId(xRequestCorrelationID);
        result.setCompany(companyService.updateCompany(companyUpdateRequest));
        return new ResponseEntity<>(result, ACCEPTED);
    }

}
