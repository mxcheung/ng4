package au.com.lonsec.service.company.companyDashboard;

import java.util.List;

import au.com.lonsec.service.company.configproperty.ConfigProperty;
import au.com.lonsec.service.company.segment.model.Segment;

/**
 * CompanyDashboardDTO contains entities support the Company Dashboard.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

public class CompanyDashboardDTO {

    private Segment segment;
    private List<ConfigProperty> propertyList;

    public CompanyDashboardDTO() {
    }

    public Segment getSegment() {
        return segment;
    }

    public void setSegment(Segment segment) {
        this.segment = segment;
    }

    public List<ConfigProperty> getPropertyList() {
        return propertyList;
    }

    public void setPropertyList(List<ConfigProperty> propertyList) {
        this.propertyList = propertyList;
    }

}
