package au.com.lonsec.service.company.companyDashboard;

import java.util.ArrayList;
import java.util.List;

import org.dozer.DozerBeanMapper;
import org.dozer.loader.api.BeanMappingBuilder;
import org.dozer.loader.api.TypeMappingBuilder;
import org.springframework.stereotype.Service;

import au.com.lonsec.service.company.companyDashboard.model.CompanyDashboardRow;
import au.com.lonsec.service.company.companyDashboard.model.SegmentAttribute;
import au.com.lonsec.service.company.configproperty.ConfigProperty;
import au.com.lonsec.service.company.segment.model.Segment;

/**
 * CompanyDashboardMapper supports mapping composite to dashboard row. 1. segment to dashboard row. 2. config
 * property to dashboard row.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

@Service
public class CompanyDashboardMapper {

    private DozerBeanMapper mapper;

    CompanyDashboardMapper() {
        mapper = new DozerBeanMapper();
        mapper.addMapping(customSegmentToCompanyDashboardMapping());
    }

    
    /**
     * @param companyDashboardDTO - segement and configuration property.
     * @param dest   CompanyDashboardRow view model.
     * @return CompanyDashboardRow view model.
     */
    public CompanyDashboardRow map(CompanyDashboardDTO companyDashboardDTO, CompanyDashboardRow dest) {
        if (companyDashboardDTO.getSegment() != null) {
            map(companyDashboardDTO.getSegment(), dest);
        }
        map(companyDashboardDTO.getPropertyList(), dest);
        return dest;
    }

    private CompanyDashboardRow map(List<ConfigProperty> propertyList, CompanyDashboardRow dest) {
        dest.setAttributes(convert(propertyList));
        return dest;
    }

    /**
     * @param propertyList segment preferences.
     * @return attributes empty list if null.
     */
    private List<SegmentAttribute> convert(List<ConfigProperty> propertyList) {
        List<SegmentAttribute> attributes = new ArrayList<SegmentAttribute>();
        for (ConfigProperty prop : propertyList) {
            attributes.add(convert(prop));
        }
        return attributes;
    }

    private SegmentAttribute convert(ConfigProperty prop) {
        SegmentAttribute segmentAttribute = new SegmentAttribute();
        segmentAttribute.setKey(prop.getKey());
        segmentAttribute.setValue(prop.getValue());
        return segmentAttribute;
    }

    private CompanyDashboardRow map(Segment source, CompanyDashboardRow dest) {
        mapper.map(source, dest);
        return dest;
    }

    private BeanMappingBuilder customSegmentToCompanyDashboardMapping() {
        List<String> excludeList = getExcludeList();
        BeanMappingBuilder builder = new BeanMappingBuilder() {
            protected void configure() {
                TypeMappingBuilder typeMappingBuilder = mapping(Segment.class, CompanyDashboardRow.class);
                excludeList.forEach(typeMappingBuilder::exclude);
            }
        };
        return builder;
    }

    private List<String> getExcludeList() {
        List<String> excludeList = new ArrayList<>();
        return excludeList;
    }

}
