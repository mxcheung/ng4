package au.com.lonsec.service.company.company.model;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Company Request DTO for company maintenance.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "companyName", "abn", "address", "parentId" })
public class Company {

    private String id;

    @NotNull(message = "Company Name must be input")
    private String companyName;

    @NotNull(message = "Abn must be input")
    private String abn;

    private String address;

    private String parentId;
    
    private String status;

    public Company() {
    }

    @JsonCreator
    public Company(@JsonProperty("companyName") String companyName, @JsonProperty("abn") String abn, @JsonProperty("address") String address,
            @JsonProperty("parentId") String parentId) {
        this.companyName = companyName;
        this.abn = abn;
        this.address = address;
        this.parentId = parentId;

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getAbn() {
        return abn;
    }

    public void setAbn(String abn) {
        this.abn = abn;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}
