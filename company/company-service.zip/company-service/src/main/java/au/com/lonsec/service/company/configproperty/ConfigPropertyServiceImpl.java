package au.com.lonsec.service.company.configproperty;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.commons.lang3.Validate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * ConfigPropertyService - stores additional properties for main entities **[COMPANY, SEGMENT, PRODUCT]**
 * entityId - Owning entity [entity primary key is UUID to provides uniqueness] ConfigPropertyType - [COMPANY,
 * SEGMENT, PRODUCT] type to describe the owning entity type.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */
@Service
public class ConfigPropertyServiceImpl implements ConfigPropertyService {

    private final ConfigPropertyRepository configPropertyRepository;

    @Autowired
    ConfigPropertyServiceImpl(final ConfigPropertyRepository configPropertyRepository) {
        this.configPropertyRepository = configPropertyRepository;
    }

    @Override
    @Transactional
    public List<ConfigProperty> updateEntityProperties(String entityId, ConfigPropertyType type, List<ConfigProperty> propertyList) {

        Validate.notBlank(entityId, "Entity identifier must be specified for updateEntityProperties.");
        Validate.notNull(type, "Entity Property Type must be specified for updateEntityProperties.");

        for (ConfigProperty property : propertyList) {
            property.setType(type);
            updateEntityProperty(entityId, property);
        }

        return propertyList;
    }

    @Override
    public List<ConfigProperty> getEntityProperties(String entityId, ConfigPropertyType type) {
        Validate.notBlank(entityId, "Entity identifier must be specified for getEntityProperty.");
        List<ConfigPropertyEntity> configurationProperties = configPropertyRepository.findByEntityIdAndPropertyType(entityId, type);
        return convertUp(configurationProperties);
    }

    private List<ConfigProperty> convertUp(List<ConfigPropertyEntity> entityProperties) {
        List<ConfigProperty> propertyEmbeddables = new ArrayList<>();
        for (ConfigPropertyEntity property : entityProperties) {
            propertyEmbeddables.add(convertUp(property));
        }
        return propertyEmbeddables;
    }

    private ConfigProperty convertUp(ConfigPropertyEntity property) {
        ConfigProperty propertyEntity = new ConfigProperty();
        propertyEntity.setType(property.getPropertyType());
        propertyEntity.setKey(property.getPropertyKey());
        propertyEntity.setValue(property.getPropertyValue());
        return propertyEntity;
    }

    private void updateEntityProperty(String entityId, ConfigProperty configProperty) throws ConfigPropertyEntityNotFoundException {
        Validate.notBlank(entityId, "Entity identifier must be specified for updateEntityProperty.");
        Validate.notBlank(configProperty.getKey(), "Entity Property Key must be specified for updateEntityProperty.");
        Validate.notNull(configProperty.getType(), "Entity Property Type must be specified for updateEntityProperty.");

        ConfigPropertyEntity propertyEntity = configPropertyRepository.findByEntityIdAndPropertyTypeAndPropertyKey(entityId, configProperty.getType(),
                configProperty.getKey());
        if (propertyEntity == null) {
            propertyEntity = new ConfigPropertyEntity();
            propertyEntity.setEntityId(entityId);
            propertyEntity.setPropertyType(configProperty.getType());
            propertyEntity.setPropertyKey(configProperty.getKey());

        }
        propertyEntity.setPropertyValue(configProperty.getValue());
        configPropertyRepository.save(propertyEntity);
    }

}