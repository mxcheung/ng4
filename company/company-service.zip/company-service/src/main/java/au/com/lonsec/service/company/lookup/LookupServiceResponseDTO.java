package au.com.lonsec.service.company.lookup;

import java.util.List;
import java.util.Map;

import au.com.lonsec.service.company.company.client.model.Trackable;
import au.com.lonsec.service.company.lookup.model.LookupValue;

/**
 * Product DTO for product maintenance.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

public class LookupServiceResponseDTO extends Trackable {

    private Long recordCount;

    private Map<String, List<LookupValue>> lookups;

    public Map<String, List<LookupValue>> getLookups() {
        return lookups;
    }

    public void setLookups(Map<String, List<LookupValue>> lookups) {
        this.lookups = lookups;
    }

    public Long getRecordCount() {
        return recordCount;
    }

    public void setRecordCount(Long recordCount) {
        this.recordCount = recordCount;
    }

}
