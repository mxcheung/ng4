package au.com.lonsec.service.company.configproperty;

import java.util.List;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * ConfigDTO DTO for storing configuration properties.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "entityId", "type", "propertyList" })
class ConfigDTO {

    @NotNull(message = "entityId must be input")
    private String entityId;

    @NotNull(message = "Config Type must be input")
    private String type;

    private List<ConfigProperty> propertyList;

    ConfigDTO() {
    }

    @JsonCreator
    ConfigDTO(@JsonProperty("entityId") String entityId, @JsonProperty("type") String type,
            @JsonProperty("propertyList") List<ConfigProperty> propertyList) {
        this.entityId = entityId;
        this.type = type;
        this.propertyList = propertyList;
    }

    public String getEntityId() {
        return entityId;
    }

    public void setEntityId(String entityId) {
        this.entityId = entityId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<ConfigProperty> getPropertyList() {
        return propertyList;
    }

    public void setPropertyList(List<ConfigProperty> propertyList) {
        this.propertyList = propertyList;
    }

}
