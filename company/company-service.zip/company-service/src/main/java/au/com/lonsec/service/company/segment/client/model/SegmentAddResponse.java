package au.com.lonsec.service.company.segment.client.model;

/**
 * SegmentAddRequest DTO for segement maintenance.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

public class SegmentAddResponse extends SegmentResponse {

    private static final long serialVersionUID = 1L;

}
