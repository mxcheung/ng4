package au.com.lonsec.service.company.company.client.model;

public class CompaniesGetResponse extends CompaniesResponse {

    private static final long serialVersionUID = 1L;

}
