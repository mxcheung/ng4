package au.com.lonsec.service.company.productDashboard;

/**
 * @author MAX see https://studio.restlet.com/apis/local/sections/Companies
 */
public final class ProductDashBoardURI {

    public static final String PRODUCT_BASE_CONTEXT = "/productdashboard";

    /* Load the list of Products */
    public static final String GET_PRODUCTS_MAPPING = "/products";
    /* Load an individual Product */
    public static final String GET_PRODUCT_MAPPING = "/product/{productId}";
    /* Create a new Product */
    public static final String POST_PRODUCTS_MAPPING = "/product";
    /* Update a Product */
    public static final String PUT_PRODUCTS_MAPPING = "/product";

    public static final String GET_PRODUCTS_SEGMENT_MAPPING = "/products/{extUniqueKey}";

    private ProductDashBoardURI() {
    }

}