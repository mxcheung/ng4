package au.com.lonsec.service.company.company.client.model;

public class CompanyGetResponse extends CompanyResponse {

    private static final long serialVersionUID = 1L;

}
