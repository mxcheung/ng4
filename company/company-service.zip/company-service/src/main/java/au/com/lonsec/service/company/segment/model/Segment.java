package au.com.lonsec.service.company.segment.model;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "companyId", "segmentCd", "extUniqueKey", "analyst", "abn", "active" })
public class Segment {

    private String id;

    @NotNull(message = "Company Id must be input")
    private String companyId;

    @NotNull(message = "segmentCd  must be input")
    private String segmentCd;

    @NotNull(message = "extUniqueKey must be input")
    private String extUniqueKey;

    private String analyst;

    private String abn;

    private String companyName;
    
    private String notes;

    private Boolean active;

    public Segment() {
    }

    @JsonCreator
    public Segment(@JsonProperty("companyId") String companyId, @JsonProperty("segmentCd") String segmentCd,
            @JsonProperty("extUniqueKey") String extUniqueKey, @JsonProperty("analyst") String analyst, @JsonProperty("abn") String abn,
            @JsonProperty("active") Boolean active) {
        this.companyId = companyId;
        this.segmentCd = segmentCd;
        this.extUniqueKey = extUniqueKey;
        this.analyst = analyst;
        this.abn = abn;
        this.active = active;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getSegmentCd() {
        return segmentCd;
    }

    public void setSegmentCd(String segmentCd) {
        this.segmentCd = segmentCd;
    }

    public String getExtUniqueKey() {
        return extUniqueKey;
    }

    public void setExtUniqueKey(String extUniqueKey) {
        this.extUniqueKey = extUniqueKey;
    }

    public String getAnalyst() {
        return analyst;
    }

    public void setAnalyst(String analyst) {
        this.analyst = analyst;
    }

    public String getAbn() {
        return abn;
    }

    public void setAbn(String abn) {
        this.abn = abn;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
    
    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

}