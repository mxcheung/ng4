package au.com.lonsec.service.company.segment;

public class SegmentNotFoundException extends Exception {

    private static final long serialVersionUID = -6022065019378181801L;

    public SegmentNotFoundException(String message) {
        super(message);
    }

}
