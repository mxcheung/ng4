package au.com.lonsec.service.company.productClassification.client.model;

/**
 * ProductClassificationGetResponse.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

public class ProductClassificationGetResponse extends ProductClassificationResponse {

    private static final long serialVersionUID = 1L;

}
