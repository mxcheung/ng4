package au.com.lonsec.service.company.productDashboard;

import static au.com.lonsec.service.company.CompanyControllerAdvice.MODEL_ATTR_PROFILE;
import static org.springframework.http.HttpStatus.OK;
import static org.springframework.web.bind.annotation.RequestMethod.GET;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import au.com.lonsec.service.company.productDashboard.client.model.ProductDashboardRowsGetResponse;
import au.com.lonsec.service.company.web.DpProfile;

/**
 * ProductController - supports crud method for product repository.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

@RestController
@Validated
@RequestMapping(value = ProductDashBoardURI.PRODUCT_BASE_CONTEXT)
public class ProductDashboardController {

    @Autowired
    private ProductDashboardService productDashboardService;

    
    @RequestMapping(value = ProductDashBoardURI.GET_PRODUCTS_MAPPING, method = GET)
    @ResponseStatus(OK)
    @ResponseBody
    public ResponseEntity<ProductDashboardRowsGetResponse> productsGet(
            @RequestHeader(value = "correlation-id", required = false) final String xRequestCorrelationID,
            @RequestHeader(value = "Authorization", required = false) final String authToken,
            @RequestHeader(value = "segmentCd", required = true) final String xRequestSegmentCd,
            @ModelAttribute(MODEL_ATTR_PROFILE) final DpProfile profile) {
        ProductDashboardRowsGetResponse result = new ProductDashboardRowsGetResponse();
        result.setCorrelationId(xRequestCorrelationID);
        result.setProductDashboardRows(productDashboardService.findProducts(xRequestSegmentCd, profile));
        return new ResponseEntity<>(result, OK);
    }
    

}
