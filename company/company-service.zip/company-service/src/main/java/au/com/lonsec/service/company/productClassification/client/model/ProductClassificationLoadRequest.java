package au.com.lonsec.service.company.productClassification.client.model;

/**
 * ProductClassificationLoadRequest for product maintenance.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

public class ProductClassificationLoadRequest {
    
    private String segmentCd;

    private String fileName;

    public String getSegmentCd() {
        return segmentCd;
    }

    public void setSegmentCd(String segmentCd) {
        this.segmentCd = segmentCd;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

}
