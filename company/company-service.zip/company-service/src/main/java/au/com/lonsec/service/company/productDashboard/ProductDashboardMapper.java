package au.com.lonsec.service.company.productDashboard;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.dozer.DozerBeanMapper;
import org.dozer.loader.api.BeanMappingBuilder;
import org.dozer.loader.api.TypeMappingBuilder;
import org.springframework.stereotype.Service;

import au.com.lonsec.service.company.product.model.Product;
import au.com.lonsec.service.company.productClassification.model.ProductClassification;
import au.com.lonsec.service.company.productDashboard.model.ProductDashboardRow;
import au.com.lonsec.service.company.segment.model.Segment;

/**
 * ProductDashboardMapper supports mapping composite to dashboard row. 1. product to dashboard row. 2. segment
 * to dashboard row. 3. product classification to dashboard row.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

@Service
public class ProductDashboardMapper {

    private static final String ASSETCLASS = "ASSETCLASS";
    private static final String PRODUCTCLASS = "PRODUCTCLASS";
    private static final String SECTOR = "SECTOR";
    private static final String SUBSECTOR = "SUBSECTOR";
    private DozerBeanMapper mapper;

    ProductDashboardMapper() {
        mapper = new DozerBeanMapper();
        mapper.addMapping(customSegmentToProductDashboardMapping());
    }

    public ProductDashboardRow map(Map<String, Map<String, String>> dataMap, ProductDashboardDTO productDashboardDTO, ProductDashboardRow dest) {

        map(productDashboardDTO.getProduct(), dest);

        if (productDashboardDTO.getProductClassification() != null) {
            map(productDashboardDTO.getProductClassification(), dest);
        }

        if (productDashboardDTO.getSegment() != null) {
            map(productDashboardDTO.getSegment(), dest);
        }
        dest.setAssetClassName(getValue(dataMap, ASSETCLASS, dest.getAssetClassName()));
        dest.setProductClassName(getValue(dataMap, PRODUCTCLASS, dest.getProductClassName()));
        dest.setSectorName(getValue(dataMap, SECTOR, dest.getSectorName()));
        dest.setSubSectorName(getValue(dataMap, SUBSECTOR, dest.getSubSectorName()));

        return dest;
    }

    private ProductDashboardRow map(Product source, ProductDashboardRow dest) {
        mapper.map(source, dest);
        dest.setNotes(source.getNotes());
        return dest;
    }

    private ProductDashboardRow map(ProductClassification source, ProductDashboardRow dest) {
        mapper.map(source, dest);
        return dest;
    }

    private ProductDashboardRow map(Segment source, ProductDashboardRow dest) {
        mapper.map(source, dest);
        return dest;
    }

    private BeanMappingBuilder customSegmentToProductDashboardMapping() {
        List<String> excludeList = getExcludeList();
        BeanMappingBuilder builder = new BeanMappingBuilder() {
            protected void configure() {
                TypeMappingBuilder typeMappingBuilder = mapping(Segment.class, ProductDashboardRow.class);
                excludeList.forEach(typeMappingBuilder::exclude);
            }
        };
        return builder;
    }

    private List<String> getExcludeList() {
        List<String> excludeList = new ArrayList<>();
        excludeList.add("active");
        excludeList.add("notes");
        return excludeList;
    }


    public String getValue(Map<String, Map<String, String>> map, String mapType, String key) {
        Map<String, String> lookup = map.get(mapType);
        String val = lookup.get(key);
        return val != null ? val : key;
    }

}
