package au.com.lonsec.service.company.company;

import java.util.UUID;

/**
 * @author Max Cheung <max.cheung@lonsec.com.au> Default method to UUID conversion. see
 *         https://docs.oracle.com/javase/tutorial/java/IandI/defaultmethods.html
 */
public interface RestUtils {

    static UUID convertUUID(String uuidString) {
        return (uuidString == null) ? null : UUID.fromString(uuidString);
    }

    static String convertUUIDToString(UUID uUID) {
        return (uUID == null) ? null : uUID.toString();
    }

}