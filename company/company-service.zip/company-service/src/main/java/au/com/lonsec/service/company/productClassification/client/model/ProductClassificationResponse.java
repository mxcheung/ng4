package au.com.lonsec.service.company.productClassification.client.model;

import au.com.lonsec.service.company.company.client.model.Trackable;
import au.com.lonsec.service.company.productClassification.model.ProductClassification;

public class ProductClassificationResponse extends Trackable {

    private static final long serialVersionUID = 1L;

    private ProductClassification productClassification;

    public ProductClassification getProductClassification() {
        return productClassification;
    }

    public void setProductClassification(ProductClassification productClassification) {
        this.productClassification = productClassification;
    }

    
}
