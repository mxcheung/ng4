package au.com.lonsec.service.company.productClassification;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductClassificationRepository extends JpaRepository<ProductClassificationEntity, Long> {

    ProductClassificationEntity findById(UUID id);

    ProductClassificationEntity findByProductId(String productId);

}