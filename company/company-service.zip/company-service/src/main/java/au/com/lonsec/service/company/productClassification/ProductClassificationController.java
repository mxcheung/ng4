package au.com.lonsec.service.company.productClassification;

import static org.springframework.http.HttpStatus.OK;
import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;

import au.com.lonsec.service.company.productClassification.client.model.ProductClassificationGetResponse;
import au.com.lonsec.service.company.productClassification.client.model.ProductClassificationLoadRequest;
import au.com.lonsec.service.company.productClassification.client.model.ProductClassificationLoadResponse;

/**
 * ProductClassificationController - supports crud method for productClassification repository.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

@RestController
@Validated
@RequestMapping(value = ProductClassificationURI.PRODUCT_CLASSIFICATION_BASE_CONTEXT)
public class ProductClassificationController {

    @Autowired
    private ProductClassificationService productClassificationService;

    @RequestMapping(value = ProductClassificationURI.GET_PRODUCT_CLASSIFICATION_MAPPING, method = GET)
    @ResponseStatus(OK)
    @ResponseBody
    public ResponseEntity<ProductClassificationGetResponse> productGet(@PathVariable(value = "productId") final String productId,
            @RequestHeader(value = "correlation-id", required = false) final String xRequestCorrelationID,
            @RequestHeader(value = "Authorization", required = false) final String authToken,
            @RequestHeader(value = "segmentCd", required = true) final String xRequestSegmentCd) throws ProductClassificationNotFoundException {
        ProductClassificationGetResponse result = new ProductClassificationGetResponse();
        result.setCorrelationId(xRequestCorrelationID);
        result.setProductClassification(productClassificationService.findProductClassification(productId));
        return new ResponseEntity<>(result, OK);
    }

    @RequestMapping(value = ProductClassificationURI.PRODUCT_CLASSIFICATION_REFRESH, method = POST)
    @ResponseStatus(OK)
    @ResponseBody
    public ResponseEntity<ProductClassificationLoadResponse> productClassificationRefresh(
            @Valid @RequestBody final ProductClassificationLoadRequest productClassificationLoadRequest,
            @RequestHeader(value = "correlation-id", required = false) final String xRequestCorrelationID)
            throws JsonProcessingException, FileNotFoundException, IOException {
        ProductClassificationLoadResponse result = new ProductClassificationLoadResponse();
        result.setCorrelationId(xRequestCorrelationID);
        List<ProductClassificationEntity> productClassifications = productClassificationService
                .productClassificationLoad(productClassificationLoadRequest);
        result.setRecordCount((long) productClassifications.size());
        return new ResponseEntity<>(result, OK);
    }

}
