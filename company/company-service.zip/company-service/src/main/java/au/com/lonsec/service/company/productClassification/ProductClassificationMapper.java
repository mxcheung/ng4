package au.com.lonsec.service.company.productClassification;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.dozer.DozerBeanMapper;
import org.springframework.stereotype.Service;

import au.com.lonsec.service.company.product.model.Product;
import au.com.lonsec.service.company.productClassification.model.ProductClassification;

/**
 * ProductClassificationMapper supports mapping. 1. row to entity. 2. entity to model
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

@Service
public class ProductClassificationMapper {

    private static final int ASSETCLASS_TIER = 1;
    private static final int SECTOR_TIER = 2;
    private static final int SUBSECTOR_TIER = 3;
    private static final int HIERARCHY_LENGTH = 3;
    private DozerBeanMapper mapper = new DozerBeanMapper();

    public ProductClassificationEntity map(ProductClassificationRow source, ProductClassificationEntity dest) {
        mapper.map(source, dest);
        return dest;
    }

    public ProductClassification map(ProductClassificationEntity source, ProductClassification dest) {
        mapper.map(source, dest);
        dest.setProductClassName(source.getProductClass());
        return dest;
    }

    /**
     * Map classification details to product.
     * 
     * @param source Product Classification for external source.
     * @param dest Product.
     * @return Product with updated product classification fields.
     */
    public Product map(ProductClassificationEntity source, Product dest) {
        mapper.map(source, dest);
        dest.setAssetClassCd(source.getAssetClassName());
        dest.setSectorCd(source.getSectorName());
        dest.setSubSectorCd(source.getSubSectorName());
        dest.setProductClassCd(source.getProductClass());
        dest = deriveClassification(dest, source.getSubSectorName());
        return dest;
    }

    public Product deriveClassification(Product product, String productHierarchy) {
        String[] hierarchy = StringUtils.split(productHierarchy, ":");
        List<String> hierarchyList = Optional.ofNullable(hierarchy).map(Arrays::stream).orElseGet(Stream::empty).collect(Collectors.toList());
        product.setAssetClassCd(getClassificationPart(hierarchyList, ASSETCLASS_TIER));
        product.setSectorCd(getClassificationPart(hierarchyList, SECTOR_TIER));
        product.setSubSectorCd(getClassificationPart(hierarchyList, SUBSECTOR_TIER));
        return product;
    }

    /**
     * @param hierarchy product hierarchy [AEQ | ALP | AR].
     * @param tier hierarchy tier { AEQ | AEQ:ALP |AEQ:ALP:ALP }
     * @return product hierarchy or empty string if tier is not available
     */
    public String getClassificationPart(List<String> hierarchy, int tier) {
        int idx = tier <= hierarchy.size() ? tier : 0;
        return hierarchy.subList(0, idx).stream().map(n -> n.toString()).collect(Collectors.joining(":"));
    }

}
