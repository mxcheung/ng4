package au.com.lonsec.service.company.company;

public class CompanyNotFoundException extends Exception {

    private static final long serialVersionUID = -6022065019378181801L;

    public CompanyNotFoundException(String message) {
        super(message);
    }

}
