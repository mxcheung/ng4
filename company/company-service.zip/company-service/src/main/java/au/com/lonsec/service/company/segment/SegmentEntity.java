package au.com.lonsec.service.company.segment;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.validator.constraints.NotEmpty;

import au.com.lonsec.service.company.base.AbstractEntity;

/**
 * Segment model representation for company. Segment decorates the company entity to form the logical company
 * for the business segment.
 * 
 * @author MCheung
 */
@Entity
@Table(name = "segment", uniqueConstraints = { @UniqueConstraint(columnNames = { "segmentCd", "extUniqueKey" }) })
public class SegmentEntity extends AbstractEntity {

    @NotEmpty
    private String companyId;

    @NotEmpty
    private String segmentCd;

    @NotEmpty
    private String extUniqueKey;

    private String analyst;

    private String abn;

    private String companyName;
    
    private String notes;

    private Boolean active = true;
    
    public SegmentEntity() {
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getSegmentCd() {
        return segmentCd;
    }

    public void setSegmentCd(String segmentCd) {
        this.segmentCd = segmentCd;
    }

    public String getExtUniqueKey() {
        return extUniqueKey;
    }

    public void setExtUniqueKey(String extUniqueKey) {
        this.extUniqueKey = extUniqueKey;
    }

    public String getAnalyst() {
        return analyst;
    }

    public void setAnalyst(String analyst) {
        this.analyst = analyst;
    }

    public String getAbn() {
        return abn;
    }

    public void setAbn(String abn) {
        this.abn = abn;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

}
