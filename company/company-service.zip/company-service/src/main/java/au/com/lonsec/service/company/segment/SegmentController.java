package au.com.lonsec.service.company.segment;

import static org.springframework.http.HttpStatus.ACCEPTED;
import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.HttpStatus.OK;
import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;
import static org.springframework.web.bind.annotation.RequestMethod.PUT;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import au.com.lonsec.service.company.segment.client.model.SegmentAddResponse;
import au.com.lonsec.service.company.segment.client.model.SegmentGetResponse;
import au.com.lonsec.service.company.segment.client.model.SegmentRequest;
import au.com.lonsec.service.company.segment.client.model.SegmentUpdateRequest;
import au.com.lonsec.service.company.segment.client.model.SegmentUpdateResponse;
import au.com.lonsec.service.company.segment.client.model.SegmentsGetResponse;

/**
 * SegmentController - supports crud method for segment repository.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

@RestController
@Validated
@RequestMapping(value = SegmentURI.SEGMENT_BASE_CONTEXT)
public class SegmentController {

    @Autowired
    private SegmentService segmentService;

    @RequestMapping(value = SegmentURI.GET_SEGMENT_MAPPING, method = GET)
    @ResponseStatus(OK)
    @ResponseBody
    public ResponseEntity<SegmentGetResponse> segmentGet(@PathVariable("extUniqueKey") String extUniqueKey,
            @RequestHeader(value = "correlation-id", required = false) final String xRequestCorrelationID,
            @RequestHeader(value = "Authorization", required = false) final String authToken,
            @RequestHeader(value = "segmentCd", required = true) final String xRequestSegmentCd) throws SegmentNotFoundException {

        SegmentGetResponse result = new SegmentGetResponse();
        result.setCorrelationId(xRequestCorrelationID);
        result.setSegment(segmentService.findSegment(xRequestSegmentCd, extUniqueKey));
        return new ResponseEntity<>(result, OK);
    }

    @RequestMapping(value = SegmentURI.GET_SEGMENTS_MAPPING, method = GET)
    @ResponseStatus(OK)
    @ResponseBody
    public ResponseEntity<SegmentsGetResponse> segmentsGet(
            @RequestHeader(value = "correlation-id", required = false) final String xRequestCorrelationID,
            @RequestHeader(value = "Authorization", required = false) final String authToken,
            @RequestHeader(value = "segmentCd", required = true) final String xRequestSegmentCd) throws SegmentNotFoundException {

        SegmentsGetResponse result = new SegmentsGetResponse();
        result.setCorrelationId(xRequestCorrelationID);
        result.setSegments(segmentService.findSegment(xRequestSegmentCd));
        return new ResponseEntity<>(result, OK);
    }

    @RequestMapping(value = SegmentURI.GET_SEGMENTS_BY_COMPANYNAME_MAPPING, method = GET)
    @ResponseStatus(OK)
    @ResponseBody
    public ResponseEntity<SegmentsGetResponse> findByCompanyNameContaining(
            @RequestHeader(value = "correlation-id", required = false) final String xRequestCorrelationID,
            @RequestHeader(value = "Authorization", required = false) final String authToken,
            @RequestHeader(value = "segmentCd", required = true) final String xRequestSegmentCd, @RequestParam("companyName") String companyName)
            throws SegmentNotFoundException {
        SegmentsGetResponse result = new SegmentsGetResponse();
        result.setCorrelationId(xRequestCorrelationID);
        result.setSegments(segmentService.findByCompanyNameContaining(xRequestSegmentCd, companyName));
        return new ResponseEntity<>(result, OK);
    }

    @RequestMapping(value = SegmentURI.POST_SEGMENTS_MAPPING, method = POST)
    @ResponseStatus(CREATED)
    @ResponseBody
    public ResponseEntity<SegmentAddResponse> segmentAdd(
            @RequestHeader(value = "correlation-id", required = false) final String xRequestCorrelationID,
            @RequestHeader(value = "Authorization", required = false) final String authToken,
            @RequestHeader(value = "segmentCd", required = true) final String xRequestSegmentCd,
            @Valid @RequestBody final SegmentRequest segmentDTO) {
        SegmentAddResponse result = new SegmentAddResponse();
        result.setCorrelationId(xRequestCorrelationID);
        result.setSegment(segmentService.createSegment(segmentDTO));
        return new ResponseEntity<>(result, CREATED);
    }

    @RequestMapping(value = SegmentURI.PUT_SEGMENTS_MAPPING, method = PUT)
    @ResponseStatus(ACCEPTED)
    @ResponseBody
    public ResponseEntity<SegmentUpdateResponse> updateSegment(@PathVariable("extUniqueKey") String extUniqueKey,
            @RequestHeader(value = "correlation-id", required = false) final String xRequestCorrelationID,
            @RequestHeader(value = "Authorization", required = false) final String authToken,
            @RequestHeader(value = "segmentCd", required = true) final String xRequestSegmentCd,
            @Valid @RequestBody final SegmentUpdateRequest segmentUpdateRequest) throws SegmentNotFoundException {
        SegmentUpdateResponse result = new SegmentUpdateResponse();
        result.setCorrelationId(xRequestCorrelationID);
        result.setSegment(segmentService.updateSegment(xRequestSegmentCd, extUniqueKey, segmentUpdateRequest));
        return new ResponseEntity<>(result, ACCEPTED);
    }

}
