package au.com.lonsec.service.company.segment;

/**
 * @author MAX see https://studio.restlet.com/apis/local/sections/Companies
 */
public final class SegmentURI {

    public static final String SEGMENT_BASE_CONTEXT = "/segments";

    /* Load the list of Segments */
    public static final String GET_SEGMENTS_MAPPING = "/segments";
    /* Load an individual Segments */
    public static final String GET_SEGMENT_MAPPING = "/segment/{extUniqueKey}";
    /* Create a new Segments */
    public static final String POST_SEGMENTS_MAPPING = "/segment";
    /* Update a Segments */
    public static final String PUT_SEGMENTS_MAPPING = "/segment/{extUniqueKey}";

    // Load the list of Segments where company name contains
    public static final String GET_SEGMENTS_BY_COMPANYNAME_MAPPING = "/segments/company";

    private SegmentURI() {
    }
}
