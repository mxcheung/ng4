package au.com.lonsec.service.company.company;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

import au.com.lonsec.service.company.base.AbstractEntity;

/**
 * Company Model representation for company
 * 
 * @author MCheung
 */
/**
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */
@Entity
@Table(name = "company")
public class CompanyEntity extends AbstractEntity {

    @NotEmpty
    @Column(name = "company_name")
    private String companyName;

    @NotEmpty
    @Column(name = "abn", unique = true)
    private String abn;

    @Column(name = "address")
    private String address;

    @Column(name = "parent_id")
    private UUID parentId;

    public CompanyEntity() {
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getAbn() {
        return abn;
    }

    public void setAbn(String abn) {
        this.abn = abn;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public UUID getParentId() {
        return parentId;
    }

    public void setParentId(UUID parentId) {
        this.parentId = parentId;
    }

}
