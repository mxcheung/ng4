package au.com.lonsec.service.company.companyDashboard;

import static org.springframework.http.HttpStatus.OK;
import static org.springframework.web.bind.annotation.RequestMethod.GET;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import au.com.lonsec.service.company.companyDashboard.client.model.CompanyDashboardRowsGetResponse;


/**
 * CompanyDashboardController - supports view model.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

@RestController
@Validated
@RequestMapping(value = CompanyDashBoardURI.COMPANY_BASE_CONTEXT)
public class CompanyDashboardController {

    @Autowired
    private CompanyDashboardService companyDashboardService;

    
    @RequestMapping(value = CompanyDashBoardURI.GET_COMPANIES_MAPPING, method = GET)
    @ResponseStatus(OK)
    @ResponseBody
    public ResponseEntity<CompanyDashboardRowsGetResponse> companiesGet(
            @RequestHeader(value = "correlation-id", required = false) final String xRequestCorrelationID,
            @RequestHeader(value = "Authorization", required = false) final String authToken,
            @RequestHeader(value = "segmentCd", required = true) final String xRequestSegmentCd) {
        CompanyDashboardRowsGetResponse result = new CompanyDashboardRowsGetResponse();
        result.setCorrelationId(xRequestCorrelationID);
        result.setCompanyDashboardRows(companyDashboardService.findCompanies(xRequestSegmentCd));
        return new ResponseEntity<>(result, OK);
    }
    

}
