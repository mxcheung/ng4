package au.com.lonsec.service.company.configproperty;

import java.util.List;

public interface ConfigPropertyService {

    /**
     * Replacing the all the properties with specified type for the Entity.
     *
     * @param entityId entity that own the properties.
     * @param type **[COMPANY, SEGMENT, PRODUCT].
     * @param propertyList **list of key value pairs.
     * @return propertyList.
     */

    List<ConfigProperty> updateEntityProperties(String entityId, ConfigPropertyType type, List<ConfigProperty> propertyList);

    List<ConfigProperty> getEntityProperties(String entityId, ConfigPropertyType type);

}