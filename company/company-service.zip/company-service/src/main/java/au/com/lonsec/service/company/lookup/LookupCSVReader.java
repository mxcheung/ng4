package au.com.lonsec.service.company.lookup;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.databind.ObjectReader;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;

/**
 * LookupCSVReader to load lookups.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

@Service
public class LookupCSVReader {

    @Value("${lookup.folder}")
    private String lookupFolder;

    private final CsvMapper mapper = new CsvMapper();
    private final CsvSchema schema = mapper.schemaFor(LookupRow.class);

    public ArrayList<LookupRow> readLookup(String filename) throws FileNotFoundException, IOException {
        InputStream inputStream = new FileInputStream(getFile(filename));
        return readLookup(inputStream);
    }

    public ArrayList<LookupRow> readLookup(InputStream inputStream) throws FileNotFoundException, IOException {
        ArrayList<LookupRow> rows = new ArrayList<LookupRow>();
        Reader reader = getReader(inputStream);
        ObjectReader oReader = mapper.readerFor(LookupRow.class).with(schema);
        MappingIterator<?> mi = oReader.readValues(reader);
        while (mi.hasNext()) {
            rows.add((LookupRow) mi.next());
        }
        return rows;
    }

    public Reader getReader(InputStream inputStream) throws FileNotFoundException {
        Reader reader = new InputStreamReader(inputStream);
        return reader;
    }

    public File getFile(String fileName) throws UnsupportedEncodingException {
        return new File(URLDecoder.decode(lookupFolder + fileName, "UTF-8"));
    }

    public String getLookupFolder() {
        return lookupFolder;
    }

    public void setLookupFolder(String lookupFolder) {
        this.lookupFolder = lookupFolder;
    }

}
