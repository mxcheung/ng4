package au.com.lonsec.service.company.segment.client.model;

import au.com.lonsec.service.company.segment.model.Segment;

public class SegmentRequest extends Segment {

    private static final long serialVersionUID = 1L;

}
