package au.com.lonsec.service.company.configproperty;

import java.io.Serializable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class ConfigProperty implements Serializable {
    private static final long serialVersionUID = 1L;

    private String key;
    private String value;
    private ConfigPropertyType type;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public ConfigPropertyType getType() {
        return type;
    }

    public void setType(ConfigPropertyType type) {
        this.type = type;
    }

    @Override
    public boolean equals(Object other) {
        if (!(other instanceof ConfigProperty)) {
            return false;
        }
        ConfigProperty castOther = (ConfigProperty) other;
        return new EqualsBuilder().append(this.key, castOther.key).append(this.type, castOther.type).isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(this.key).append(this.type).toHashCode();
    }

    public String toString() {
        return new ToStringBuilder(this).append("key", this.key).append("type", this.type).append("value", this.value).toString();
    }

}
