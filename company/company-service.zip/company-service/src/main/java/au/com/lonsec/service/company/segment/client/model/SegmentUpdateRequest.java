package au.com.lonsec.service.company.segment.client.model;

/**
 * SegmentUpdateRequest DTO for segement maintenance.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

public class SegmentUpdateRequest extends SegmentRequest {

    private static final long serialVersionUID = 1L;

}
