package au.com.lonsec.service.company.configproperty;

import java.util.List;

class ConfigurationServiceResponseDTO {

    private String entityId;

    private String type;

    private List<ConfigProperty> propertyList;

    public String getEntityId() {
        return entityId;
    }

    public void setEntityId(String entityId) {
        this.entityId = entityId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<ConfigProperty> getPropertyList() {
        return propertyList;
    }

    public void setPropertyList(List<ConfigProperty> propertyList) {
        this.propertyList = propertyList;
    }

}
