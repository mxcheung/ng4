package au.com.lonsec.service.company.product.client.model;

import au.com.lonsec.service.company.product.model.Product;

public class ProductRequest extends Product {

    private static final long serialVersionUID = 1L;

}
