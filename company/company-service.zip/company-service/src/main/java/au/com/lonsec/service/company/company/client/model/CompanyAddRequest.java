package au.com.lonsec.service.company.company.client.model;

/**
 * Company CompanyAddRequest for company maintenance.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

public class CompanyAddRequest extends CompanyRequest {

    private static final long serialVersionUID = 1L;

}
