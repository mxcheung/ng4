package au.com.lonsec.service.company.product.client.model;

import javax.validation.constraints.NotNull;

/**
 * ProductAddRequest for product maintenance.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

public class ProductUpdateRequest extends ProductRequest {

    @NotNull(message = "Id must be input")
    private String id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
