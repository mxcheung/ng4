package au.com.lonsec.service.company.segment;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import au.com.lonsec.service.company.company.RestUtils;
import au.com.lonsec.service.company.segment.client.model.SegmentRequest;
import au.com.lonsec.service.company.segment.client.model.SegmentUpdateRequest;
import au.com.lonsec.service.company.segment.model.Segment;

/**
 * SegmentService - supports crud method for segment repository.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

@Service
public class SegmentService {

    private static final Logger LOGGER = LoggerFactory.getLogger(SegmentService.class);

    private final SegmentRepository segmentRepository;

    @Autowired
    SegmentService(SegmentRepository segmentRepository) {
        this.segmentRepository = segmentRepository;
    }

    /**
     * Create Segment will attempt to match existing on segmentCd , ExtUniqueKey -- aka (company id for that
     * segment). If no matching Segment then proceed with Segment creation
     * 
     * @param segmentDTO Add request
     * @return SegmentEntity
     */
    public Segment createSegment(SegmentRequest segmentDTO) {
        return convertUp(save(segmentDTO, findOrCreate(segmentDTO)));
    }

    /**
     * Update Segment validate entity exists using primary key. If no matching company then throw
     * SegmentNotFoundException
     * 
     * @param extUniqueKey Unique key for segment.
     * @param xRequestSegmentCd Segment Code.
     * @param segmentUpdateRequest Update request including primary key
     * @return SegmentEntity
     * @throws SegmentNotFoundException Unable to locate entity via primary key
     */
    public Segment updateSegment(String xRequestSegmentCd, String extUniqueKey, SegmentUpdateRequest segmentUpdateRequest)
            throws SegmentNotFoundException {
        return convertUp(save(segmentUpdateRequest, findOrThrow(xRequestSegmentCd, extUniqueKey)));
    }

    private SegmentEntity findOrThrow(String segmentCd, String extUniqueKey) throws SegmentNotFoundException {
        SegmentEntity result = segmentRepository.findBySegmentCdAndExtUniqueKey(segmentCd, extUniqueKey);
        if (result == null) {
            throw new SegmentNotFoundException(String.format("Unable to locate segment segmentCd: %s extUniqueKey: %s", segmentCd, extUniqueKey));
        }
        return result;
    }

    private SegmentEntity findOrCreate(SegmentRequest segmentDTO) {
        SegmentEntity segment = segmentRepository.findBySegmentCdAndExtUniqueKey(segmentDTO.getSegmentCd(), segmentDTO.getExtUniqueKey());

        if (segment == null) {
            segment = new SegmentEntity();
        }
        return segment;
    }

    private SegmentEntity save(SegmentRequest segmentDTO, SegmentEntity segment) {
        segment.setCompanyId(segmentDTO.getCompanyId());
        segment.setSegmentCd(segmentDTO.getSegmentCd());
        segment.setExtUniqueKey(segmentDTO.getExtUniqueKey());
        segment.setAnalyst(segmentDTO.getAnalyst());
        segment.setAbn(segmentDTO.getAbn());
        segment.setCompanyName(segmentDTO.getCompanyName());
        segment.setNotes(segmentDTO.getNotes());
        segmentRepository.save(segment);
        LOGGER.info("Segment created :", segment);
        return segment;
    }

    private SegmentEntity findSegmentByKey(String segmentCd, String extUniqueKey) {
        return segmentRepository.findBySegmentCdAndExtUniqueKey(segmentCd, extUniqueKey);
    }

    public Segment findSegment(String segmentCd, String extUniqueKey) throws SegmentNotFoundException {
        SegmentEntity segment = findSegmentByKey(segmentCd, extUniqueKey);
        if (segment == null) {
            throw new SegmentNotFoundException(String.format("Unable to locate segment segmentCd: %s extUniqueKey: %s", segmentCd, extUniqueKey));
        }
        return convertUp(segment);
    }

    public List<Segment> findSegment(String segmentCd) {
        return convertUp(segmentRepository.findBySegmentCd(segmentCd));

    }

    public List<Segment> findByCompanyNameContaining(String segmentCd, String companyName) {
        return convertUp(segmentRepository.findBySegmentCdAndCompanyNameContainingIgnoreCase(segmentCd, companyName));

    }

    public List<Segment> convertUp(List<SegmentEntity> entityProperties) {
        List<Segment> propertyEmbeddables = new ArrayList<>();
        for (SegmentEntity property : entityProperties) {
            propertyEmbeddables.add(convertUp(property));
        }
        return propertyEmbeddables;
    }

    private Segment convertUp(SegmentEntity segmentEntity) {
        Segment segment = new Segment();
        segment.setId(RestUtils.convertUUIDToString(segmentEntity.getId()));
        segment.setCompanyId(segmentEntity.getCompanyId());
        segment.setSegmentCd(segmentEntity.getSegmentCd());
        segment.setExtUniqueKey(segmentEntity.getExtUniqueKey());
        segment.setAnalyst(segmentEntity.getAnalyst());
        segment.setAbn(segmentEntity.getAbn());
        segment.setCompanyName(segmentEntity.getCompanyName());
        segment.setNotes(segmentEntity.getNotes());
        segment.setActive(segmentEntity.getActive());
        return segment;
    }

}