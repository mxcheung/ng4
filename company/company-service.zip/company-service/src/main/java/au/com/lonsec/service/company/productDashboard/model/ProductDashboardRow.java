package au.com.lonsec.service.company.productDashboard.model;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Product DTO for product maintenance.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "extUniqueKey", "productName", "productId", "apirCd", "segmentCd" })
public class ProductDashboardRow {

    private String id;

    @NotNull(message = "Segment Id must be input")
    private String segmentId;

    @NotNull(message = "Product Name must be input")
    private String productName;

    @NotNull(message = "Product Id must be input")
    private String productId;

    @NotNull(message = "segmentCd  must be input")
    private String segmentCd;

    @NotNull(message = "extUniqueKey must be input")
    private String extUniqueKey;

    private String apirCd;

    private String productType;

    private String researchPlan;

    private String sectorLead;

    private String notes;

    private String asxCd;
    private String assetClassCd;
    private String assetClassName;
    private String sectorCd;
    private String sectorName;
    private String subSectorCd;
    private String subSectorName;
    private String productClassCd;
    private String productClassName;
    private String companyName;
    private String analyst;
    private Boolean active;

    public ProductDashboardRow() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSegmentId() {
        return segmentId;
    }

    public void setSegmentId(String segmentId) {
        this.segmentId = segmentId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getSegmentCd() {
        return segmentCd;
    }

    public void setSegmentCd(String segmentCd) {
        this.segmentCd = segmentCd;
    }

    public String getExtUniqueKey() {
        return extUniqueKey;
    }

    public void setExtUniqueKey(String extUniqueKey) {
        this.extUniqueKey = extUniqueKey;
    }

    public String getApirCd() {
        return apirCd;
    }

    public void setApirCd(String apirCd) {
        this.apirCd = apirCd;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getResearchPlan() {
        return researchPlan;
    }

    public void setResearchPlan(String researchPlan) {
        this.researchPlan = researchPlan;
    }

    public String getSectorLead() {
        return sectorLead;
    }

    public void setSectorLead(String sectorLead) {
        this.sectorLead = sectorLead;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getAsxCd() {
        return asxCd;
    }

    public void setAsxCd(String asxCd) {
        this.asxCd = asxCd;
    }

    public String getAssetClassCd() {
        return assetClassCd;
    }

    public void setAssetClassCd(String assetClassCd) {
        this.assetClassCd = assetClassCd;
    }

    public String getAssetClassName() {
        return assetClassName;
    }

    public void setAssetClassName(String assetClassName) {
        this.assetClassName = assetClassName;
    }

    public String getSectorCd() {
        return sectorCd;
    }

    public void setSectorCd(String sectorCd) {
        this.sectorCd = sectorCd;
    }

    public String getSectorName() {
        return sectorName;
    }

    public void setSectorName(String sectorName) {
        this.sectorName = sectorName;
    }

    public String getSubSectorCd() {
        return subSectorCd;
    }

    public void setSubSectorCd(String subSectorCd) {
        this.subSectorCd = subSectorCd;
    }

    public String getSubSectorName() {
        return subSectorName;
    }

    public void setSubSectorName(String subSectorName) {
        this.subSectorName = subSectorName;
    }

    public String getProductClassCd() {
        return productClassCd;
    }

    public void setProductClassCd(String productClassCd) {
        this.productClassCd = productClassCd;
    }

    public String getProductClassName() {
        return productClassName;
    }

    public void setProductClassName(String productClassName) {
        this.productClassName = productClassName;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getAnalyst() {
        return analyst;
    }

    public void setAnalyst(String analyst) {
        this.analyst = analyst;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }


    
}
