package au.com.lonsec.service.company.company.client.model;

/**
 * Company CompanyUpdateRequest for company maintenance.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

public class CompanyUpdateRequest extends CompanyRequest {

    private static final long serialVersionUID = 1L;

}
