package au.com.lonsec.service.company.productClassification;

public class ProductClassificationNotFoundException extends Exception {

    private static final long serialVersionUID = -6022065019378181801L;

    public ProductClassificationNotFoundException(String message) {
        super(message);
    }

}
