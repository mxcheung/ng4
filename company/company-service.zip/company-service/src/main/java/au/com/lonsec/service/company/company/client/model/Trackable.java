package au.com.lonsec.service.company.company.client.model;

public abstract class Trackable {

    private String correlationId;

    public Trackable() {
        super();
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

}