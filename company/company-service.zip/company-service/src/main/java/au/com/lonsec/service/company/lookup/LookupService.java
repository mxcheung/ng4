package au.com.lonsec.service.company.lookup;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import au.com.lonsec.service.company.lookup.model.LookupValue;

/**
 * Lookup service supports the maintenance of the lookup repository. Main usage: 1. Fetch lookups based on a
 * shopping 2. Refresh lookup, refreshes repository using file based resource.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

@Service
public class LookupService {

    private final LookupRepository lookUpRepository;
    private final LookupCSVReader lookupCSVReader;

    @Autowired
    LookupService(LookupRepository lookUpRepository, LookupCSVReader lookupCSVReader) {
        this.lookUpRepository = lookUpRepository;
        this.lookupCSVReader = lookupCSVReader;
    }

    public Map<String, List<LookupValue>> fetchLookupByType(LookupGetRequest lookupGetRequest) {
        List<String> shoppingList = lookupGetRequest.getShoppingList();
        final String looktype = lookupGetRequest.getLookupType();
        return fetchLookups(shoppingList, looktype);
    }

    public Map<String, Map<String, String>> convertToMap(Map<String, List<LookupValue>> lookups) {
        Map<String, Map<String, String>> returnMap = new HashMap<>();
        lookups.entrySet().stream().forEach(e -> returnMap.put(e.getKey(), convertToMap(e.getValue())));
        return returnMap;
    }

    private Map<String, String> convertToMap(List<LookupValue> lookup) {
        return lookup.stream().collect(Collectors.toMap(LookupValue::getKey, item -> item.getValue()));
    }

    public List<LookupEntity> lookupLoad(LookupLoadRequest lookupLoadRequest) throws FileNotFoundException, IOException {
        ArrayList<LookupRow> data = lookupCSVReader.readLookup(lookupLoadRequest.getFileName());
        List<LookupEntity> lookupList = convertDown(data);
        save(lookupList);
        return lookupList;
    }

    @Transactional
    void save(List<LookupEntity> newList) {
        lookUpRepository.deleteAll();
        lookUpRepository.save(newList);
    }

    private Map<String, List<LookupValue>> fetchLookups(List<String> shoppingList, final String looktype) {
        return shoppingList.stream().collect(Collectors.toMap(looktypeName -> looktypeName, looktypeName -> addLookup(looktype, looktypeName)));
    }

    private List<LookupValue> addLookup(final String looktype, String looktypeName) {
        return convertUp(lookUpRepository.findByLookupTypeAndLookupTypeName(looktype, looktypeName));
    }

    public List<LookupEntity> convertDown(List<LookupRow> rows) {
        return rows.stream().map(row -> convertDown(row)).collect(Collectors.toList());
    }

    private LookupEntity convertDown(LookupRow lookupRow) {
        LookupEntity lookUpEntity = new LookupEntity();
        lookUpEntity.setEntityId(lookupRow.getEntityId());
        lookUpEntity.setLookupType(lookupRow.getLooktype());
        lookUpEntity.setLookupTypeName(lookupRow.getLooktypeName());
        lookUpEntity.setLookupCode(lookupRow.getCode());
        lookUpEntity.setLookupValue(lookupRow.getValue());
        lookUpEntity.setParentCode(lookupRow.getParentCode());
        return lookUpEntity;
    }

    public List<LookupValue> convertUp(List<LookupEntity> entityProperties) {
        List<LookupValue> propertyEmbeddables = new ArrayList<>();
        for (LookupEntity property : entityProperties) {
            propertyEmbeddables.add(convertUp(property));
        }
        return propertyEmbeddables;
    }

    private LookupValue convertUp(LookupEntity lookupEntity) {
        LookupValue lookupValue = new LookupValue();
        lookupValue.setKey(lookupEntity.getLookupCode());
        lookupValue.setValue(lookupEntity.getLookupValue());
        lookupValue.setParentCode(lookupEntity.getParentCode());
        return lookupValue;
    }

}
