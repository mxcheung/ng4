package au.com.lonsec.service.company.productClassification;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import au.com.lonsec.service.company.product.ProductNotFoundException;
import au.com.lonsec.service.company.product.ProductService;
import au.com.lonsec.service.company.product.model.Product;
import au.com.lonsec.service.company.productClassification.client.model.ProductClassificationLoadRequest;
import au.com.lonsec.service.company.productClassification.model.ProductClassification;

/**
 * ProductClassification service supports the maintenance of the ProductClassification repository. Main usage:
 * 1. Fetch ProductClassification based on a product id. 2. Refresh ProductClassification, refreshes
 * repository using file based resource.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

@Service
public class ProductClassificationService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ProductClassificationService.class);

    private final ProductClassificationRepository productClassificationRepository;
    private final ProductClassificationCSVReader productClassificationCSVReader;
    private final ProductClassificationMapper productClassificationMapper;
    private final ProductService productService;

    @Autowired
    public ProductClassificationService(ProductClassificationRepository productClassificationRepository,
            ProductClassificationCSVReader productClassificationCSVReader, ProductClassificationMapper productClassificationMapper,
            ProductService productService) {
        this.productClassificationRepository = productClassificationRepository;
        this.productClassificationCSVReader = productClassificationCSVReader;
        this.productClassificationMapper = productClassificationMapper;
        this.productService = productService;

    }

    /**
     * Load product classifications from external source.
     *
     * @param productClassificationLoadRequest load from external source.
     * @return the newly loaded product classifications.
     * @throws FileNotFoundException unable to location product classification file.
     * @throws IOException Exception reading product classification file.
     */
    public List<ProductClassificationEntity> productClassificationLoad(ProductClassificationLoadRequest productClassificationLoadRequest)
            throws FileNotFoundException, IOException {
        ArrayList<ProductClassificationRow> data = productClassificationCSVReader
                .readProductClassification(productClassificationLoadRequest.getFileName());
        List<ProductClassificationEntity> productClassificationList = convertDown(productClassificationLoadRequest.getSegmentCd(), data);
        save(productClassificationList);
        updateProductClassifications(productClassificationLoadRequest.getSegmentCd(), productClassificationList);
        return productClassificationList;
    }

    private void updateProductClassifications(String segmentCd,
            List<ProductClassificationEntity> productClassificationList) {
        productClassificationList.stream().forEach(
                (productClassification) -> updateProductClassification(segmentCd, productClassification));
    }

    private void updateProductClassification(String segmentCd, ProductClassificationEntity productClassification) {
        Product product = productClassificationMapper.map(productClassification, new Product());
        try {
            productService.updateProductClassification(segmentCd, product.getProductId(), product);
        } catch (ProductNotFoundException e) {
            LOGGER.info("Skipping .... unable to locate product :", product.getProductId());
        }
    }

    public ProductClassification findProductClassification(String productId) throws ProductClassificationNotFoundException {
        ProductClassificationEntity productClassificationEntity = productClassificationRepository.findByProductId(productId);
        if (productClassificationEntity == null) {
            throw new ProductClassificationNotFoundException(String.format("Unable to locate product classification productId: %s", productId));
        }
        return convertUp(productClassificationEntity);
    }

    @Transactional
    void save(List<ProductClassificationEntity> newList) {
        productClassificationRepository.deleteAll();
        productClassificationRepository.save(newList);
    }

    public List<ProductClassificationEntity> convertDown(String segmentCd, List<ProductClassificationRow> rows) {
        return rows.stream().map(row -> convertDown(segmentCd, row)).collect(Collectors.toList());
    }

    private ProductClassificationEntity convertDown(String segmentCd, ProductClassificationRow productClassificationRow) {
        ProductClassificationEntity productClassificationEntity = new ProductClassificationEntity();
        productClassificationEntity.setSegmentCd(segmentCd);
        return productClassificationMapper.map(productClassificationRow, productClassificationEntity);
    }

    public List<ProductClassification> convertUp(List<ProductClassificationEntity> entityList) {
        return entityList.stream().map(entity -> convertUp(entity)).collect(Collectors.toList());
    }

    public ProductClassification convertUp(ProductClassificationEntity productClassificationEntity) {
        return productClassificationMapper.map(productClassificationEntity, new ProductClassification());
    }

}
