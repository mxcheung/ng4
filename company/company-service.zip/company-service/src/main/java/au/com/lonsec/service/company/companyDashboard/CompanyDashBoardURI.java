package au.com.lonsec.service.company.companyDashboard;

/**
 * @author MAX see https://studio.restlet.com/apis/local/sections/Companies
 */
public final class CompanyDashBoardURI {

    public static final String COMPANY_BASE_CONTEXT = "/companydashboard";

    /* Load the list of Companies */
    public static final String GET_COMPANIES_MAPPING = "/companies";

    private CompanyDashBoardURI() {
    }

}