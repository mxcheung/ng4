package au.com.lonsec.service.company.lookup.client.model;

import java.util.List;
import java.util.Map;

import au.com.lonsec.service.company.lookup.model.LookupValue;

public class LookupContactResponse {
    private static final long serialVersionUID = 1L;

    private Map<String, List<LookupValue>> lookupMap;

    public Map<String, List<LookupValue>> getLookupMap() {
        return lookupMap;
    }

    public void setLookupMap(Map<String, List<LookupValue>> lookupMap) {
        this.lookupMap = lookupMap;
    }

}
