package au.com.lonsec.service.company.productClassification.client.model;

import au.com.lonsec.service.company.company.client.model.Trackable;

/**
 * Product DTO for product maintenance.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

public class ProductClassificationLoadResponse extends Trackable {

    private Long recordCount;

    public Long getRecordCount() {
        return recordCount;
    }

    public void setRecordCount(Long recordCount) {
        this.recordCount = recordCount;
    }


}
