package au.com.lonsec.service.company;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties("app")
public class AppProperties {

    @Value("${lookup.folder}")
    private String lookupFolder;

    public String getLookupFolder() {
        return lookupFolder;
    }

    public void setLookupFolder(String lookupFolder) {
        this.lookupFolder = lookupFolder;
    }

}