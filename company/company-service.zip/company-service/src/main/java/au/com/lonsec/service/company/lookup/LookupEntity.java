package au.com.lonsec.service.company.lookup;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import au.com.lonsec.service.company.base.AbstractEntity;

/**
 * Lookup Model representation for lookup data.
 * 
 * @author MCheung
 */
@Entity
@Table(name = "lookup")
public class LookupEntity extends AbstractEntity {

    @Column(name = "entity_id")
    private String entityId;

    @Column(name = "lookup_type")
    private String lookupType;

    @Column(name = "lookup_type_name")
    private String lookupTypeName;

    @Column(name = "lookup_code")
    private String lookupCode;

    @Column(name = "lookup_value")
    private String lookupValue;

    @Column(name = "parent_code")
    private String parentCode;

    public String getEntityId() {
        return entityId;
    }

    public void setEntityId(String entityId) {
        this.entityId = entityId;
    }

    public String getLookupType() {
        return lookupType;
    }

    public void setLookupType(String lookupType) {
        this.lookupType = lookupType;
    }

    public String getLookupTypeName() {
        return lookupTypeName;
    }

    public void setLookupTypeName(String lookupTypeName) {
        this.lookupTypeName = lookupTypeName;
    }

    public String getLookupCode() {
        return lookupCode;
    }

    public void setLookupCode(String lookupCode) {
        this.lookupCode = lookupCode;
    }

    public String getLookupValue() {
        return lookupValue;
    }

    public void setLookupValue(String lookupValue) {
        this.lookupValue = lookupValue;
    }

    public String getParentCode() {
        return parentCode;
    }

    public void setParentCode(String parentCode) {
        this.parentCode = parentCode;
    }

}
