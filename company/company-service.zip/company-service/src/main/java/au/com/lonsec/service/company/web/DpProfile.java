package au.com.lonsec.service.company.web;

import java.util.Base64;
import java.util.Base64.Decoder;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;

public class DpProfile {
    
    public static final String MASK_ALL = "111111";
    public static final String MASK_ALL_ADMINS = "010100";
    public static final String MASK_EMPLOYEE_ADMINS = "010000";
    public static final String MASK_EXTERNAL_ADMINS = "000100";
    public static final String MASK_ANY_EMPLOYEES_OR_EXTERNAL_ADMINS = "110100";
    public static final String MASK_EMPLOYEES = "110000";
    public static final String MASK_EXTERNALS = "001100";
    public static final String MASK_DELEGATES = "000010";
    public static final String MASK_ANY_EXTERNALS_OR_DELEGATES = "001110";

    private static final ObjectMapper MAPPER = new ObjectMapper();
    private static final Decoder DECODER = Base64.getDecoder();

    @JsonProperty(value = "username", required = true)
    private String username;

    @JsonProperty(value = "id", required = true)
    private String profileId;

    @JsonProperty(value = "segment", required = true)
    private String segment;

    @JsonProperty(value = "extId", required = true)
    private String externalIdentifier;

    @JsonProperty(value = "role", required = true)
    private int roleHierarchy;

    @JsonProperty(value = "displayName", required = false)
    private String displayName;

    DpProfile() {

    }

    public String getUsername() {
        return username;
    }

    void setUsername(String username) {
        // Enforce username is always uppercase in the jcr repository.
        this.username = username.toUpperCase();
    }

    public String getProfileId() {
        return profileId;
    }

    void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getSegment() {
        return segment;
    }

    void setSegment(String segment) {
        // As JCR paths in this repo are lowercase, ensure segment is lowercase.
        this.segment = segment.toLowerCase();
    }

    public String getExternalIdentifier() {
        return externalIdentifier;
    }

    void setExternalIdentifier(String externalIdentifier) {
        // As JCR path in this repo are lowercase ensure external identifier is lowercase.
        this.externalIdentifier = externalIdentifier.toLowerCase();
    }

    public int getRoleHierarchy() {
        return roleHierarchy;
    }

    void setRoleHierarchy(int roleHierarchy) {
        this.roleHierarchy = roleHierarchy;
    }

    public String getDisplayName() {
        return displayName;
    }

    void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public static DpProfile fromToken(String profileToken, String displayName) throws Exception {
        DpProfile profile = MAPPER.readValue(DECODER.decode(profileToken), DpProfile.class);
        profile.setDisplayName(displayName);
        return profile;
    }

    public boolean hasPermission(String hierarchyMask) {
        int mask = Integer.parseInt(hierarchyMask, 2);
        return (mask & getRoleHierarchy()) > 0;
    }

}