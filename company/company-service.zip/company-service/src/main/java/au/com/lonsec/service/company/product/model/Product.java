package au.com.lonsec.service.company.product.model;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Product DTO for product maintenance.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "extUniqueKey", "productName", "productId", "apirCd", "segmentCd", "extUniqueKey", "active" })
public class Product {

    private String id;

    @NotNull(message = "Segment Id must be input")
    private String segmentId;

    @NotNull(message = "Product Name must be input")
    private String productName;

    @NotNull(message = "Product Id must be input")
    private String productId;

    @NotNull(message = "segmentCd  must be input")
    private String segmentCd;

    @NotNull(message = "extUniqueKey must be input")
    private String extUniqueKey;

    private String apirCd;
    
    private String asxCd;
    
    private String assetClassCd;
    
    private String sectorCd;
    
    private String subSectorCd;
    
    private String productClassCd;

    private String productType;
    
    private String researchPlan;

    private String sectorLead;

    private String notes;
    
    private Boolean active;

    public Product() {
    }

    @JsonCreator
    public Product(@JsonProperty("segmentId") String segmentId, @JsonProperty("productName") String productName,
            @JsonProperty("productId") String productId, @JsonProperty("apirCd") String apirCd, @JsonProperty("segmentCd") String segmentCd,
            @JsonProperty("extUniqueKey") String extUniqueKey, @JsonProperty("active") boolean active) {
        this.segmentId = segmentId;
        this.productName = productName;
        this.productId = productId;
        this.apirCd = apirCd;
        this.segmentCd = segmentCd;
        this.extUniqueKey = extUniqueKey;
        this.active = active;
    }

    public String getId() {
        return id;
    }


    public void setId(String id) {
        this.id = id;
    }

    public String getSegmentId() {
        return segmentId;
    }

    public void setSegmentId(String segmentId) {
        this.segmentId = segmentId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getSegmentCd() {
        return segmentCd;
    }

    public void setSegmentCd(String segmentCd) {
        this.segmentCd = segmentCd;
    }

    public String getExtUniqueKey() {
        return extUniqueKey;
    }

    public void setExtUniqueKey(String extUniqueKey) {
        this.extUniqueKey = extUniqueKey;
    }

    public String getApirCd() {
        return apirCd;
    }

    public void setApirCd(String apirCd) {
        this.apirCd = apirCd;
    }
    
    public String getAsxCd() {
        return asxCd;
    }

    public void setAsxCd(String asxCd) {
        this.asxCd = asxCd;
    }

    
    public String getAssetClassCd() {
        return assetClassCd;
    }

    public void setAssetClassCd(String assetClassCd) {
        this.assetClassCd = assetClassCd;
    }

    public String getSectorCd() {
        return sectorCd;
    }

    public void setSectorCd(String sectorCd) {
        this.sectorCd = sectorCd;
    }

    public String getSubSectorCd() {
        return subSectorCd;
    }

    public void setSubSectorCd(String subSectorCd) {
        this.subSectorCd = subSectorCd;
    }

    public String getProductClassCd() {
        return productClassCd;
    }

    public void setProductClassCd(String productClassCd) {
        this.productClassCd = productClassCd;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getResearchPlan() {
        return researchPlan;
    }

    public void setResearchPlan(String researchPlan) {
        this.researchPlan = researchPlan;
    }

    public String getSectorLead() {
        return sectorLead;
    }

    public void setSectorLead(String sectorLead) {
        this.sectorLead = sectorLead;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    
    
}
