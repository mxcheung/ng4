package au.com.lonsec.service.company.lookup;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

public interface LookupRepository extends JpaRepository<LookupEntity, Long> {

    LookupEntity findById(UUID id);

    List<LookupEntity> findByLookupTypeAndLookupTypeName(String lookupType, String lookupTypeName);

}