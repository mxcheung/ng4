package au.com.lonsec.service.company.configproperty;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ConfigPropertyRepository extends JpaRepository<ConfigPropertyEntity, Long> {

    List<ConfigPropertyEntity> findByEntityId(String entityId);

    List<ConfigPropertyEntity> findByEntityIdAndPropertyType(String entityId, ConfigPropertyType propertyType);

    void deleteByEntityIdAndPropertyTypeAndPropertyKey(String entityId, ConfigPropertyType propertyType, String propertyKey);

    ConfigPropertyEntity findByEntityIdAndPropertyTypeAndPropertyKey(String entityId, ConfigPropertyType propertyType, String propertyKey);

}