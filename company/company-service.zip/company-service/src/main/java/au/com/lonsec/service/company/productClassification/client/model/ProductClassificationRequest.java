package au.com.lonsec.service.company.productClassification.client.model;

import au.com.lonsec.service.company.productClassification.model.ProductClassification;

public class ProductClassificationRequest extends ProductClassification {

    private static final long serialVersionUID = 1L;

}
