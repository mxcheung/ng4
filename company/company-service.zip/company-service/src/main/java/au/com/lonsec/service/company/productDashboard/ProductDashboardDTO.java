package au.com.lonsec.service.company.productDashboard;

import au.com.lonsec.service.company.product.model.Product;
import au.com.lonsec.service.company.productClassification.model.ProductClassification;
import au.com.lonsec.service.company.segment.model.Segment;

/**
 * ProductDashboardDTO contains entities support the Product Dashboard.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

public class ProductDashboardDTO {

    private Segment segment;
    private Product product;
    private ProductClassification productClassification;

    public ProductDashboardDTO() {
    }

    public Segment getSegment() {
        return segment;
    }

    public void setSegment(Segment segment) {
        this.segment = segment;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public ProductClassification getProductClassification() {
        return productClassification;
    }

    public void setProductClassification(ProductClassification productClassification) {
        this.productClassification = productClassification;
    }

}
