package au.com.lonsec.service.company.productDashboard;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import au.com.lonsec.service.company.lookup.LookupGetRequest;
import au.com.lonsec.service.company.lookup.LookupService;
import au.com.lonsec.service.company.lookup.model.LookupValue;
import au.com.lonsec.service.company.product.ProductService;
import au.com.lonsec.service.company.product.model.Product;
import au.com.lonsec.service.company.productClassification.ProductClassificationNotFoundException;
import au.com.lonsec.service.company.productClassification.ProductClassificationService;
import au.com.lonsec.service.company.productClassification.model.ProductClassification;
import au.com.lonsec.service.company.productDashboard.model.ProductDashboardRow;
import au.com.lonsec.service.company.segment.SegmentNotFoundException;
import au.com.lonsec.service.company.segment.SegmentService;
import au.com.lonsec.service.company.segment.model.Segment;
import au.com.lonsec.service.company.web.DpProfile;

/**
 * ProductDashboardService - supports Product Dashboard UI.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

@Service
class ProductDashboardService {

    private static final String SYSTEM = "SYSTEM";

    private static final String SUBSECTOR = "SUBSECTOR";

    private static final String SECTOR = "SECTOR";

    private static final String PRODUCTCLASS = "PRODUCTCLASS";

    private static final String ASSETCLASS = "ASSETCLASS";

    private static final Logger LOGGER = LoggerFactory.getLogger(ProductDashboardService.class);

    private final SegmentService segmentService;

    private final ProductService productService;

    private final ProductClassificationService productClassificationService;

    private final ProductDashboardMapper productDashboardMapper;

    private final LookupService lookupService;

    @Autowired
    ProductDashboardService(SegmentService segmentService, ProductService productService, ProductClassificationService productClassificationService,
            ProductDashboardMapper productDashboardMapper, LookupService lookupService) {
        this.segmentService = segmentService;
        this.productService = productService;
        this.productClassificationService = productClassificationService;
        this.productDashboardMapper = productDashboardMapper;
        this.lookupService = lookupService;
    }

    /**
     *  Find all products for a segmentCd.
     *  
     * @param segmentCd business segment.
     * @param profile - user profile token.
     * @return data rows to support the product dashboard.
     */
    public List<ProductDashboardRow> findProducts(String segmentCd, DpProfile profile) {
        List<Product> products = productService.findProducts(segmentCd, profile);
        List<ProductDashboardDTO> dashboardDTOs = fetchAssociations(segmentCd, products);
        return convertUp(getLookupMap(), dashboardDTOs);
    }


    private List<ProductDashboardDTO> fetchAssociations(final String segmentCd, final List<Product> products) {
        return products.stream().map(entity -> fetchAssociation(segmentCd, entity)).collect(Collectors.toList());
    }

    /**
     *  Find associated entities [segment, product classification] for a product. 
     *  
     * @param segmentCd business segment.
     * @param product product details.
     * @return productdashboard DTO that contains the composite entities.
     */
    public ProductDashboardDTO fetchAssociation(final String segmentCd, final Product product) {
        ProductDashboardDTO productDashboardDTO = new ProductDashboardDTO();
        String extUniqueKey = product.getExtUniqueKey();
        productDashboardDTO.setProduct(product);
        productDashboardDTO.setProductClassification(fetchProductClassification(product.getProductId()));
        productDashboardDTO.setSegment(fetchSegment(segmentCd, extUniqueKey));
        return productDashboardDTO;
    }

    private ProductClassification fetchProductClassification(String productId) {
        try {
            return productClassificationService.findProductClassification(productId);
        } catch (ProductClassificationNotFoundException e) {
            return null;
        }
    }

    private Segment fetchSegment(String segmentCd, String extUniqueKey) {
        try {
            return segmentService.findSegment(segmentCd, extUniqueKey);
        } catch (SegmentNotFoundException e) {
            LOGGER.info("Unexpected exception occurred SegmentNotFoundException", e);
            return null;
        }
    }

    /**
     * Map Composite DTOs to Dashboard Rows.
     *
     * @param lookup contains product classification mappings.
     * @param productList - list of products to convert. 
     * @return Dashboard Rows.
     */
    public List<ProductDashboardRow> convertUp(Map<String, Map<String, String>> lookup, List<ProductDashboardDTO> productList) {
        return productList.stream().map(entity -> convertUp(lookup, entity)).collect(Collectors.toList());
    }


    /**
     * Map Composite DTO to Dashboard Row.
     * 
     * @param lookup contains product classification mappings.
     * @param productDashboardDTO composite entities [product, segment, product classification].
     * @return Dashboard Row.
     */
    public ProductDashboardRow convertUp(Map<String, Map<String, String>> lookup, ProductDashboardDTO productDashboardDTO) {
        return productDashboardMapper.map(lookup, productDashboardDTO, new ProductDashboardRow());
    }

    private Map<String, Map<String, String>> getLookupMap() {
        return lookupService.convertToMap(getSystemLookups());
    }

    private Map<String, List<LookupValue>> getSystemLookups() {
        return lookupService.fetchLookupByType(getLookupRequest());
    }

    private LookupGetRequest getLookupRequest() {
        LookupGetRequest lookupGetRequest = new LookupGetRequest();
        lookupGetRequest.setLookupType(SYSTEM);
        List<String> shoppingList = new ArrayList<String>();
        shoppingList.add(ASSETCLASS);
        shoppingList.add(PRODUCTCLASS);
        shoppingList.add(SECTOR);
        shoppingList.add(SUBSECTOR);
        lookupGetRequest.setShoppingList(shoppingList);
        return lookupGetRequest;
    }

}