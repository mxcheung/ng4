package au.com.lonsec.service.company.product.client.model;

import java.util.List;

import au.com.lonsec.service.company.company.client.model.Trackable;
import au.com.lonsec.service.company.product.model.Product;

/**
 * Product DTO for product maintenance.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

public class ProductsResponse extends Trackable {

    private List<Product> products;

    public List<Product> getProducts() {
        return products;
    }

    public void setProducts(List<Product> products) {
        this.products = products;
    }

}
