package au.com.lonsec.service.company.company;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import au.com.lonsec.service.company.company.client.model.CompanyAddRequest;
import au.com.lonsec.service.company.company.client.model.CompanyGetByIdsRequest;
import au.com.lonsec.service.company.company.client.model.CompanyUpdateRequest;
import au.com.lonsec.service.company.company.model.Company;

/**
 * CompanyService - supports crud method for company repository.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

@Service
public class CompanyService {

    private static final String ACTIVE = "ACTIVE";

    private static final Logger LOGGER = LoggerFactory.getLogger(CompanyService.class);

    private final CompanyRepository companyRepository;

    @Autowired
    CompanyService(CompanyRepository companyRepository) {
        this.companyRepository = companyRepository;
    }

    public Company findCompany(String companyid) throws CompanyNotFoundException {
        return convertUp(findOrThrow(companyid));
    }

    /**
     * Create Company will attempt to match existing on abn. If no matching company then proceed with company
     * creation.
     * 
     * @param companyAddRequest - Create company request
     * @return CompanyEntity
     */
    public Company createCompany(CompanyAddRequest companyAddRequest) {
        CompanyEntity companyEntity = findOrCreate(companyAddRequest);
        return convertUp(save(companyAddRequest, companyEntity));
    }

    /**
     * Update Company validate entity exists using primary key. If no matching company then throw
     * 
     * @param companyUpdateRequest - Update company request
     * @return CompanyEntity
     * @throws CompanyNotFoundException when unable to located entity using primary key.
     */
    public Company updateCompany(CompanyUpdateRequest companyUpdateRequest) throws CompanyNotFoundException {
        CompanyEntity companyEntity = findOrThrow(companyUpdateRequest.getAbn());
        return convertUp(save(companyUpdateRequest, companyEntity));
    }

    private CompanyEntity findOrThrow(String companyid) throws CompanyNotFoundException {
        CompanyEntity result = companyRepository.findByAbn(companyid);
        if (result == null) {
            throw new CompanyNotFoundException(String.format("No company found for the identifiers: %s", companyid));
        }
        return result;
    }

    private CompanyEntity findOrCreate(Company company) {
        try {
            return matchCompany(company.getAbn());
        } catch (CompanyNotFoundException e) {
            return new CompanyEntity();
        }
    }

    private CompanyEntity save(Company company, CompanyEntity companyEntity) {
        companyEntity.setCompanyName(company.getCompanyName());
        companyEntity.setAbn(company.getAbn());
        companyEntity.setAddress(company.getAddress());
        companyEntity.setParentId(RestUtils.convertUUID(company.getParentId()));
        companyRepository.save(companyEntity);

        LOGGER.info("Company created :", companyEntity);
        return companyEntity;
    }

    /**
     * Use the following to locate company 1. Segment Cd + extUniqueKey 2. Abn
     * 
     * @param abn unique key
     * @return
     * @throws CompanyNotFoundException
     */

    private CompanyEntity matchCompany(String abn) throws CompanyNotFoundException {
        CompanyEntity company = findByAbn(abn);
        if (company == null) {
            throw new CompanyNotFoundException(String.format("Unable to locate abn: %s", abn));
        }
        return company;
    }

    private CompanyEntity findByAbn(String abn) {
        CompanyEntity company = companyRepository.findByAbn(abn);
        return company;
    }

    public Map<String, Company> fetchByABNs(CompanyGetByIdsRequest companyFetchByAbnsRequest) {

        List<String> abns = companyFetchByAbnsRequest.getAbns();
        Map<String, Company> result = new HashMap<String, Company>();

        for (String abn : abns) {
            CompanyEntity companyEntity = companyRepository.findByAbn(abn);
            if (companyEntity != null) {
                result.put(abn, convertUp(companyEntity));
            }
        }
        return result;
    }

    private Company convertUp(CompanyEntity companyEntity) {
        Company company = new Company();
        company.setStatus(ACTIVE);
        company.setId(RestUtils.convertUUIDToString(companyEntity.getId()));
        company.setAbn(companyEntity.getAbn());
        company.setAddress(companyEntity.getAddress());
        company.setCompanyName(companyEntity.getCompanyName());
        company.setParentId(RestUtils.convertUUIDToString(companyEntity.getParentId()));
        return company;
    }

}