package au.com.lonsec.service.company.product;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

import au.com.lonsec.service.company.base.AbstractEntity;

/**
 * Product Model representation for product.
 * 
 * @author MCheung
 */
@Entity
@Table(name = "product")
public class ProductEntity extends AbstractEntity {

    @NotEmpty
    private String segmentId;

    @NotEmpty
    private String productId;

    private String apirCd;
    
    private String asxCd;
    
    private String assetClassCd;
    
    private String sectorCd;
    
    private String subSectorCd;
    
    private String productClassCd;

    @NotEmpty
    private String productName;

    @NotEmpty
    private String segmentCd;

    @NotEmpty
    private String extUniqueKey;

    private String productType;
    
    private String researchPlan;
    
    private String sectorLead;
    
    private String notes;
    
    private Boolean active = true;

    public ProductEntity() {
    }

    public ProductEntity(String segmentId, String productName, String productId, String apirCd, Boolean active) {
        this.segmentId = segmentId;
        this.productName = productName;
        this.productId = productId;
        this.apirCd = apirCd;
        this.active = active;
    }

    public String getSegmentId() {
        return segmentId;
    }

    public void setSegmentId(String segmentId) {
        this.segmentId = segmentId;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getApirCd() {
        return apirCd;
    }

    public void setApirCd(String apirCd) {
        this.apirCd = apirCd;
    }

    public String getAsxCd() {
        return asxCd;
    }

    public void setAsxCd(String asxCd) {
        this.asxCd = asxCd;
    }

    public String getAssetClassCd() {
        return assetClassCd;
    }

    public void setAssetClassCd(String assetClassCd) {
        this.assetClassCd = assetClassCd;
    }

    public String getSectorCd() {
        return sectorCd;
    }

    public void setSectorCd(String sectorCd) {
        this.sectorCd = sectorCd;
    }

    public String getSubSectorCd() {
        return subSectorCd;
    }

    public void setSubSectorCd(String subSectorCd) {
        this.subSectorCd = subSectorCd;
    }

    public String getProductClassCd() {
        return productClassCd;
    }

    public void setProductClassCd(String productClassCd) {
        this.productClassCd = productClassCd;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getSegmentCd() {
        return segmentCd;
    }

    public void setSegmentCd(String segmentCd) {
        this.segmentCd = segmentCd;
    }

    public String getExtUniqueKey() {
        return extUniqueKey;
    }

    public void setExtUniqueKey(String extUniqueKey) {
        this.extUniqueKey = extUniqueKey;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getResearchPlan() {
        return researchPlan;
    }

    public void setResearchPlan(String researchPlan) {
        this.researchPlan = researchPlan;
    }

    public String getSectorLead() {
        return sectorLead;
    }

    public void setSectorLead(String sectorLead) {
        this.sectorLead = sectorLead;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    
    
}
