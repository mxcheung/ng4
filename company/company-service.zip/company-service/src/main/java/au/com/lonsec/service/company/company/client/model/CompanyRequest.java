package au.com.lonsec.service.company.company.client.model;

import au.com.lonsec.service.company.company.model.Company;

public class CompanyRequest extends Company {

    private static final long serialVersionUID = 1L;

}
