package au.com.lonsec.service.company.product;

import static au.com.lonsec.service.company.CompanyControllerAdvice.MODEL_ATTR_PROFILE;
import static org.springframework.http.HttpStatus.ACCEPTED;
import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.HttpStatus.OK;
import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;
import static org.springframework.web.bind.annotation.RequestMethod.PUT;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import au.com.lonsec.service.company.product.client.model.ProductAddRequest;
import au.com.lonsec.service.company.product.client.model.ProductAddResponse;
import au.com.lonsec.service.company.product.client.model.ProductGetResponse;
import au.com.lonsec.service.company.product.client.model.ProductUpdateRequest;
import au.com.lonsec.service.company.product.client.model.ProductUpdateResponse;
import au.com.lonsec.service.company.product.client.model.ProductsGetResponse;
import au.com.lonsec.service.company.web.DpProfile;

/**
 * ProductController - supports crud method for product repository.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

@RestController
@Validated
@RequestMapping(value = ProductURI.PRODUCT_BASE_CONTEXT)
class ProductController {

    @Autowired
    private ProductService productService;

    @RequestMapping(value = ProductURI.GET_PRODUCT_MAPPING, method = GET)
    @ResponseStatus(OK)
    @ResponseBody
    public ResponseEntity<ProductGetResponse> productGet(@PathVariable(value = "productId") final String productId,
            @RequestHeader(value = "correlation-id", required = false) final String xRequestCorrelationID,
            @RequestHeader(value = "Authorization", required = false) final String authToken,
            @RequestHeader(value = "segmentCd", required = true) final String xRequestSegmentCd) throws ProductNotFoundException {
        ProductGetResponse result = new ProductGetResponse();
        result.setCorrelationId(xRequestCorrelationID);
        result.setProduct(productService.findProduct(xRequestSegmentCd, productId));
        return new ResponseEntity<>(result, OK);
    }

    @RequestMapping(value = ProductURI.GET_PRODUCTS_MAPPING, method = GET)
    @ResponseStatus(OK)
    @ResponseBody
    public ResponseEntity<ProductsGetResponse> productsGet(
            @RequestHeader(value = "correlation-id", required = false) final String xRequestCorrelationID,
            @RequestHeader(value = "Authorization", required = false) final String authToken,
            @RequestHeader(value = "segmentCd", required = true) final String xRequestSegmentCd,
            @ModelAttribute(MODEL_ATTR_PROFILE) final DpProfile profile) throws ProductNotFoundException {

        ProductsGetResponse result = new ProductsGetResponse();
        result.setCorrelationId(xRequestCorrelationID);
        result.setProducts(productService.findProducts(xRequestSegmentCd, profile));
        return new ResponseEntity<>(result, OK);
    }

    @RequestMapping(value = ProductURI.GET_PRODUCTS_SEGMENT_MAPPING, method = GET)
    @ResponseStatus(OK)
    @ResponseBody
    public ResponseEntity<ProductsGetResponse> fetchByExtUniqueKey(@PathVariable(value = "extUniqueKey") final String extUniqueKey,
            @RequestHeader(value = "correlation-id", required = false) final String xRequestCorrelationID,
            @RequestHeader(value = "Authorization", required = false) final String authToken,
            @RequestHeader(value = "segmentCd", required = true) final String xRequestSegmentCd) throws ProductNotFoundException {
        ProductsGetResponse result = new ProductsGetResponse();
        result.setCorrelationId(xRequestCorrelationID);
        result.setProducts(productService.findBySegmentCdAndExtUniqueKey(xRequestSegmentCd, extUniqueKey));
        return new ResponseEntity<>(result, OK);
    }

    @RequestMapping(value = ProductURI.POST_PRODUCTS_MAPPING, method = POST)
    @ResponseStatus(CREATED)
    @ResponseBody
    public ResponseEntity<ProductAddResponse> productAdd(@Valid @RequestBody final ProductAddRequest productAddRequest,
            @RequestHeader(value = "correlation-id", required = false) final String xRequestCorrelationID,
            @RequestHeader(value = "Authorization", required = false) final String authToken,
            @RequestHeader(value = "segmentCd", required = true) final String xRequestSegmentCd) {
        ProductAddResponse result = new ProductAddResponse();
        result.setCorrelationId(xRequestCorrelationID);
        result.setProduct(productService.createProduct(productAddRequest));
        return new ResponseEntity<>(result, CREATED);
    }

    @RequestMapping(value = ProductURI.PUT_PRODUCTS_MAPPING, method = PUT)
    @ResponseStatus(ACCEPTED)
    @ResponseBody
    public ResponseEntity<ProductUpdateResponse> updateProduct(@PathVariable(value = "productId") final String productId,
            @RequestHeader(value = "correlation-id", required = false) final String xRequestCorrelationID,
            @RequestHeader(value = "Authorization", required = false) final String authToken,
            @RequestHeader(value = "segmentCd", required = true) final String xRequestSegmentCd,
            @Valid @RequestBody final ProductUpdateRequest productUpdateRequest) throws ProductNotFoundException {
        ProductUpdateResponse result = new ProductUpdateResponse();
        result.setCorrelationId(xRequestCorrelationID);
        result.setProduct(productService.updateProduct(xRequestSegmentCd, productId, productUpdateRequest));
        return new ResponseEntity<>(result, ACCEPTED);
    }

    @RequestMapping(value = ProductURI.PUT_PRODUCT_CLASSIFICATION_MAPPING, method = PUT)
    @ResponseStatus(ACCEPTED)
    @ResponseBody
    public ResponseEntity<ProductUpdateResponse> updateProductClassfication(@PathVariable(value = "productId") final String productId,
            @RequestHeader(value = "correlation-id", required = false) final String xRequestCorrelationID,
            @RequestHeader(value = "Authorization", required = false) final String authToken,
            @RequestHeader(value = "segmentCd", required = true) final String xRequestSegmentCd,
            @Valid @RequestBody final ProductUpdateRequest productUpdateRequest) throws ProductNotFoundException {
        ProductUpdateResponse result = new ProductUpdateResponse();
        result.setCorrelationId(xRequestCorrelationID);
        result.setProduct(productService.updateProductClassification(xRequestSegmentCd, productId, productUpdateRequest));
        return new ResponseEntity<>(result, ACCEPTED);
    }

}
