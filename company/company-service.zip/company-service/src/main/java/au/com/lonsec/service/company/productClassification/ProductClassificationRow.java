package au.com.lonsec.service.company.productClassification;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Product Classification DTO for company maintenance.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "apirCd", "productId", "asxCd", "productName", "assetClassName", "sectorName", "subSectorName", "productClass" })
public class ProductClassificationRow {

    private String apirCd;

    @NotNull(message = "productId must be input")
    private String productId;
    private String asxCd;
    private String productName;
    private String assetClassName;
    private String sectorName;
    private String subSectorName;
    private String productClass;

    @JsonCreator
    public ProductClassificationRow(@JsonProperty(value = "apirCd", required = false) String apirCd,
            @JsonProperty(value = "productId", required = true) String productId, @JsonProperty(value = "asxCd", required = false) String asxCd,
            @JsonProperty(value = "productName", required = true) String productName,
            @JsonProperty(value = "assetClassName", required = false) String assetClassName,
            @JsonProperty(value = "sectorName", required = false) String sectorName,
            @JsonProperty(value = "subSectorName", required = false) String subSectorName,
            @JsonProperty(value = "productClass", required = false) String productClass

    ) {
        this.productId = productId;
        this.apirCd = apirCd;
        this.asxCd = asxCd;
        this.productName = productName;
        this.assetClassName = assetClassName;
        this.sectorName = sectorName;
        this.subSectorName = subSectorName;
        this.productClass = productClass;

    }

    public String getApirCd() {
        return apirCd;
    }

    public void setApirCd(String apirCd) {
        this.apirCd = apirCd;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getAsxCd() {
        return asxCd;
    }

    public void setAsxCd(String asxCd) {
        this.asxCd = asxCd;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getAssetClassName() {
        return assetClassName;
    }

    public void setAssetClassName(String assetClassName) {
        this.assetClassName = assetClassName;
    }

    public String getSectorName() {
        return sectorName;
    }

    public void setSectorName(String sectorName) {
        this.sectorName = sectorName;
    }

    public String getSubSectorName() {
        return subSectorName;
    }

    public void setSubSectorName(String subSectorName) {
        this.subSectorName = subSectorName;
    }

    public String getProductClass() {
        return productClass;
    }

    public void setProductClass(String productClass) {
        this.productClass = productClass;
    }

}
