package au.com.lonsec.service.company.lookup;

import static org.springframework.http.HttpStatus.OK;
import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;

import au.com.lonsec.service.company.lookup.client.model.LookupCompanyResponse;
import au.com.lonsec.service.company.lookup.client.model.LookupContactResponse;
import au.com.lonsec.service.company.lookup.model.LookupValue;

/**
 * ProductController - supports crud method for product repository.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

@RestController
@Validated
@RequestMapping(value = LookupURI.LOOKUP_BASE_CONTEXT)
public class LookupController {

    @Autowired
    private LookupService lookupService;

    @RequestMapping(value = LookupURI.LOOKUP_FETCH_MAPPING, method = POST)
    @ResponseStatus(OK)
    @ResponseBody
    public ResponseEntity<LookupServiceResponseDTO> lookupFetch(@Valid @RequestBody final LookupGetRequest lookupGetRequest,
            @RequestHeader(value = "correlation-id", required = false) final String xRequestCorrelationID,
            @RequestHeader(value = "Authorization", required = false) final String authToken) {
        LookupServiceResponseDTO result = new LookupServiceResponseDTO();
        result.setCorrelationId(xRequestCorrelationID);
        Map<String, List<LookupValue>> lookups = lookupService.fetchLookupByType(lookupGetRequest);
        result.setLookups(lookups);
        return new ResponseEntity<>(result, OK);
    }

    @RequestMapping(value = LookupURI.LOOKUP_REFRESH, method = POST)
    @ResponseStatus(OK)
    @ResponseBody
    public ResponseEntity<LookupServiceResponseDTO> lookupRefresh(@Valid @RequestBody final LookupLoadRequest lookupLoadRequest,
            @RequestHeader(value = "correlation-id", required = false) final String xRequestCorrelationID)
            throws JsonProcessingException, FileNotFoundException, IOException {
        LookupServiceResponseDTO result = new LookupServiceResponseDTO();
        result.setCorrelationId(xRequestCorrelationID);
        List<LookupEntity> lookups = lookupService.lookupLoad(lookupLoadRequest);
        result.setRecordCount((long) lookups.size());
        return new ResponseEntity<>(result, OK);
    }

    /* Custom lookup for company page */
    @RequestMapping(value = LookupURI.COMPANY_LOOKUP, method = GET)
    @ResponseStatus(OK)
    @ResponseBody
    public ResponseEntity<LookupCompanyResponse> lookupFetch(
            @RequestHeader(value = "correlation-id", required = false) final String xRequestCorrelationID) {
        LookupCompanyResponse result = new LookupCompanyResponse();
        Map<String, List<LookupValue>> sRlookups = getSRLookups();
        Map<String, List<LookupValue>> systemlookups = getSystemLookups();
        sRlookups.putAll(systemlookups);
        result.setLookupMap(sRlookups);
        return new ResponseEntity<>(result, OK);
    }

    /* Custom lookup for product page */
    @RequestMapping(value = LookupURI.PRODUCT_LOOKUP, method = GET)
    @ResponseStatus(OK)
    @ResponseBody
    public ResponseEntity<LookupCompanyResponse> productLookup(
            @RequestHeader(value = "correlation-id", required = false) final String xRequestCorrelationID) {
        LookupCompanyResponse result = new LookupCompanyResponse();
        Map<String, List<LookupValue>> sRlookups = getSRProductLookups();
        Map<String, List<LookupValue>> systemlookups = getSystemLookups();
        sRlookups.putAll(systemlookups);
        result.setLookupMap(sRlookups);

        return new ResponseEntity<>(result, OK);
    }

    /* Custom lookup for contact page */
    @RequestMapping(value = LookupURI.CONTACT_LOOKUP, method = GET)
    @ResponseStatus(OK)
    @ResponseBody
    public ResponseEntity<LookupContactResponse> contactLookup(
            @RequestHeader(value = "correlation-id", required = false) final String xRequestCorrelationID) {
        LookupContactResponse result = new LookupContactResponse();
        result.setLookupMap(getContactSystemLookups());
        return new ResponseEntity<>(result, OK);
    }

    private Map<String, List<LookupValue>> getSRProductLookups() {
        LookupGetRequest lookupGetRequest = new LookupGetRequest();
        lookupGetRequest.setLookupType("SYSTEM_SR");
        List<String> shoppingList = new ArrayList<String>();
        shoppingList.add("ProductType");
        lookupGetRequest.setShoppingList(shoppingList);
        Map<String, List<LookupValue>> lookups = lookupService.fetchLookupByType(lookupGetRequest);
        return lookups;
    }

    private Map<String, List<LookupValue>> getSRLookups() {
        LookupGetRequest lookupGetRequest = new LookupGetRequest();
        lookupGetRequest.setLookupType("SYSTEM_SR");
        List<String> shoppingList = new ArrayList<String>();
        shoppingList.add("QuestionnaireType");
        lookupGetRequest.setShoppingList(shoppingList);
        Map<String, List<LookupValue>> lookups = lookupService.fetchLookupByType(lookupGetRequest);
        return lookups;
    }

    private Map<String, List<LookupValue>> getSystemLookups() {
        LookupGetRequest lookupGetRequest = new LookupGetRequest();
        lookupGetRequest.setLookupType("SYSTEM");
        List<String> shoppingList = new ArrayList<String>();
        shoppingList.add("Status");
        shoppingList.add("ASSETCLASS");
        shoppingList.add("PRODUCTCLASS");
        shoppingList.add("SECTOR");
        shoppingList.add("SUBSECTOR");
        lookupGetRequest.setShoppingList(shoppingList);
        Map<String, List<LookupValue>> lookups = lookupService.fetchLookupByType(lookupGetRequest);
        return lookups;
    }

    private Map<String, List<LookupValue>> getContactSystemLookups() {
        LookupGetRequest lookupGetRequest = new LookupGetRequest();
        lookupGetRequest.setLookupType("SYSTEM");
        List<String> shoppingList = new ArrayList<String>();
        shoppingList.add("UserRole");
        shoppingList.add("Comms");
        lookupGetRequest.setShoppingList(shoppingList);
        Map<String, List<LookupValue>> lookups = lookupService.fetchLookupByType(lookupGetRequest);
        return lookups;
    }

}
