package au.com.lonsec.service.company.product;

/**
 * @author MAX see https://studio.restlet.com/apis/local/sections/Companies
 */
public final class ProductURI {

    public static final String PRODUCT_BASE_CONTEXT = "/products";

    /* Load the list of Products */
    public static final String GET_PRODUCTS_MAPPING = "/products";
    /* Load an individual Product */
    public static final String GET_PRODUCT_MAPPING = "/product/{productId}";
    /* Create a new Product */
    public static final String POST_PRODUCTS_MAPPING = "/product";
    /* Update a Product */
    public static final String PUT_PRODUCTS_MAPPING = "/product/{productId}";

    /* Update a Product Classification */
    public static final String PUT_PRODUCT_CLASSIFICATION_MAPPING = "/productclassification/{productId}";

    public static final String GET_PRODUCTS_SEGMENT_MAPPING = "/products/{extUniqueKey}";

    private ProductURI() {
    }

}